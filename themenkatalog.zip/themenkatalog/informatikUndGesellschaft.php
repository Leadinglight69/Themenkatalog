<?php
$title = 'Informatik im gesellschaftlichen Kontext: Big Data, Web 2.0 und mehr';
$description = 'Erforschen Sie den Einfluss der Informatik auf die Gesellschaft, einschließlich Themen wie Big Data, Web 2.0, Industrie 4.0, das Internet der Dinge (IoT), die Nutzung von Sprachassistenten, e-Government und digitale Signaturen. Entdecken Sie Schutzmöglichkeiten vor Tracking, die Gefahren des Identitätsdiebstahls, die Bedeutung von Netzneutralität und die Vor- und Nachteile biometrischer Daten. Verstehen Sie, wie Unternehmensrichtlinien die Nutzung sozialer Netzwerke formen.';
$keywords = 'Informatik, Gesellschaft, Big Data, Web 2.0, Industrie 4.0, IoT, Sprachassistenten, e-Government, digitale Signatur, Tracking-Schutz, Identitätsdiebstahl, Netzneutralität, biometrische Daten, soziale Netzwerke';
$canonical = 'https://www.codeabschlussguide.de/informatik-und-gesellschaft';
include 'include/header.php'
?>
<body>
<main class="responsive">
  <section>
    <h1>8) Informatik und Gesellschaft</h1>
    <ul class="listLegend"  style="list-style: none">
      <li><a href="#big-Data">8.1 Fachbegriff Big-Data</a></li>
      <li><a href="#web">8.2 Fachbegriff Web 2.0</a></li>
      <li><a href="#industrie">8.3 Fachbegriff Industrie 4.0</a></li>
      <li><a href="#iot">8.4 Fachbegriff IoT</a></li>
      <li><a href="#sprachassistenten">8.5 Kenntnisse über Vor- und Nachteile bei Nutzung von Sprachassistenten</a></li>
      <li><a href="#e-Government">8.6 Kenntnisse über e-Government, digitale Signatur und Handy-Signatur</a></li>
      <li><a href="#tracking">8.7 Schutzmöglichkeiten vor Cookie-Tracking und Cookieless-Tracking</a></li>
      <li><a href="#identitätsdiebstahl">8.8 Kenntnisse über die Gefahr von Identitätsdiebstahl</a></li>
      <li><a href="#netzneutralität">8.9 Fachbegriff Netzneutralität</a></li>
      <li><a href="#biometrischen">8.10 Kenntnisse über Vor- und Nachteile bei Nutzung von biometrischen Daten</a></li>
      <li><a href="#netzwerken">8.11 Inhalte von Unternehmensrichtlinien für Nutzung von sozialen Netzwerken</a></li>
    </ul>
    <aside class="floatingNav">
      <div class="floatingDot" data-section="#big-Data"><span class="floatingText">8.1 </span></div>
      <div class="floatingDot" data-section="#web"><span class="floatingText">8.2 </span></div>
      <div class="floatingDot" data-section="#industrie"><span class="floatingText">8.3 </span></div>
      <div class="floatingDot" data-section="#iot"><span class="floatingText">8.4 </span></div>
      <div class="floatingDot" data-section="#sprachassistenten"><span class="floatingText">8.5 </span></div>
      <div class="floatingDot" data-section="#e-Government"><span class="floatingText">8.6 </span></div>
      <div class="floatingDot" data-section="#tracking"><span class="floatingText">8.7 </span></div>
      <div class="floatingDot" data-section="#identitätsdiebstahl"><span class="floatingText">8.8 </span></div>
      <div class="floatingDot" data-section="#netzneutralität"><span class="floatingText">8.9 </span></div>
      <div class="floatingDot" data-section="#biometrischen"><span class="floatingText">8.10 </span></div>
      <div class="floatingDot" data-section="#netzwerken"><span class="floatingText">8.11 </span></div>
    </aside>
  </section>

  <article>
    <section class="container" id="big-Data">
      <h2>8.1 Fachbegriff Big-Data</h2>
      <p>
        Big Data bezeichnet extrem große Datensätze, die so umfangreich und komplex sind, dass herkömmliche Datenverarbeitungswerkzeuge sie nicht effizient erfassen, speichern, verwalten und analysieren können. Diese Daten stammen aus vielfältigen Quellen und umfassen strukturierte, semi-strukturierte und unstrukturierte Daten. Big Data wird genutzt, um Muster, Trends und Verbindungen zu erkennen, die für geschäftliche Entscheidungen, wissenschaftliche Forschungen und viele andere Bereiche von Bedeutung sind. Die Analyse von Big Data setzt fortschrittliche Technologien und Methoden voraus, um wertvolle Einsichten zu gewinnen.
      </p>
      <div class="quelle">
        <a class="btn" href="https://www.oracle.com/de/big-data/what-is-big-data/#:~:text=Unter%20Big%20Data%20versteht%20man,vor%20allem%20von%20neuen%20Datenquellen. " target="_blank">Quelle</a>
      </div>
    </section>
    <section class="container" id="web">
      <h2>8.2 Fachbegriff Web 2.0</h2>
      <p>Der Begriff »Web 2.0« bezeichnet aus heutiger Sicht einen Zeitabschnitt in der Geschichte des Web. Besonders populär war der Begriff um das Jahr 2007. Unter Web 2.0 versteht man Neuerungen und Weiterentwicklungen aus dem Bereich Technik, Design, Service und Gesellschaft.
        Im Web 2.0 (auch als »Mitmach-Web« bezeichnet) leben Internetseiten- & Portale u.a. vom freiwillig zur Verfügung gestellten Inhalt des Users. Der Fachbegriff hierzu lautet »User-Generated-Content«.Der Seitenbesucher gestaltet selbst aktiv das Web mit, indem er Inhalte bereit stellt, kommentiert, bewertet, sammelt und verbreitet.

        Folgende Websites sind typische (und frühe) Vertreter dieser Entwicklung.  </p>
      <ul class="left" style="target: none">
        <li><a href="https://de.youtube.com/" target="_blank">Youtube</a></li>
        <li><a href="https://www.studivz.net/" target="_blank">studivz</a></li>
        <li><a href="https://www.myspace.com/" target="_blank">myspace</a></li>
        <li><a href="https://www.flickr.com/" target="_blank">flickr</a></li>
      </ul>
      <div class="quelle">
        <a class="btn" href="https://kulturbanause.de/faq/web-2-0/ " target="_blank">Quelle</a>
      </div>
    </section>
    <section class="container" id="industrie">
      <h2>8.3 Fachbegriff Industrie 4.0</h2>
      <p> Industrie 4.0 hat die Art und Weise, wie Unternehmen ihre Produkte konzipieren, herstellen und vertreiben, neu definiert. Technologien wie das industrielle Internet der Dinge (IIoT), Cloud-Konnektivität, künstliche Intelligenz und Machine Learning sind heute tief in den Fertigungsprozess verwoben. Dieser einheitliche und integrierte Ansatz für die Fertigung führt zu vernetzten und intelligenten Produkten, Fabriken und Anlagen. </p>
      <p>Die heutigen Industrie-4.0-Initiativen zielen auch auf die Entwicklung einer symbiotischen und lohnenden Zusammenarbeit zwischen Mensch und Technologie ab. Wenn die Genauigkeit und Schnelligkeit von Industrie-4.0-Tools mit der Kreativität, dem Talent und der Innovationskraft Ihrer Belegschaft zusammentrifft, ergibt sich eine Win-Win-Situation, die für Ihre Beschäftigten und für Ihr Unternehmen Vorteile mit sich bringt. Ihre Produktionsabläufe werden effizienter und produktiver, und Ihre Teams werden von vielen alltäglichen und sich wiederholenden Aufgaben entlastet – was ihnen die Möglichkeit gibt, mit intelligenten Technologien zu arbeiten und sich optimal auf die technologischen Entwicklungen und die KI-gestützte Zukunft der Arbeitswelt vorzubereiten.
        <br>Industrie 4.0 kann als die Integration intelligenter digitaler Technologien in Fertigungs- und Industrieprozesse definiert werden. Sie umfasst eine Reihe von Technologien, darunter industrielle IoT-Netzwerke, KI, Big Data, Robotik und Automatisierung. Industrie 4.0 ermöglicht eine intelligente Fertigung und die Schaffung von intelligenten Fabriken. Sie zielt darauf ab, die Produktivität, Effizienz und Flexibilität zu steigern und gleichzeitig intelligentere Entscheidungen und Anpassungen in der Fertigung und den Lieferketten zu ermöglichen.  </p>
      <p>Zur Definition des Begriffs Industrie 4.0 gehört außerdem die Herleitung aus der vierten industriellen Revolution. Seit dem Jahr 1800 haben wir drei industrielle Revolutionen erlebt. Sie wurden deshalb „Revolutionen“ genannt, weil die Innovationen, die sie antrieben, die Produktivität und Effizienz nicht nur ein wenig verbesserten, sondern von Grund auf revolutionierten, auf welche Art und Weise Güter hergestellt bzw. Arbeit geleistet </p>
      <div class="quelle">
        <a class="btn" href="https://de.wikipedia.org/wiki/Industrie_4.0" target="_blank">Quelle</a>
      </div>
    </section>
    <section class="container" id="iot">
      <h2>8.4 Fachbegriff IoT</h2>
      <p>IoT steht für “Internet of Things”, auf Deutsch “Internet der Dinge”. Es bezeichnet ein System von miteinander vernetzten Maschinen, Anlagen und Geräten über und mit dem Internet. Die damit verbundenen „Dinge“ müssen eindeutig identifizierbar sein. </p>
      <p>Das IoT ermöglicht eine Fernüberwachung und -steuerung durch den Austausch von Daten über das Internet, die von Sensoren und Software erfasst werden. Diese Technologie findet Anwendung in vielen Bereichen, einschließlich Alltagsgegenständen wie Smartphones und Smart-TVs, sowie Haushaltsgeräten wie Kaffeemaschinen oder Thermostaten. </p>
      <div class="quelle">
        <a class="btn" href="https://www.oracle.com/at/internet-of-things/what-is-iot/ " target="_blank">Quelle</a>
      </div>
    </section>
    <section class="container" id="sprachassistenten">
      <h2>8.5 Kenntnisse über Vor- und Nachteile bei Nutzung von Sprachassistenten</h2>
      <h3>Vorteile</h3>
      <ul>
        <li>Einfache Handhabung durch Spracheingabe</li>
        <li>Einkaufslisten erstellen</li>
        <li>Wecker stellen</li>
        <li>Unterstützung beim Autofahren</li>
      </ul>
      <h3>Nachteile</h3>
      <ul>
        <li>Daten werden von den dahinterstehenden Firmen gesammelt und verarbeitet</li>
        <li>Geräte warten immer auf ihr Schlüsselwort, hören somit immer aktiv zu</li>
        <li>Geräte können manipuliert werden, um einen auszuspionieren</li>
        <li>Kinder können auf jegliche Daten im Internet zugreifen, kein Schutz</li>
      </ul>
      <div class="quelle">
        <a class="btn" href="https://www.security-insider.de/nutzen-und-risiko-von-sprachassistenten-a-744746/" target="_blank">Quelle</a>
      </div>
    </section>
    <section class="container" id="e-Government">
      <h2>8.6 Kenntnisse über e-Government, digitale Signatur und Handy-Signatur</h2>
      <p>Die Schlüsselkomponenten der Digitalisierung im öffentlichen Sektor, wie E-Government, digitale Signatur und Handy-Signatur, spielen eine zentrale Rolle bei der Modernisierung und Effizienzsteigerung von Verwaltungsdienstleistungen. Hier eine kurze Zusammenfassung: </p>
      <ul class="left">
        <li><strong>E-Government: </strong>Nutzt digitale Technologien, um öffentliche Dienstleistungen zugänglicher und nutzerfreundlicher zu machen, was die Verwaltungsprozesse vereinfacht und die Kommunikation zwischen Bürgern und Behörden verbessert. </li>
        <li><strong>Digitale Signatur: </strong>Bietet eine sichere Methode, die Integrität und Authentizität digitaler Dokumente zu gewährleisten, mit rechtlicher Bindung für Verträge und amtliche Dokumente. </li>
        <li><strong>Handy-Signatur: </strong> Ermöglicht das Unterzeichnen elektronischer Dokumente und Transaktionen direkt über das Mobiltelefon, was als digitaler Ausweis fungiert und besonders in einigen Ländern für E-Government-Dienste genutzt wird.</li>
      </ul>
      <div class="quelle">
        <a class="btn" href="https://www.rtr.at/TKP/was_wir_tun/vertrauensdienste/konsumentenservice/e-government/egovernment.de.html" target="_blank">Quelle</a>
      </div>
    </section>
    <section class="container" id="tracking">
      <h2>8.7 Schutzmöglichkeiten vor Cookie-Tracking und Cookieless-Tracking</h2>
      <p>Um sich vor Cookie-Tracking zu schützen, können Nutzer in ihren Browsereinstellungen Drittanbieter-Cookies deaktivieren. Gegen Cookieless-Tracking, wie Fingerprinting oder Tracking über ETags, hilft das regelmäßige Leeren des Browser-Caches. Die Nutzung von spezialisierten Datenschutz-Tools und Browser-Erweiterungen, die solche Tracking-Methoden erkennen und blockieren, kann ebenfalls effektiv sein. Es ist wichtig, sich der verschiedenen Tracking-Technologien bewusst zu sein und proaktiv Maßnahmen zum Schutz der eigenen Online-Privatsphäre zu ergreifen.</p>
      <div class="quelle">
        <a class="btn" href="https://www.cintellic.com/wiki/was-ist-cookieless-tracking/#:~:text=Die%20einzige%20M%C3%B6glichkeit%20vor%20Schutz,Cross%20Device%20Tracking%20gesch%C3%BCtzt%20ist. " target="_blank">Quelle</a>
      </div>
    </section>
    <section class="container" id="identitätsdiebstahl">
      <h2>8.8 Kenntnisse über die Gefahr von Identitätsdiebstahl </h2>
      <p>Beim Identitätsdiebstahl versuchen Cyberkriminelle mittels Ausnutzung typischer psychologischer Verhaltensmuster wie Höflichkeit, Hilfsbereitschaft oder Neugierde sensible Informationen zu erschleichen, um damit Identitäten zu stehlen und die Unachtsamkeit von Internetnutzerinnen und -nutzern auszunützen.
        <br>
        Identitätsdiebstahl ist im Rahmen des Social Engineerings eine repräsentative Methode, um Schaden zu verursachen, Menschen zu täuschen und Online-Identitäten von Personen zu übernehmen. Damit haben die Kriminellen die Möglichkeit, auf Ihre Kosten Einkäufe zu tätigen oder Accounts bei Dienstleistern in Ihrem Namen zu eröffnen. Auch Mobbing-Kampagnen können damit einhergehen. Oft ist Identitätsdiebstahl mit direkter oder indirekter Rufschädigung verknüpft. </p>
      <div class="quelle">
        <a class="btn" href="https://www.onlinesicherheit.gv.at/Themen/Gefahren-im-Netz/Privatsphaere/Identitaetsdiebstahl.html " target="_blank">Quelle</a>
      </div>
    </section>
    <section class="container" id="netzneutralität">
      <h2>8.9 Fachbegriff Netzneutralität </h2>
      <p>Netzneutralität bedeutet, dass Daten unabhängig von deren Herkunft, Inhalt, Anwendung, Absender, Empfänger in Netzen gleich behandelt werden. Das ist für uns alle von zentraler Bedeutung, da wir Informationen und Internetdienste wie E-Mail, Nachrichten, VoIP oder Videos frei nutzen können. Dadurch haben alle Nutzer gleiche Chancen. Ideen und Innovationen können sich frei entfalten. </p>
      <h3>Diskussion in Europa </h3>
      <p>Da der Zugang zum freien und offenen Internet eine zentrale Bedeutung für uns alle hat, wird das Thema europaweit diskutiert. Der europäische Gesetzgeber hat Regeln zur Sicherstellung der Netzneutralität (Telekom-Binnenmarkt-Verordnung) festgelegt. Die Verordnung verankert Netzneutralität als Grundprinzip und soll sicherstellen, dass Datenverkehr nicht diskriminiert, geblockt, gedrosselt oder priorisiert wird. Dadurch sollen Nutzerrechte geschützt werden, denn alle sollen Informationen und Dienste frei nutzen können. Die Anbieter müssen dafür den gesamten Verkehr grundsätzlich gleich behandeln. Eine "angemessene Verwaltung" des Datenverkehrs ist nur zulässig, um technische Anforderungen für Qualität der Dienste sowie die Netzsicherheit im öffentlichen Interesse zu gewährleisten. Ein solches Verkehrsmanagement muss transparent, nichtdiskriminierend und verhältnismäßig sein und darf nicht aus kommerziellen Interessen erfolgen. Eine spezielle Datenkategorie, z. B. Videos oder Spiele, darf nicht gegen Bezahlung priorisiert werden. Erst recht darf der konkrete Inhalt nicht überwacht werden, und die Maßnahmen dürfen nicht länger als erforderlich aufrechterhalten werden.
        <br>
        Darüber hinaus müssen die Internetanbieter ihre Kunden über vertragsgemäße Beschränkungen des offenen Internetzugangs oder über die Rechte der Nutzer, wenn die tatsächliche Datenübermittlung von der vertraglich vereinbarten abweicht, ordnungsgemäß informieren. </p>
      <div class="quelle">
        <a class="btn" href="https://www.bundesnetzagentur.de/DE/Vportal/TK/InternetTelefon/Netzneutralitaet/start.html " target="_blank">Quelle</a>
      </div>
    </section>
    <section class="container" id="biometrischen">
      <h2>8.10 Kenntnisse über Vor- und Nachteile bei Nutzung von biometrischen Daten</h2>
      <h3>Vorteile: </h3>
      <p><strong>Einfach zu nutzen: </strong>Biometrische Daten sind immer dabei und können nicht verloren oder vergessen werden.</p>
      <p><strong>Schwer zu stehlen oder nachzuahmen: </strong> Biometrische Daten können nicht wie ein Passwort oder ein Schlüssel gestohlen werden. </p>
      <p><strong>Hohe Genauigkeit: </strong>Da biometrische Merkmale einzigartig und schwer zu fälschen sind, bieten sie eine zuverlässige Methode zur Unterscheidung von Personen. </p>
      <h3>Nachteile: </h3>
      <p><strong>Nicht unfehlbar: </strong>Hacker können biometrische Daten unter Verwendung verschiedener Techniken fälschen. </p>
      <p><strong>Risiko des Identitätsdiebstahls: </strong>Wenn Hacker Zugang zu biometrischen Daten erlangen, können diese Daten missbraucht werden. </p>
      <p><strong>Datenschutzbedenken: </strong> Die Verarbeitung biometrischer Daten unterliegt strengen datenschutzrechtlichen Bestimmungen. </p>

      <div class="quelle">
        <a class="btn" href="https://www.onlinesicherheit.gv.at/Services/News/Biometrie-Datenschutz-Interview.html" target="_blank">Quelle</a>
        <a class="btn" href="https://www.onelogin.com/de-de/learn/biometric-authentication " target="_blank">Quelle</a>
      </div>
    </section>
    <section class="container" id="netzwerken">
      <h2>8.11 Inhalte von Unternehmen&shy;srichtlinien für Nutzung von sozialen Netzwerken</h2>
      <p>Gut durchdachte Richtlinien geben Mitarbeitern die Informationen an die Hand, die sie benötigen, um in den sozialen
        <br>
        Medien die richtigen Entscheidungen zu treffen für sich selbst wie für das Unternehmen. Sie können Teammitglieder sogar zu unschätzbaren Botschaftern für Ihre Marke machen. </p>
      <h3>Vorteile </h3>
      <ul class="left">
        <li>Mitarbeiter zu positivem Engagement befähigen </li>
        <li>Über die besten Praktiken für Social Media informieren </li>
        <li>Mitarbeiter vor Belästigungen in den sozialen Medien schützen </li>
        <li>Unternehmen vor Cyber - Sicherheitsrisiken schützen </li>
        <li>Den Ruf Ihrer Marke in den sozialen Medien verbessern </li>
      </ul>
      <h3>Nachteile </h3>
      <ul class="left">
        <li>Eingriff in Privatleben und Privatsphäre</li>
        <li>Läuft Gefahr, willkürliche Regeln zu implementieren </li>
        <li>Marke kann mit negativen Verhalten von Mitarbeitern assoziiert werden </li>
      </ul>
      <h3>Inhalt guter Social Media Guidelines </h3>
      <ul class="left">
        <li>Geben Sie sich in den sozialen Netzwerken immer als Mitarbeiter des Unternehmens zu erkennen. </li>
        <li>Stellen Sie klar, dass es sich bei ihren Aussagen um ihre eigene Meinung handelt und sie nicht für das Unternehmen sprechen. </li>
        <li>Bleiben Sie stets höflich und freundlich. </li>
        <li>Antworten Sie bitte niemals emotional. </li>
        <li>Stellen Sie keine Behauptungen auf, die Sie nicht belegen können. </li>
        <li>Geben Sie keine Zusagen oder Versprechen im Namen des Unternehmens ab. </li>
        <li>Sprechen Sie bitte nur über Ihre eigenen Erfahrungen. </li>
        <li>Denken Sie immer daran: Sie kommunizieren mit Menschen. </li>
        <li>Diskutieren Sie keinesfalls firmeninterne Daten und Themen in den sozialen Netzwerken. Auch nicht in Chats oder geschlossenen Gruppen. </li>
        <li>Beschimpfen oder beleidigen Sie Ihre Gesprächspartner niemals. </li>
        <li>Äußern Sie Kritik bitte unternehmensintern und nicht über die sozialen Netzwerke. </li>
        <li>Verbreiten Sie keine Gerüchte über das Unternehmen, Kollegen oder Vorgesetzte. </li>
        <li>Meiden Sie sensible Themen wie beispielsweise Religion oder Politik. </li>
        <li>Nutzen Sie die sozialen Netzwerke bitte primär privat. </li>
        <li>Kommentare, Likes und Shares auf den Seiten des Unternehmens sind herzlich willkommen. Geben Sie Kritik und verärgerte Kommentare zum Unternehmen, die Sie in den Netzwerken finden, bitte an das Social Media Team weiter. </li>
      </ul>
      <div class="quelle">
        <a class="btn" href="https://karrierebibel.de/social-media-guidelines/ " target="_blank">Quelle</a>
      </div>
    </section>
      <div class="center">
          <a class="btn" href="itSecurityundBetriebssicherheit.php">Zurück zu IT-Security und Betriebs&shy;sicherheit</a>
          <a class="btn" href="ergonomischeGestaltungEinesArbeitsplatzes.php">Weiter zu Ergonomische Gestaltung eines Arbeitsplatzes</a>
      </div>
  </article>
</main>
<?php include'include/footer.php' ?>