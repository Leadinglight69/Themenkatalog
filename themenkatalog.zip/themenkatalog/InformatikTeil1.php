<?php
$title = 'Informatik Grundlagen: Webentwicklung, Scripting und Webstandards';
$description = 'Entdecken Sie grundlegende Konzepte der Informatik, einschließlich Webentwicklung, verschiedene Typen von Webseiten, wichtige Webtechnologien wie HTML, CSS, und JavaScript, sowie Standards wie SOAP, WSDL und REST APIs. Erhalten Sie Einblicke in die Welt der Informatik, von der Zeichencodierung bis hin zu modernen Content-Management-Systemen.';
$keywords = 'Informatik, Webentwicklung, HTML5, CSS, JavaScript, Webstandards, REST API, CMS, SEO, Frameworks, Scripting, Datenstrukturen, Userinterface Design';
$canonical = 'https://www.codeabschlussguide.de/informatik-teil-1';
include 'include/header.php'
?>

<main class="responsive">
    <section>
        <h1>11) Informatik Teil 1</h1>
        <ul class="listLegend"  style="list-style: none">
            <li><a href="#informatik">11.1 Fachbegriff Informatik</a></li>
            <li><a href="#statische">11.2 Typen von Webseiten (statische, dynamische Webseiten)</a></li>
            <li><a href="#webshop">11.3 Fachbegriffe Weblog, Webshop, Web-Plattform</a></li>
            <li><a href="#fachbegriff">11.4 Auszeichnungssprachen HTML, XML – Fachbegriff und Einsatzgebiet</a></li>
            <li><a href="#wichtigsten">11.5 Kenntnisse über das HTML5-Grundgerüst mit den wichtigsten Bestandteilen</a></li>
            <li><a href="#metadaten">11.6 Fachbegriff Meta-Element/Metadaten</a></li>
            <li><a href="#maßnahmen">11.7 Fachbegriff SEO und Maßnahmen</a></li>
            <li><a href="#einsatz">11.8 Fachbegriff Cascading StyleSheets und deren Einsatz</a></li>
            <li><a href="#clientseitiges">11.9 Scripting (clientseitiges Scripting, serverseitiges Scripting)</a></li>
            <li><a href="#webseiten">11.10 Software zum Erstellen und Betrachten von Webseiten (Code-Editoren, Web-Browser, FTP-
                Programme, Grafikprogramme, Serversoftware)</a></li>
            <li><a href="#cms">11.11 Fachbegriff CMS (Einsatzgebiet, notwendige Voraussetzungen, existierende Systeme am Markt)</a></li>
            <li><a href="#lifo">11.12 Unterschied LIFO/FIFO-Prinzip</a></li>
            <li><a href="#queue">11.13 Fachbegriffe Stack und Queue</a></li>
            <li><a href="#userinterface">11.14 Fachbegriff Userinterface (Arten, Regeln für Entwurf, Gestaltungshilfen / Toolkits / Frameworks)</a></li>
            <li><a href="#zeichencodierung">11.15 Fachbegriff Zeichencodierung (ASCII, ISO-Latin, Unicode, … – Unterschiede und Verwendung)</a></li>
            <li><a href="#iso">11.16 Standards ANSI, ISO, IEEE</a></li>
            <li><a href="#frame">11.17 Fachbegriff Frame</a></li>
            <li><a href="#heterogene">11.18 Fachbegriff Webservices (verteiltes System für heterogene Systeme, …)</a></li>
            <li><a href="#standards">11.19 Kenntnisse über Standards (SOAP, WSDL, …)</a></li>
            <li><a href="#api">11.20 Fachbegriff Rest API</a></li>
        </ul>
        <aside class="floatingNav">
            <div class="floatingDot" data-section="#informatik"><span class="floatingText">11.1 </span></div>
            <div class="floatingDot" data-section="#statische"><span class="floatingText">11.2 </span></div>
            <div class="floatingDot" data-section="#webshop"><span class="floatingText">11.3 </span></div>
            <div class="floatingDot" data-section="#fachbegriff"><span class="floatingText">11.4 </span></div>
            <div class="floatingDot" data-section="#wichtigsten"><span class="floatingText">11.5 </span></div>
            <div class="floatingDot" data-section="#metadaten"><span class="floatingText">11.6 </span></div>
            <div class="floatingDot" data-section="#maßnahmen"><span class="floatingText">11.7 </span></div>
            <div class="floatingDot" data-section="#einsatz"><span class="floatingText">11.8 </span></div>
            <div class="floatingDot" data-section="#clientseitiges"><span class="floatingText">11.9 </span></div>
            <div class="floatingDot" data-section="#webseiten"><span class="floatingText">11.10 </span></div>
            <div class="floatingDot" data-section="#cms"><span class="floatingText">11.11 </span></div>
            <div class="floatingDot" data-section="#lifo"><span class="floatingText">11.12 </span></div>
            <div class="floatingDot" data-section="#queue"><span class="floatingText">11.13 </span></div>
            <div class="floatingDot" data-section="#userinterface"><span class="floatingText">11.14 </span></div>
            <div class="floatingDot" data-section="#zeichencodierung"><span class="floatingText">11.15 </span></div>
            <div class="floatingDot" data-section="#iso"><span class="floatingText">11.16 </span></div>
            <div class="floatingDot" data-section="#frame"><span class="floatingText">11.17 </span></div>
            <div class="floatingDot" data-section="#heterogene"><span class="floatingText">11.18 </span></div>
            <div class="floatingDot" data-section="#standards"><span class="floatingText">11.19 </span></div>
            <div class="floatingDot" data-section="#api"><span class="floatingText">11.20 </span></div>
        </aside>
    </section>

    <article>
        <section class="container" id="informatik">
            <h2>11.1 Fachbegriff Informatik</h2>
            <p>Die Informatik ist die Wissenschaft der systematischen Verarbeitung von Informationen, insbesondere der automatischen Verarbeitung mithilfe von Computern. Sie umfasst sowohl theoretische Aspekte der Informationsdarstellung und -übertragung als auch praktische Anwendungen in verschiedenen technischen Disziplinen. Als interdisziplinäres Feld verbindet die Informatik Grundlagenforschung mit angewandter Ingenieursarbeit und hat entscheidende Beiträge zur Entwicklung moderner Technologien und zur Gestaltung der digitalen Welt geleistet.</p>
            <div class="quelle">
                <a class="btn" href="https://de.wikipedia.org/wiki/Informatik " target="_blank">Quelle</a>
            </div>
        </section>
        <section class="container" id="statische">
            <h2>11.2 Typen von Webseiten (statische, dynamische Webseiten)</h2>
            <p>Bei einer statischen Website werden alle Seiten eines Internetauftritts hergestellt und als einzelne Dateien auf dem Webserver gespeichert. Wenn ein Besucher die Website besucht, werden die Seiten direkt zu ihm übertragen. Ein Zugriff auf Datenbanken erfolgt nicht. Benötigt man eine größere Website, kann es bei einer statischen Website schnell vorkommen, dass sehr viele einzelne Dateien erstellt werden müssen. Ändert man etwas am Layout zum Beispiel, muss jede Datei einzeln angepasst werden. Auch die Erst-Erstellung aller Dateien ist sehr zeitintensiv.</p>
            <p> Ein „Content-Management-System“ (WordPress zB.) generiert so genannte dynamische Internetseiten auf Basis von Datenbanken. Das bedeutet, dass die Inhalte (Texte, Bilder, andere Medien etc.) getrennt von technischen Elementen (Layout- Vorlagen, Programmierung, Skripte) aufbewahrt werden. Wenn ein Besucher die Website besucht, werden die Inhalte und die technischen Elemente aus den Datenbanken gelesen und “just in time” zu einer Internetseite zusammengefügt und dem Besucher der Seite ausgeliefert. Man hat also die Inhalte nicht „fest verankert“ in einem Seiten-Dokument. Die Inhalte werden jedes Mal „live“ aus der Datenbank genommen. </p>
            <div class="quelle">
                <a class="btn" href="https://www.pixelbar.be/blog/einsteiger-tipps-unterschied-statisch-dynamisch-cms/ " target="_blank">Quelle</a>
            </div>
        </section>
        <section class="container" id="webshop">
            <h2>11.3 Fachbegriffe Weblog, Webshop, Web - Plattform</h2>
            <h3>Weblog</h3>
            <p>Das Wort Blog ist die Abkürzung von Weblog, eine Zusammensetzung aus den beiden englischen Wörtern web, für Netz, und log, für Logbuch bzw. Tagebuch. Der Begriff Weblog tauchte 1997 erstmals auf. Die Abkürzung Blog für Weblog stammt aus dem Jahr 1999 – in dem Jahr, in dem allgemein der Aufstieg dieser Art von Websites begann. Gleichzeitig etablierten sich einige Blogs als angesehene Medien. Um die unterschiedlichen Charakteristika der Blogs begrifflich abzugrenzen, spricht man von Informationsblogs und Meinungsblogs </p>
            <h3>Online-Shop </h3>
            <p>
                Ein Online-Shop (auch Webshop) ist eine Plattform für eine spezielle Form des elektronischen Handels. Als Synonyme für elektronischen Handel gelten die Begriffe Onlinehandel, Internethandel oder E-Commerce. Darunter wird im Allgemeinen das Angebot und der Verkauf von Waren oder Dienstleistungen über das Internet – also online – verstanden. Wie im stationären Handel gibt es ein oder mehrere Anbieter sowie die Kunden. Diese Konstellation von Business-to-Consumer (B2C) finden wir häufig beim Online-Shopping vor.
                <br>
                Meistens wird ein Online-Shop dem Versandhandel zugeordnet, denn nach Bestellung der Ware erfolgt die Auslieferung per Post. Allerdings können auch digitale Produkte wie Musik, Software oder der Zugang zu Videos zum Verkauf stehen. Zu den beliebtesten Waren und Dienstleistungen, die über das Internet gekauft werden, zählen laut Statista Bekleidung, Schuhe sowie Veranstaltungstickets.
            </p>
            <h3>Webplattform</h3>
            <p>Eine Webplattform ist eine digitale Infrastruktur, die es Benutzern ermöglicht, über das Internet miteinander zu interagieren, Informationen auszutauschen und verschiedene Dienste zu nutzen. Diese Plattformen bieten in der Regel eine Vielzahl von Funktionen und Diensten, die darauf abzielen, bestimmte Bedürfnisse oder Ziele der Benutzer zu erfüllen. Hier sind einige grundlegende Merkmale von Webplattformen: </p>
            <ul class="left">
                <li>Zugänglichkeit über das Internet: Webplattformen sind online verfügbar und können über Webbrowser von verschiedenen Geräten aus, wie Computern, Tablets oder Smartphones, aufgerufen werden. </li>
                <li>Benutzerregistrierung und Konten: In der Regel erfordern Webplattformen, dass Benutzer sich registrieren und Konten erstellen. Dies ermöglicht eine personalisierte Nutzung und oft auch die Verwaltung von Benutzerdaten. </li>
                <li>Interaktive Benutzerschnittstellen: Webplattformen bieten interaktive Benutzerschnittstellen, die es den Benutzern ermöglichen, mit der Plattform zu interagieren. Dies können Formulare, Dashboards, Chatfunktionen, Spiele oder andere Funktionen sein.</li>
                <li>Datenbanken und Inhaltsverwaltung: Webplattformen verwalten oft große Mengen von Daten, sei es Benutzerinformationen, Inhalte, Transaktionshistorien oder andere relevante Daten. Datenbanken spielen daher eine entscheidende Rolle. </li>
                <li>Kommunikation und soziale Interaktion: Viele Webplattformen fördern die Kommunikation und soziale Interaktion zwischen Benutzern. Dies kann in Form von sozialen Netzwerken, Foren, Chatrooms oder anderen Kommunikationskanälen geschehen. </li>
                <li>Dienste und Anwendungen: Webplattformen bieten verschiedene Dienste und Anwendungen an, je nach ihrem Zweck. Das können E-Commerce-Funktionen, Bildungsressourcen, Unterhaltungsangebote, Produktivitätstools und vieles mehr sein. </li>
            </ul>
            <div class="quelle">
                <a class="btn" href="https://de.wikipedia.org/wiki/Weblog " target="_blank">Quelle</a>
                <a class="btn" href="https://www.heise-homepages.de/online-shop-definition/ " target="_blank">Quelle</a>
            </div>
        </section>
        <section class="container" id="fachbegriff">
            <h2>11.4 Auszeichnungssprachen HTML, XML – Fachbegriff und Einsatzgebiet</h2>
            <h3>HTML: </h3>
            <p>HyperText Markup Language. HTML ist eine einheitliche textbasierte Auszeichnungssprache. Sie besteht aus einfachen Auszeichnungselementen (Tags). HTML ermöglicht die Interpretation, Anzeige und Verknüpfung von Webseiten in Browsern. HTML ist plattformunabhängig und kann mit allen Betriebssystemen und Browsern verwendet werden. </p>
            <h3>XML</h3>
            <p>Extensible Markup Language. Wird verwendet um Daten strukturiert in einer Textdatei darzustellen, die von Meschen und Computern ausgewertet werden kann. HTML basiert auf XML. Die Sprache wird oft zu Webentwicklung, z.B. Erstellen von Sitemaps (Datei in der Informationen zu Seiten, Videos etc. der Website und deren Relationen definiert sind),  oder zum Erstellen von dokumentorientierten Datenbanken verwendet.
            </p>
            <div class="quelle">
                <a class="btn" href="https://coupling.media/marketing-lexikon-glossar-fachbegriffe-einfach-erklaert/h/html/#:~:text=HTML%20(Abk.%3A%20HyperText%20Markup,die%20im%20Internet%20angewendet%20wird. " target="_blank">Quelle</a>
                <a class="btn" href="https://www.ionos.de/digitalguide/websites/web-entwicklung/was-ist-xml/#:~:text=Bei%20XML%20handelt%20es%20sich,Datenaustausch%20im%20Internet%20eingesetzt%20wird. " target="_blank">Quelle</a>
            </div>
        </section>
        <section class="container" id="wichtigsten">
            <h2>11.5 Kenntnisse über das HTML5-Grundgerüst mit den wichtigsten Bestandteilen</h2>
            <p>Hier ist das HTML5-Grundgerüst mit den wichtigsten Bestandteilen in kompakter Form:</p>
            <pre>
                <code class="language-html">
&lt;!DOCTYPE html&gt;
&lt;html lang="de"&gt;
&lt;head&gt;
&lt;meta charset="UTF-8"&gt;
&lt;meta name="viewport" content="width=device-width, initial-scale=1.0"&gt;
&lt;title&gt;Titel der Webseite&lt;/title&gt;
&lt;/head&gt;
&lt;body&gt;
&lt;!-- Inhalt der Webseite --&gt;
&lt;/body&gt;
&lt;/html&gt;
                </code>
            </pre>

        </section>
        <section class="container" id="metadaten">
            <h2>11.6 Fachbegriff Meta - Element / Metadaten</h2>
            <p>Metadaten werden im Kopf-Bereich eines HTML-Dokuments, also im <code>&lt;head&gt;</code>-Element, notiert. Hier sind einige Beispiele für verschiedene Metadaten-Schemata und ihre Bedeutung:</p>
            <div class="codeContainer">
        <pre class="codeBlock">
            <code class="language-html">
&lt;!-- Definiert die Zeichenkodierung für das HTML-Dokument --&gt;
&lt;meta charset="UTF-8"&gt;

&lt;!-- Gibt an, wie die Webseite auf verschiedenen Geräten dargestellt werden soll --&gt;
&lt;meta name="viewport" content="width=device-width, initial-scale=1.0"&gt;

&lt;!-- Beschreibung des Inhalts der Webseite für Suchmaschinen und die Anzeige in Suchergebnissen --&gt;
&lt;meta name="description" content="Beschreibung des Inhalts der Webseite"&gt;

&lt;!-- Stichwörter, die den Inhalt der Webseite beschreiben, für Suchmaschinenoptimierung --&gt;
&lt;meta name="keywords" content="Stichwörter, Themen, Webseite"&gt;

&lt;!-- Name des Autors oder der verantwortlichen Person für den Inhalt der Webseite --&gt;
&lt;meta name="author" content="Name des Autors"&gt;

&lt;!-- Urheberrechtsinformationen für die Webseite --&gt;
&lt;meta name="copyright" content="© 2023 Max Mustermann"&gt;

&lt;!-- Steuerung der Suchmaschinenroboter, wie die Seite indexiert und verfolgt werden soll --&gt;
&lt;meta name="robots" content="index, follow"&gt;

&lt;!-- Kontrolle über das Zwischenspeichern der Seite im Browser des Benutzers --&gt;
&lt;meta http-equiv="cache-control" content="no-cache"&gt;

&lt;!-- Definiert einen Zeitpunkt, wann die Seite aus dem Cache gelöscht werden soll --&gt;
&lt;meta http-equiv="expires" content="0"&gt;

&lt;!-- Automatische Weiterleitung zu einer neuen URL nach einer festgelegten Zeit --&gt;
&lt;meta http-equiv="refresh" content="5; URL= http://www.example.com/"&gt;
            </code>
        </pre>
            </div>
            <p>Metadaten verbessern vor allem die Durchsuchbarkeit des World Wide Webs bzw. einer einzelnen Website und ermöglichen spezielle Anweisungen für Suchmaschinenroboter.</p>
            <div class="quelle">
                <a class="btn" href="" target="_blank">Quelle</a>
            </div>
        </section>

        <section class="container" id="maßnahmen">
            <h2>11.7  Fachbegriff SEO und Maßnahmen</h2>
            <p>SEO (Search Engine Optimization) bezieht sich auf die Maßnahmen, die ergriffen werden, um die Sichtbarkeit einer Website in den organischen Suchergebnissen von Suchmaschinen zu verbessern. Zu den grundlegenden Maßnahmen gehören: </p>
            <ul class="left" style="list-style: decimal">
                <li><strong>Keyword-Recherche: </strong> Identifizierung relevanter Suchbegriffe.</li>
                <li><strong>On-Page-Optimierung: </strong>Optimierung von Meta-Tags, Inhalt und Ladezeit der Webseite. </li>
                <li><strong>Off-Page-Optimierung: </strong>Aufbau von Backlinks und Engagement in sozialen Medien. </li>
                <li><strong>Technische SEO: </strong>Gewährleistung der Indexierbarkeit und Behebung technischer Probleme. </li>
                <li><strong>Lokale SEO: </strong>Optimierung für lokale Suchanfragen. </li>
                <li><strong>Analyse und Monitoring: </strong>Verwendung von Tools zur Überwachung und Anpassung der Strategie. </li>
            </ul>
            <p>SEO ist ein kontinuierlicher Prozess, der dazu beiträgt, die Platzierung einer Website in den Suchergebnissen zu verbessern und mehr qualifizierte Besucher anzuziehen. </p>
            <div class="quelle">
                <a class="btn" href="https://de.wikipedia.org/wiki/Suchmaschinenoptimierung#:~:text=Suchmaschinenoptimierung%20%E2%80%93%20englisch%20search%20engine%20optimization,Benutzer%20einer%20Websuchmaschine%20zu%20erh%C3%B6hen." target="_blank">Quelle</a>
            </div>
        </section>

        <section class="container" id="einsatz">
            <h2>11.8 Fachbegriff Cascading StyleSheets und deren Einsatz</h2>
            <p>
                Cascading Style Sheets (CSS) sind entscheidend für modernes Webdesign und -entwicklung. Sie bieten eine leistungsfähige Sprache zur Gestaltung von Webseiten und erlauben es Entwicklern, das Aussehen (Styling) von Webdokumenten präzise zu steuern. CSS ermöglicht das Styling von Text, das Layout von Seiten, die Anpassung an verschiedene Displaygrößen (Responsive Webdesign), Animationen und Effekte. Stile können dabei direkt in HTML-Dokumente eingefügt, in einem separaten Dokument verlinkt oder in externen Dateien definiert werden, was Wiederverwendbarkeit und Wartbarkeit erhöht. Die Kaskadierung - also die Art, wie verschiedene Stildefinitionen zusammenfließen und Prioritäten gesetzt werden - gibt CSS seinen Namen und erlaubt eine feingranulare Kontrolle über das Erscheinungsbild einer Webseite.
            </p>
            <div class="quelle">
                <a class="btn" href="https://www.ionos.at/digitalguide/websites/webdesign/was-ist-css/ " target="_blank">Quelle</a>
            </div>
        </section>
        <section class="container" id="clientseitiges">
            <h2>11.9 Scripting (clientseitiges Scripting, serverseitiges Scripting)</h2>
            <p>Scripte werden durch einen Interpreter interpretiert/ausgeführt. </p>
            <p>Was ist clientseitiges Skripting? Was ist serverseitiges Skripting? </p>
            <p>Clientseitiges Skripting bedeutet einfach, das Skripts wie z. B. JavaScript auf dem Clientgerät ausgeführt werden – gewöhnlich in einem Browser. Alle Arten von Skripts können auf der Clientseite laufen, wenn sie in JavaScript geschrieben sind, weil JavaScript universell unterstützt wird. Andere Skriptsprachen können nur verwendet werden, wenn der Browser des Benutzers sie unterstützt.
                Beispiele: Javascript</p>
            <p>Serverseitige Skripts laufen auf dem Server, anstatt auf dem Client – oft, um dynamischen Inhalt als Reaktion auf Benutzeraktionen an Webseiten zu liefern. Serverseitige Skripts brauchen nicht in JavaScript geschrieben zu werden, weil der Server eine Vielzahl von Sprachen unterstützen kann.
                Beispiele: PHP, Python, Perl </p>

            <div class="quelle">
                <a class="btn" href="https://www.cloudflare.com/de-de/learning/serverless/glossary/client-side-vs-server-side/ " target="_blank">Quelle</a>
            </div>
        </section>
        <section class="container" id="webseiten">
            <h2>11.10 Software zum Erstellen und Betrachten von Webseiten (Code - Editoren, Web - Browser, FTP -
                Programme, Grafik&shy;programme, Serversoftware)</h2>
            <p>Für die Entwicklung und Betrachtung von Webseiten ist eine Reihe von Softwaretools essentiell. Dazu gehören Code-Editoren für das Erstellen von Webcode, Webbrowser zur Ansicht der entwickelten Seiten, FTP-Programme für den Dateitransfer zwischen lokalen Systemen und Webservern, Grafikprogramme zur Erstellung von Webgrafiken und Designelementen sowie Serversoftware zur Verwaltung und Bereitstellung von Webinhalten. Code-Editoren unterstützen die Entwicklung mit Funktionen wie Syntaxhervorhebung, während Browser die endgültige Darstellung prüfen. FTP-Programme erleichtern die Publikation von Webseiten, Grafikprogramme optimieren visuelle Inhalte, und Serversoftware ermöglicht das Hosting der Webseite.
            </p>
            <div class="quelle">
                <a class="btn" href="https://www.ionos.at/digitalguide/websites/web-entwicklung/code-editoren/" target="_blank">Quelle</a>
            </div>
        </section>
        <section class="container" id="cms">
            <h2>11.11 Fachbegriff CMS (Einsatzgebiet, notwendige Voraus&shy;setzungen, existierende Systeme am Markt)</h2>
            <p>
                Ein Content-Management-System (CMS) ermöglicht das gemeinsame Erstellen, Bearbeiten und Verwalten digitaler Inhalte für Websites, Apps und andere Medien. Es wird in verschiedenen Bereichen eingesetzt, darunter Webseitenverwaltung, Blogs, Unternehmenswebsites, E-Learning-Plattformen, Online-Shops und Nachrichtenportale. Für den Betrieb eines CMS sind bestimmte Voraussetzungen notwendig, wie Server & Hosting, eine Datenbank, ein Serverbetriebssystem, Programmiersprachen wie PHP, Datenbanksysteme wie MySQL, ausreichend Speicherplatz & Bandbreite, eventuell ein SSL-Zertifikat, Browser-Kompatibilität und eine solide Backup-Strategie. Bekannte CMS-Systeme am Markt sind WordPress, Joomla, Drupal, Magento, Shopify und Wix.
            </p>
            <div class="quelle">
                <a class="btn" href="https://www.ionos.at/digitalguide/hosting/cms/cms-vergleich/" target="_blank">Quelle</a>
                <a class="btn" href="https://de.wikipedia.org/wiki/Content-Management-System" target="_blank">Quelle</a>
            </div>
        </section>
        <section class="container" id="lifo">
            <h2>11.12 Unterschied LIFO/FIFO-Prinzip</h2>
            <h3>FIFO</h3>
            <p>FIFO(Maus, Tastatur) bezeichnet eine Warteschlange bei Computern, aus der das am längsten wartende Element als nächstes bearbeitet wird.[4] FIFO ist eine spezielle Art, Daten abzulegen und wieder abzurufen. Die Warteschlange (englisch queue) in der Informatik beruht auf dem FIFO-Prinzip. Elemente werden in genau der Reihenfolge abgerufen, in der sie zuvor abgelegt wurden. Auf der Ebene des Betriebssystems werden Datenverbindungen, die nach dem FIFO-Prinzip organisiert sind, Pipes genannt.
                <br>
                Ein praktischer Bereich in der Informatik, in dem ein FIFO zum Einsatz kommt, sind Controller, insbesondere die serielle Schnittstelle (RS232-Port) bei PCs. Der gepufferte Chip sorgt durch ein FIFO-Verfahren dafür, dass das erste an der seriellen Schnittstelle ankommende Byte als erstes durch Software im Rechner verarbeitet wird. Byte-Protokolle (wie etwa durch eine Maus) bleiben so für „Leser“ (Treiber) wie „Schreiber“ (Maus) linear äquivalent. Ebenso gilt dies für den Tastaturpuffer. </p>
            <h3>LIFO</h3>
            <p>"LIFO" (Programme) steht für "Last In, First Out" und bezieht sich auf eine Methode der Datenverwaltung und -zugriff in der Informationstechnologie. Es ist eine Art von Datenstruktur oder Datenverwaltungsschema, bei dem das zuletzt hinzugefügte Element als erstes entfernt wird. Dies steht im Gegensatz zu "FIFO" (First In, First Out), bei dem das zuerst hinzugefügte Element als erstes entfernt wird.
                <br>
                In der IT wird der Begriff "LIFO" häufig in Bezug auf Datenstrukturen wie Stapel (Stacks) verwendet. Ein Stapel ist eine abstrakte Datenstruktur, bei der Elemente aufeinander gestapelt werden und das zuletzt hinzugefügte Element als erstes entfernt wird. Dieses Prinzip wird oft in Algorithmen, Speicherverwaltung und anderen Anwendungen verwendet, bei denen die Reihenfolge, in der Elemente hinzugefügt und entfernt werden, wichtig ist.
                <br>
                Ein einfaches Beispiel für LIFO in der IT ist die Verwendung eines Stapels beim Aufrufen von Funktionen in der Programmierung. Jedes Mal, wenn eine Funktion aufgerufen wird, wird der Funktionsaufruf auf den Stapel gelegt. Wenn die Funktion abgeschlossen ist, wird sie vom Stapel entfernt. Dies erfolgt in umgekehrter Reihenfolge, in der die Funktionen aufgerufen wurden, was dem LIFO-Prinzip entspricht.  </p>
            <div class="quelle">
                <a class="btn" href="https://de.wikipedia.org/wiki/First_In_%E2%80%93_First_Out " target="_blank">Quelle</a>
            </div>
        </section>
        <section class="container" id="queue">
            <h2>11.13 Fachbegriffe Stack und Queue</h2>
            <h3>Stack</h3>
            <p>Ein Stack ist ein abstrakter Datentyp und dynamische Datenstruktur. Es ist eine der Listen, die dem LIFO Prinzip (Last In First Out) folgt, bei dem man zu jeder Zeit nur das oberste Element abrufen kann. </p>
            <h3>Queue</h3>
            <p>Eine Queue ist ein abstrakter Datentyp, der für die Zwischenspeicherung von Objekten in einer bestimmten Reihenfolge verwendet wird. Sie ist eine Liste, die dem FIFO Prinzip (First In First Out) folgt, bei dem immer der älteste Wert zuerst bearbeitet wird.</p>
            <p>Die häufigsten Operationen dieser Datentypen sind push (Neues Element wird dem Stack ganz oben hinzugefügt), pop (Oberstes Element wird entfernt und zurückgegeben) und peek (Liefert den Wert des obersten Elements aber entfernt es nicht).
            </p>

            <div class="quelle">
                <a class="btn" href="https://www.happycoders.eu/de/algorithmen/stack-vs-queue/ " target="_blank">Quelle</a>
                <a class="btn" href="https://www.studysmarter.de/schule/informatik/algorithmen-und-datenstrukturen/stack/ " target="_blank">Quelle</a>
                <a class="btn" href="https://www.studysmarter.de/schule/informatik/algorithmen-und-datenstrukturen/queue/" target="_blank">Quelle</a>
            </div>
        </section>
        <section class="container" id="userinterface">
            <h2>11.14 Fachbegriff Userinterface (Arten, Regeln für Entwurf, Gestaltungshilfen / Toolkits / Frameworks)</h2>
            <h3>Arten: </h3>
            <p>
                <strong>GUI: </strong>Grafische Benutzeroberfläche mit Elementen wie Schaltflächen und Menüs. <br>
                <strong>CLI: </strong>Textbasierte Benutzeroberfläche für Befehle. <br>
                <strong>VUI: </strong>Interaktion über gesprochene Sprache. <br>
                <strong>TUI: </strong>Touch-Benutzeroberfläche für Touchscreen-Geräte
            </p>
            <h3>Entwurfsregeln:  </h3>
            <ul class="left">
                <li>Benutzerzentrierter Entwurf</li>
                <li>Konsistenz</li>
                <li>Benutzerfreundlichkeit</li>
                <li>Feedback</li>
                <li>Barrierefreiheit</li>
            </ul>
            <h3>Gestaltungshilfen: </h3>
            <p>
                <strong>Bootstrap: </strong>Frontend-Framework für responsive Webseiten.<br>
                <strong>Material Design: </strong>Einheitliches Designsystem von Google.<br>
                <strong>React: </strong>JavaScript-Bibliothek für UI-Entwicklung.<br>
                <strong>Flutter: </strong>UI-Toolkit für plattformübergreifende mobile Apps.<br>
                <strong>jQuery UI: </strong>Sammlung von UI-Widgets für interaktive Webseiten.<br>
                Diese Tools helfen bei der Gestaltung und Implementierung ansprechender und benutzerfreundlicher Benutzeroberflächen.
            </p>

            <div class="quelle">
                <a class="btn" href="" target="_blank">Quelle</a>
            </div>
        </section>
        <section class="container" id="zeichencodierung">
            <h2>11.15 Fachbegriff Zeichencodierung (ASCII, ISO-Latin, Unicode, … – Unterschiede und Verwendung)</h2>
            <p>Zeichen werden zusammengefasst in einem Zeichensatz (character set). Dieser wird als codierter Zeichensatz (coded character set) bezeichnet, wenn jedem Zeichen eine Nummer zugeordnet wird: der Zeichencode (codepoint). Diese Zeichencodes werden im Computer durch ein oder mehrere Bytes repräsentiert.
                <br>
                Die Zeichencodierung (character encoding) ist der Schlüssel, der Zeichencodes in Bytes im Speicher des Computers umsetzt und Bytes wieder in Zeichencodes zurückverwandelt.
                <br>
                Die Zeichencodierung legt fest, wie ein bestimmtes Zeichen in Bits und Bytes abgebildet wird </p>
            <p>ASCII (American Standard Code for Information Interchange);
                <br>
                maximal 256 verschiedene Zeichen;
                <br>
                Dieser Zeichenvorrat reicht gerade für das lateinische Alphabet und einige zusätzliche Zeichen; </p>
            <h3>ISO-8859-1 / ISO-Latin </h3>
            <p>Sie verwenden die ASCII-Codetabelle für die Zeichen 0 bis 127 und definieren zusätzlich die Werte 160 bis 255. Sofern in diesem Bereich das gleiche Zeichen in verschiedenen Schriften vorkommt, überlappen sie sich zumeist
                <br>
                Der universale Code: Unicode = 149.186 Zeichen
                <br>
                ziemlich alle Zeichencodierungsprobleme dieser Welt gelöst
                <br>
                Unicode kennt zu jedem Zeichen dutzende definierte Eigenschaften. Ein Zeichen besitzt Informationen.
                <br>
                Beispielsweise werden arabische Schriftzeichen automatisch korrekt von rechts nach links geschrieben.
                <br>
                Ein Unicode Codepoint entspricht oft einem bestimmten Schriftzeichen oder Leerraum. Das muss aber nicht immer so sein. Einige Codepoints stellen Steuerzeichen dar, wie zum Beispiel U+0009 und U+000A für Tabulator und Zeilenvorschub. </p>
            <div class="quelle">
                <a class="btn" href="https://www.w3.org/International/questions/qa-what-is-encoding.de " target="_blank">Quelle</a>
                <a class="btn" href="https://wiki.selfhtml.org/wiki/Zeichencodierung " target="_blank">Quelle</a>
            </div>
        </section>
        <section class="container" id="iso">
            <h2>11.16 Standards ANSI, ISO, IEEE</h2>
            <p>Die Standards ANSI, ISO und IEEE sind bedeutende Organisationen, die Normen und Standards in verschiedenen Bereichen festlegen:</p>
            <h3> ANSI (American National Standards Institute): </h3>
            <p>ANSI ist eine private, gemeinnützige Organisation in den USA, die für die Koordinierung, Entwicklung und Veröffentlichung von Normen zuständig ist.
                <br>
                ANSI entwickelt und veröffentlicht Standards für eine Vielzahl von Branchen und Bereichen, darunter Informationstechnologie, Elektronik, Bauwesen, Gesundheitswesen, Luft- und Raumfahrt und viele mehr.
                <br>
                ANSI fungiert als nationale Mitgliedsorganisation in der Internationalen Organisation für Normung (ISO).
            </p>
            <h3>ISO (International Organization for Standardization):</h3>
            <p>Die ISO ist eine internationale Organisation mit Sitz in Genf, Schweiz, die weltweit Normen entwickelt und veröffentlicht.
                <br>
                ISO ist bekannt für die Entwicklung von international anerkannten Standards in verschiedenen Bereichen wie Qualitätsmanagement (ISO 9001), Umweltmanagement (ISO 14001), Informationssicherheit (ISO 27001) und vielem mehr.
                <br>
                Die ISO arbeitet mit nationalen Normungsinstituten in verschiedenen Ländern zusammen, darunter ANSI in den USA. </p>
            <h3>IEEE (Institute of Electrical and Electronics Engineers):</h3>
            <p>
                IEEE ist eine weltweite Berufsorganisation für Ingenieure in den Bereichen Elektrotechnik, Elektronik und verwandten Disziplinen.
                <br>
                Das IEEE entwickelt und veröffentlicht Standards für Elektro- und Informationstechnik, darunter Kommunikationsstandards, Netzwerkprotokolle, Computerhardwarestandards, Sicherheitsstandards und vieles mehr.
                <br>
                IEEE-Standards haben einen großen Einfluss auf die Technologiebranche und werden weltweit von Unternehmen, Regierungen und Organisationen verwendet.
            </p>
            <p>Diese Organisationen spielen eine entscheidende Rolle bei der Entwicklung und Veröffentlichung von Normen und Standards, die die Interoperabilität, Qualität, Sicherheit und Effizienz von Produkten, Dienstleistungen und Systemen verbessern sollen. </p>
            <div class="quelle">
                <a class="btn" href="https://ger.myservername.com/what-is-sei-cmm-iso" target="_blank">Quelle</a>
            </div>
        </section>
        <section class="container" id="frame">
            <h2>11.17 Fachbegriff Frame</h2>
            <p><strong>Webentwicklung: </strong>In der Webentwicklung bezieht sich ein Frame auf ein Element innerhalb eines Web-Browsers, das es ermöglicht, den Inhalt einer Webseite in separate Abschnitte zu unterteilen, von denen jeder unabhängig laden und anzeigen kann. Frames werden mittels des &lt;frameset&gt; Tags in HTML definiert, sind aber aus Gründen der Benutzerfreundlichkeit und Webstandards weitgehend durch CSS und JavaScript-Funktionen ersetzt worden. </p>
            <p><strong>Netzwerke: </strong>In der Netzwerktechnik bezeichnet ein Frame eine Datenübertragungseinheit, die aus Datenpaketen und den dazugehörigen Steuerinformationen besteht. Frames werden in LANs (Local Area Networks) verwendet, insbesondere in der Ethernet-Technologie, und ermöglichen es, Daten zwischen Netzwerkgeräten zu transportieren. </p>
            <p><strong>Multimedia: </strong>In der Videotechnik und Animation bezeichnet ein Frame ein einzelnes Bild in einer Serie von Bildern, die zusammen eine Bewegung oder eine Sequenz bilden.
            </p>

            <div class="quelle">
                <a class="btn" href="https://de.wikipedia.org/wiki/Frame_(HTML) " target="_blank">Quelle</a>
                <a class="btn" href="https://www.informatik-verstehen.de/lexikon/frame/#:~:text=Der%20englische%20Begriff%20Frame%20steht,HTML%2DInhalte%20angezeigt%20werden%20k%C3%B6nnen " target="_blank">Quelle</a>
            </div>
        </section>
        <section class="container" id="heterogene">
            <h2>11.18 Fachbegriff Webservices (verteiltes System für heterogene Systeme, …)</h2>
            <p>Ein Webservice stellt einen Dienst über das Internet zur Verfügung. Er ist somit eine Schnittstelle, über die zwei Maschinen (oder Anwendungen) miteinander kommunizieren können. Dabei sind zwei Eigenschaften für die Technik entscheidend: </p>
            <ul class="left">
                <li><strong>Plattformunabhängig: </strong>Client und Server müssen nicht die gleichen Konfigurationen haben, damit sie miteinander kommunizieren können. Der Webservice sorgt für eine gemeinsame Ebene</li>
                <li><strong>Verteilt: </strong>Ein Webservice steht in den meisten Fällen nicht nur einem Client zur Verfügung. Über das Internet greifen unterschiedliche Clients auf den Dienst zu. </li>
            </ul>
            <p>Kommt ein Webservice zum Einsatz, sendet ein Client eine Anfrage an einen Server und löst damit eine Aktion bei diesem Server aus. Anschließend sendet der Server eine Antwort zurück an den Client. </p>
            <h3>Die Technik hinter einem Webservice – am Beispiel erklärt </h3>
            <p>Ein Webservice wird über einen eindeutigen Uniform Resource Identifier (URI) angesprochen. Ähnlich wie ein Uniform Resource Locator (URL), mit dem man Websites ansprechen kann, ist der URI eine Adresse für den entsprechenden Webservice. Theoretisch spielt auch der Verzeichnisdienst UDDI eine Rolle, über den sich Webservices finden lassen. Dieser Dienst hat sich allerdings nie durchgesetzt und die größten Unterstützer haben sich aus dem Projekt zurückgezogen.</p>
            <p>Wichtiger ist allerdings die Sprache Web Service Description Language (WSDL): Ein Webservice besitzt eine Datei in WSDL, in der der Dienst näher beschrieben wird. Der Client kann über die Information verstehen, was für Funktionen er am Server über den Webservice ausführen kann. Die Kommunikation funktioniert schließlich über verschiedene Protokolle und Architekturen. Beliebt sind z. B. das Netzwerkprotokoll SOAP in Kombination mit dem Internetstandard HTTP oder auch RESTful Webservices. Mit diesen Techniken werden Anfragen und Antworten hin und her gesendet.</p>
            <p>Oftmals funktioniert die Kommunikation mit der Extensible Markup Language (XML). Die relativ simple Sprache kann von Menschen und Computern gleichermaßen verstanden werden und ist bestens dazu geeignet, Systeme mit unterschiedlichen Voraussetzungen miteinander zu verbinden. Doch REST lässt auch andere Formate wie JSON zu.</p>
            <p>Zur Verdeutlichung ein Webservice-Beispiel: Gehen wir von einer Software aus, die in Visual Basic geschrieben wurde und auf einer Windows-Maschine läuft. Das Programm benötigt den Dienst eines Apache Webservers. Dafür sendet der Client eine SOAP-Anfrage in Form einer HTTP-Nachricht an den Server. Der Webservice interpretiert den Inhalt der Anfrage</p>
            <p>und sorgt dafür, dass der Server eine Aktion durchführt. Nach Ausführung formuliert der Webservice eine Antwort und sendet diese – wieder mit SOAP und HTTP – an den Client zurück. Dort wird die Antwort wiederum interpretiert und die Informationen gelangen in die Software, wo sie weiterverarbeitet werden. </p>
            <div class="quelle">
                <a class="btn" href="https://www.ionos.at/digitalguide/websites/web-entwicklung/webservice/ " target="_blank">Quelle</a>
            </div>
        </section>
        <section class="container" id="standards">
            <h2>11.19 Kenntnisse über Standards (SOAP, WSDL, …) </h2>
            <h3>SOAP (Simple Object Access Protocol): </h3>
            <p><strong>Beschreibung: </strong>SOAP ist ein Protokoll zum Austausch strukturierter Informationen in Webdiensten. Es ermöglicht die Kommunikation zwischen Anwendungen über das Internet oder ein Intranet. </p>
            <p><strong>Struktur: </strong>SOAP definiert einen Satz von Regeln für die Strukturierung von Nachrichten. Diese Nachrichten können in verschiedenen Formaten wie XML codiert werden. </p>
            <p><strong>Transport: </strong>SOAP kann über verschiedene Transportprotokolle wie HTTP, SMTP oder andere übertragen werden. </p>
            <p><strong>Verwendung: </strong>Es wird häufig in Kombination mit anderen Webdiensttechnologien wie WSDL und UDDI verwendet, um die Interoperabilität zwischen verschiedenen Systemen zu gewährleisten. </p>
            <h3>WSDL (Web Services Description Language): </h3>
            <p><strong>Beschreibung: </strong>WSDL ist eine XML-basierte Beschreibungssprache für Webdienste. Sie wird verwendet, um die Schnittstelle eines Webdienstes zu beschreiben, einschließlich der angebotenen Operationen und der Nachrichtenformate.
            </p>
            <p><strong>Port Type: </strong>Definiert eine Sammlung von Operationen, die von einem Webdienst unterstützt werden. </p>
            <p><strong>Binding: </strong>Verknüpft ein Port Type mit einem bestimmten Netzwerkprotokoll und Datenformat (wie SOAP).</p>
            <p><strong>Service: </strong>Definiert eine Sammlung von Netzwerkendpunkten oder Ports.</p>
            <p><strong>Verwendung: </strong>WSDL wird von Entwicklern und Tools verwendet, um auf einen Blick zu verstehen, wie ein bestimmter Webdienst aufgebaut ist und wie er genutzt werden kann. </p>
            <div class="quelle">
                <a class="btn" href="https://www.ibm.com/docs/de/radfws/9.6.1?topic=overview-web-services-standards" target="_blank">Quelle</a>
            </div>
        </section>
        <section class="container" id="api">
            <h2>11.20 Fachbegriff Rest API</h2>
            <p>
                REST- (Representational State Transfer) bzw. RESTful-API ist ein Application-Program-Interface-Typ (API-Typ), der webbasierte Apps in der Kommunikation miteinander unterstützt.
                <br>
                Obwohl die API theoretisch mit jedem Protokoll oder Datenformat kompatibel ist, verwendet REST in den meisten Fällen das HTTP-Protokoll und überträgt die Daten mithilfe von JSON (JavaScript Object Notation).
                <br>
                Die REST-API ist aufgrund ihrer Flexibilität, Schnelligkeit und Einfachheit eine der beliebtesten Varianten, um Daten aus dem Internet zu bekommen.
            </p>
            <div class="quelle">
                <a class="btn" href="https://www.talend.com/de/resources/was-ist-rest-api/#:~:text=REST%2D%20(Representational%20State%20Transfer),in%20der%20Kommunikation%20miteinander%20unterst%C3%BCtzt. " target="_blank">Quelle</a>
            </div>
        </section>
        <div class="center">
            <a class="btn" href="fachberatungPlanung.php">Zurück zu Fachberatung, Planung</a>
            <a class="btn" href="InformatikTeil2.php">Weiter zu Informatik Teil 2</a>
        </div>
    </article>
</main>
<?php include'include/footer.php' ?>