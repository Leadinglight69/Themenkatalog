<?php
$title = 'Ergonomische Arbeitsplatzgestaltung | Leitfaden für gesundes Arbeiten';
$description = 'Erfahren Sie, wie Sie Ihren Arbeitsplatz ergonomisch gestalten können, um die Gesundheit und Produktivität zu fördern. Unser umfassender Guide bietet Einblicke in die ergonomische Einrichtung von Bildschirmarbeitsplätzen, optimale Bildschirmpositionierung, gesetzliche Pausenbestimmungen, ideale Höhenanpassungen für Tisch und Bildschirm sowie Schutzmaßnahmen gegen körperliche Schäden bei sitzender Tätigkeit und empfohlene Entspannungsübungen.';
$keywords = 'ergonomische Arbeitsplatzgestaltung, Bildschirmarbeitsplatz, gesetzliche Pausen, ergonomisches Sitzen, Entspannungsübungen, Schutzmaßnahmen sitzende Tätigkeit, Bildschirmpositionierung';
$canonical = 'https://www.codeabschlussguide.at/ergonomische-arbeitsplatzgestaltung';
include 'include/header.php'
?>
<main class="responsive">
  <section>
    <h1>9) Ergonomische Gestaltung eines Arbeitsplatzes</h1>
    <ul class="listLegend"  style="list-style: none">
      <li><a href="#bildschirmarbeitsplatzes">9.1 Kenntnisse über die ergonomische Einrichtung eines Bildschirm&shy;arbeitsplatzes</a></li>
      <li><a href="#bildschirmen">9.2 Kenntnisse über den optimalen Aufstellungsort von Bildschirmen (Lichteinfall)</a></li>
      <li><a href="#bildschirmarbeit">9.3 Kenntnisse der gesetzlichen Bestimmungen von Pausen bei Bildschirmarbeit</a></li>
      <li><a href="#benutzer">9.4 Kenntnisse über die ideale Höhe von Tisch / Tastatur, Bildschirm&shy;oberkante und Bildschirma&shy;bstand zum Benutzer</a></li>
      <li><a href="#sitzender">9.5 Kenntnisse über Schutzmaßnahmen zur Vorbeugung körperlicher Schäden bei sitzender Tätigkeit</a></li>
      <li><a href="#tätigkeit">9.6 Kenntnisse über körperliche Entspannungs&shy;übungen bei sitzender Tätigkeit</a></li>
    </ul>
    <aside class="floatingNav">
      <div class="floatingDot" data-section="#bildschirmarbeitsplatzes"><span class="floatingText">9.1 </span></div>
      <div class="floatingDot" data-section="#bildschirmen"><span class="floatingText">9.2 </span></div>
      <div class="floatingDot" data-section="#bildschirmarbeit"><span class="floatingText">9.3 </span></div>
      <div class="floatingDot" data-section="#benutzer"><span class="floatingText">9.4 </span></div>
      <div class="floatingDot" data-section="#sitzender"><span class="floatingText">9.5 </span></div>
      <div class="floatingDot" data-section="#tätigkeit"><span class="floatingText">9.6 </span></div>
    </aside>
  </section>

  <article>
    <section class="container" id="bildschirmarbeitsplatzes">
      <h2>9.1 Kenntnisse über die ergonomische Einrichtung eines Bildschirm&shy;arbeitsplatzes</h2>
      <h3>Bildschirmpositionierung</h3>
      <ul class="left">
        <li>Der Bildschirm sollte etwa eine Armlänge entfernt sein, mit der oberen Kante auf oder leicht unter Augenhöhe, damit der Blick leicht nach unten gerichtet ist. </li>
        <li>Vermeide Blendung durch direktes Licht auf dem Bildschirm, indem du den Arbeitsplatz richtig ausrichtest oder Blendschutzfilter verwendest. </li>
      </ul>
      <h3>Sitzhaltung</h3>
      <ul class="left">
        <li>Nutze einen verstellbaren Stuhl, der eine gute Lendenwirbelstütze bietet. Deine Füße sollten flach auf dem Boden stehen können, und deine Knie sollten etwa auf Höhe mit deinen Hüften sein. </li>
        <li>Halte deine Arme in einem Winkel von etwa 90 Grad zum Schreibtisch. </li>
      </ul>
      <h3>Tastatur und Maus</h3>
      <ul class="left">
        <li>Positioniere die Tastatur und die Maus so, dass deine Hände und Handgelenke in einer natürlichen Position bleiben, ohne dass du sie verdrehen musst. </li>
        <li>Verwende gegebenenfalls Handgelenkauflagen, um den Druck auf die Handgelenke zu minimieren. </li>
      </ul>
      <h3>Pausen und Bewegung </h3>
      <ul class="left">
        <li>Mache regelmäßige Pausen, um aufzustehen, dich zu strecken und die Augen zu entspannen. Die 20-20-20-Regel kann helfen: Schaue alle 20 Minuten für 20 Sekunden auf etwas, das 20 Fuß (etwa 6 Meter) entfernt ist. </li>
        <li>Wechsle häufig deine Sitzposition, um nicht zu lange in einer Haltung zu verharren. </li>
      </ul>
      <h3> Beleuchtung und Raumgestaltung </h3>
      <ul class="left">
        <li>Sorge für eine angemessene Beleuchtung, die weder zu hell noch zu dunkel ist, um Augenanstrengung zu vermeiden. </li>
        <li>Halte den Arbeitsbereich aufgeräumt und frei von Unordnung, um eine angenehme Arbeitsumgebung zu schaffen. </li>
      </ul>

      <div class="quelle">
        <a class="btn" href="https://www.arbeitsinspektion.gv.at/Arbeitsstaetten-_Arbeitsplaetze/Ergonomie/Bildschirmarbeitsplaetze.html" target="_blank">Quelle</a>
      </div>
    </section>

    <section class="container" id="bildschirmen">
      <h2>9.2 Kenntnisse über den optimalen Aufstellungsort von Bildschirmen (Lichteinfall)</h2>
      <p>Die optimale Positionierung des Bildschirms hinsichtlich des Lichteinfalls ist wichtig, um Blendung zu vermeiden und die Sicht zu verbessern. Der Bildschirm sollte so aufgestellt werden, dass direktes Licht von Fenstern nicht darauf fällt, idealerweise parallel zu den Fenstern oder mit Verwendung von Blendschutzvorrichtungen. Der empfohlene Abstand zwischen Augen und Monitor liegt zwischen 45 und 80 cm, abhängig von der Bildschirmgröße, wobei größere Bildschirme einen größeren Abstand erfordern können. Die richtige Positionierung zusammen mit der Vermeidung von Flüssigkeiten in der Nähe des Geräts trägt zur Langlebigkeit bei.</p>

      <div class="quelle">
        <a class="btn" href="https://www.akademie-sport-gesundheit.de/magazin/arbeitsplatzergonomie-so-stellen-sie-ihren-monitor-richtig-auf.html#:~:text=Idealerweise%20wird%20der%20Bildschirm%20seitlich,einer%20%C3%9Cberanstrengung%20der%20Augen%20f%C3%BChren." target="_blank">Quelle</a>
      </div>
    </section>
    <section class="container" id="bildschirmarbeit">
      <h2>9.3 Kenntnisse der gesetzlichen Bestimmungen von Pausen bei Bildschirmarbeit</h2>
      <p>Für Bildschirmarbeit in Österreich sind gemäß den gesetzlichen Bestimmungen Pausen sicherzustellen:</p>
      <ul class="left">
        <li>Pausen oder Tätigkeitswechsel: Nach 50 Minuten ununterbrochener Bildschirmarbeit sind 10 Minuten Pause vorgesehen. Alternativ sind 20 Minuten Pause nach der zweiten Arbeitsstunde möglich, abhängig vom Arbeitsablauf.</li>
        <li>Augenuntersuchungen: Vor Arbeitsbeginn und danach alle drei Jahre müssen Untersuchungen des Sehvermögens angeboten werden. Bei Sehbeschwerden durch Bildschirmarbeit sind zusätzliche Untersuchungen erforderlich.</li>
        <li>Sehhilfen: Falls nötig, müssen spezielle Sehhilfen für Bildschirmarbeit zur Verfügung gestellt werden.</li>
      </ul>
      <p>Diese Maßnahmen sollen die Gesundheit der Beschäftigten schützen und die Belastung durch lange Bildschirmzeiten reduzieren.</p>
      <div class="quelle">
        <a class="btn" href="https://www.tk.de/techniker/magazin/sport/gesunder-ruecken/ruecken-monitor-richtig-aufstellen-2009242?tkcm=aaus " target="_blank">Quelle</a>
      </div>
    </section>
    <section class="container" id="benutzer">
      <h2>9.4 Kenntnisse über die ideale Höhe von Tisch / Tastatur, Bildschirm&shy;oberkante und Bildschirma&shy;bstand zum Benutzer</h2>
      <picture>
        <source srcset="/img/GesundAmSchreibtischArbeiten.avif" title="GesundAmSchreibtischArbeiten" type="image/avif">
        <img src="/img/GesundAmSchreibtischArbeiten.jpg" title="GesundAmSchreibtischArbeiten" alt="Beschreibung des Bildinhalts" width="1000" loading="lazy">
      </picture>
      <span class="bildQuelle"><a href="https://ratgeber.bueromoebel-experte.de/ergonomie-ratgeber/ergonomie-am-arbeitsplatz/" target="_blank">Bild Quelle</a></span>
      <p>Um einen ergonomischen Bildschirmarbeitsplatz zu schaffen, beachten Sie folgende Punkte:</p>
      <ul class="left">
        <li><strong>Schreibtischhöhe: </strong>Anpassbar an den Nutzer, idealerweise mit elektrisch verstellbaren Modellen für stehende und sitzende Positionen.</li>
        <li><strong>Tastatur: </strong>Sollte auf einer Höhe sein, die es ermöglicht, die Unterarme parallel zum Boden zu halten.</li>
        <li><strong>Bildschirmoberkante: </strong>Auf oder leicht unter Augenhöhe, um den Kopf und Nacken in einer neutralen Position zu halten.</li>
        <li><strong>Bildschirmabstand: </strong>Optimal ist eine Armlänge entfernt, abhängig von der Bildschirmgröße und persönlichem Sehkomfort.</li>
      </ul>
      <p>Diese Anpassungen fördern eine gesunde Körperhaltung und können das Risiko von Belastungsschäden verringern.</p>
      <div class="quelle">
        <a class="btn" href="https://ratgeber.bueromoebel-experte.de/ergonomie-ratgeber/ergonomie-am-arbeitsplatz/" target="_blank">Quelle</a>
      </div>
    </section>
    <section class="container" id="sitzender">
      <h2>9.5 Kenntnisse über Schutzmaßnahmen zur Vorbeugung körperlicher Schäden bei sitzender Tätigkeit</h2>
      <p>Zur Vorbeugung körperlicher Schäden bei sitzender Tätigkeit sollten folgende Schutzmaßnahmen beachtet werden:</p>
      <ul class="left">
        <li>Ergonomische Einrichtung des Arbeitsplatzes mit anpassbarer Tisch- und Sitzhöhe.</li>
        <li>Regelmäßige Pausen und Tätigkeitswechsel, um Muskelverspannungen und Augenbelastungen zu vermeiden.
        </li>
        <li>Einrichtung des Bildschirms und der Arbeitsmittel zur Förderung einer natürlichen Körperhaltung.</li>
        <li>Bewegungsfördernde Maßnahmen wie Steharbeitsplätze oder die Integration kurzer Bewegungsübungen in den Arbeitsalltag.</li>
      </ul>
      <p>Diese Maßnahmen unterstützen eine gesunde Arbeitsweise und tragen zur Prävention von berufsbedingten Erkrankungen bei.</p>
      <div class="quelle">
        <a class="btn" href="https://www.gesundheit.gv.at/leben/lebenswelt/beruf/arbeitsplatz/ergonomie-am-arbeitsplatz.html" target="_blank">Quelle</a>
      </div>
    </section>
    <section class="container" id="tätigkeit">
      <h2>9.6 Kenntnisse über körperliche Entspannungs&shy;übungen bei sitzender Tätigkeit</h2>
      <p>Man sollte sich regelmäßig strecken, um die Muskeln zu entspannen. Man sollte öfter über den Bildschirm schauen, um den Augen Abwechslung zu dem Bildschirm zu geben. Man sollte auch, wenn man die Möglichkeit, hat im Stehen arbeiten. Also mit einem höhenverstellbaren Tisch. </p>
      <h3>Wie bringe ich Bewegung in den Arbeitsalltag? </h3>
      <p>Bei einem sitzenden Beruf sollte so viel Bewegung wie möglich in den Arbeitsalltag eingebaut werden, um Beschwerden vorzubeugen. Das beginnt beim dynamischen Sitzen, bei dem so oft wie möglich die Sitzposition variiert wird. Abwechslung bieten auch selbstverständliche, aber etwas anstrengendere Alltagsbewegungen wie: </p>
      <ul class="left">
        <li>Kolleginnen und Kollegen im anderen Büro besuchen, statt ein E-Mail zu schicken oder anzurufen </li>
        <li>Telefonate im Stehen erledigen, Stehtische für Besprechungen nutzen </li>
        <li>Treppen steigen statt mit dem Aufzug fahren oder die Rolltreppe nehmen, </li>
        <li>Arbeitswege und Besorgungen zu Fuß oder mit dem Rad erledigen statt mit dem Auto bzw. </li>
        <li>Die Mittagspause für einen kurzen Spaziergang nutzen. </li>
        <li>Einseitige Haltungen am Arbeitsplatz können durch tägliche Ausgleichsübungen aufgelockert werden. Übungsbeispiele für die gesunde Bewegungsdosis zwischendurch finden Sie unter: Arbeiterkammer Wellnesstipp: Die 12 Bildschirmtibeter </li>
      </ul>
      
      <div class="quelle">
        <a class="btn" href="https://www.gesundheit.gv.at/leben/lebenswelt/beruf/arbeitsplatzgestaltung/sitzender-beruf.html" target="_blank">Quelle</a>
      </div>
    </section>
      <div class="center">
          <a class="btn" href="informatikUndGesellschaft.php">Zurück zu Informatik und Gesellschaft</a>
          <a class="btn" href="fachberatungPlanung.php">Weiter zu Fachberatung, Planung</a>
      </div>
  </article>
</main>
<?php include 'include/footer.php'; ?>