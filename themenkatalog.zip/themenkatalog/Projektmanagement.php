<?php
$title = 'Projektmanagement: Grundlagen, Planung und Werkzeuge';
$description = 'Erfahren Sie alles über Projektmanagement, von der Definition und Planung von Projekten, über die Erstellung von Pflichten- und Lastenheften, bis hin zu Methoden zur Bewältigung von Spannungsfeldern und zum Umgang mit internen und externen Projekten. Entdecken Sie die Rollen und Aufgaben eines Projektleiters, die Bedeutung von Projektstrukturplänen, Arbeitspaketen, und Meilensteinen, sowie die Grundlagen der Projektkostenplanung.';
$keywords = 'Projektmanagement, Projektplanung, Pflichtenheft, Lastenheft, Projektleiter, Projektorganisation, Projektdokumentation, Struktogramm, Ablaufdiagramm, Projektstrukturplan, Arbeitspaket, Meilenstein, Projektkostenplanung';
$canonical = 'https://www.codeabschlussguide.de/fachberatung-planung';
include 'include/header.php'
?>
<main class="responsive">
    <section>
        <h1>12) Fachberatung, Planung</h1>
        <ul class="listLegend"  style="list-style: none">
            <li><a href="#projektmanagement">12.1 Fachbegriff Projektmanagement</a></li>
            <li><a href="#projekten">12.2 Definition von Projekten</a></li>
            <li><a href="#notwendiger">12.3 Fachbegriff Pflichtenheft und notwendiger Inhalt</a></li>
            <li><a href="#lastenheft">12.4 Fachbegriff Lastenheft und notwendiger Inhalt</a></li>
            <li><a href="#spannungsfelder">12.5 Kenntnisse über Spannungsfelder in einem Projekt</a></li>
            <li><a href="#projektziel">12.6 Kenntnisse über den Fachbegriff Primäres Projektziel</a></li>
            <li><a href="#projektorganisation">12.7 Kenntnisse über Vor- und Nachteile einer Projekt&shy;organisation</a></li>
            <li><a href="#einerProjektdokumentation">12.8 Ziel einer Projekt&shy;dokumentation</a></li>
            <li><a href="#struktogramm">12.9 Fachbegriff Struktogramm</a></li>
            <li><a href="#ablaufdiagramm">12.10 Fachbegriff Ablaufdiagramm (Flowchart)</a></li>
            <li><a href="#wesentliche">12.11 Kenntnisse über wesentliche Schritte einer Projektplanung</a></li>
            <li><a href="#eigenschaften">12.12 Kenntnisse über Eigenschaften eines Projektleiters</a></li>
            <li><a href="#projektleiters">12.13 Aufgaben eines Projektleiters</a></li>
            <li><a href="#dokumentationen">12.14 Kenntnisse über Dokumentationen eines Projektes</a></li>
            <li><a href="#projektauftrag">12.15 Fachbegriff Projektauftrag</a></li>
            <li><a href="#projektstrukturplan">12.16 Fachbegriff Projektstrukturplan</a></li>
            <li><a href="#arbeitspaket">12.17 Fachbegriff Arbeitspaket</a></li>
            <li><a href="#meilenstein">12.18 Fachbegriff Meilenstein</a></li>
            <li><a href="#externesProjekt">12.19 Unterschiede internes/externes Projekt</a></li>
            <li><a href="#projektkostenplanung">12.20 Kenntnis Projektkostenplanung</a></li>
        </ul>
        <aside class="floatingNav">
            <div class="floatingDot" data-section="#projektmanagement"><span class="floatingText">12.1 </span></div>
            <div class="floatingDot" data-section="#projekten"><span class="floatingText">12.2 </span></div>
            <div class="floatingDot" data-section="#notwendiger"><span class="floatingText">12.3 </span></div>
            <div class="floatingDot" data-section="#lastenheft"><span class="floatingText">12.4 </span></div>
            <div class="floatingDot" data-section="#spannungsfelder"><span class="floatingText">12.5 </span></div>
            <div class="floatingDot" data-section="#projektziel"><span class="floatingText">12.6 </span></div>
            <div class="floatingDot" data-section="#projektorganisation"><span class="floatingText">12.7 </span></div>
            <div class="floatingDot" data-section="#einerProjektdokumentation"><span class="floatingText">12.8 </span></div>
            <div class="floatingDot" data-section="#struktogramm"><span class="floatingText">12.9 </span></div>
            <div class="floatingDot" data-section="#ablaufdiagramm"><span class="floatingText">12.10 </span></div>
            <div class="floatingDot" data-section="#wesentliche"><span class="floatingText">12.11 </span></div>
            <div class="floatingDot" data-section="#eigenschaften"><span class="floatingText">12.12 </span></div>
            <div class="floatingDot" data-section="#projektleiters"><span class="floatingText">12.13 </span></div>
            <div class="floatingDot" data-section="#dokumentationen"><span class="floatingText">12.14 </span></div>
            <div class="floatingDot" data-section="#projektauftrag"><span class="floatingText">12.15 </span></div>
            <div class="floatingDot" data-section="#projektstrukturplan"><span class="floatingText">12.16 </span></div>
            <div class="floatingDot" data-section="#arbeitspaket"><span class="floatingText">12.17 </span></div>
            <div class="floatingDot" data-section="#meilenstein"><span class="floatingText">12.18 </span></div>
            <div class="floatingDot" data-section="#externesProjekt"><span class="floatingText">12.19 </span></div>
            <div class="floatingDot" data-section="#projektkostenplanung"><span class="floatingText">12.20 </span></div>
        </aside>
    </section>

    <article>
        <section class="container" id="projektmanagement">
            <h2>12.1 Fachbegriff Projekt&shy;management</h2>
            <p>Der Fachbegriff "Projektmanagement" bezeichnet die Disziplin der Planung, Organisation, Steuerung und Überwachung von Projekten, um deren Ziele erfolgreich zu erreichen. Hier sind einige grundlegende Aspekte des Projektmanagements: </p>
            <ul class="left" style="list-style: decimal">
                <li><strong>Planung: </strong>Projektmanagement beginnt mit der Planung, bei der Ziele, Umfang, Zeitplan, Ressourcenbedarf, Budget und Risiken des Projekts definiert werden. Ein Projektplan wird erstellt, der als Leitfaden für die Durchführung des Projekts dient. </li>
                <li><strong>Organisation: </strong>In dieser Phase werden die Projektteams zusammengestellt und die Verantwortlichkeiten und Rollen der Teammitglieder festgelegt. Die Organisationsstruktur wird definiert, um effiziente Kommunikation und Zusammenarbeit zu ermöglichen. </li>
                <li><strong>Steuerung: </strong>Während des Projekts werden Fortschritt, Kosten, Qualität und Risiken überwacht und gesteuert, um sicherzustellen, dass das Projekt im Rahmen des Plans bleibt. Anpassungen werden vorgenommen, um Abweichungen zu korrigieren und das Projekt auf Kurs zu halten. </li>
                <li><strong>Überwachung: </strong>Die Überwachung umfasst die regelmäßige Überprüfung des Projektstatus und die Verfolgung von Meilensteinen und Leistungsindikatoren. Dies ermöglicht es, Probleme frühzeitig zu erkennen und entsprechend zu reagieren. </li>
                <li><strong>Kommunikation: </strong>Eine effektive Kommunikation ist entscheidend für den Erfolg eines Projekts. Projektmanager sind dafür verantwortlich, sicherzustellen, dass alle Stakeholder angemessen informiert werden und dass eine klare und offene Kommunikation innerhalb des Teams stattfindet. </li>
                <li><strong>Risikomanagement: </strong>Projekte sind mit Unsicherheiten und Risiken verbunden. Das Risikomanagement umfasst die Identifizierung, Bewertung, Priorisierung und Bewältigung von Risiken, um deren Auswirkungen auf das Projekt zu minimieren. </li>
                <li><strong>Abschluss: </strong>Nach Abschluss des Projekts werden die Ergebnisse überprüft und abgenommen. Ein Abschlussbericht wird erstellt, der Erfahrungen und Erkenntnisse aus dem Projekt dokumentiert und für zukünftige Projekte genutzt werden kann. </li>
            </ul>
            <p>Projektmanagementmethoden wie Wasserfall, Agile, Scrum und Kanban bieten verschiedene Ansätze und Tools für die Durchführung von Projekten, abhängig von den Anforderungen und der Natur des Projekts. In jedem Fall ist ein effektives Projektmanagement entscheidend für die erfolgreiche Umsetzung von Projekten innerhalb von Zeit, Budget und Qualität. </p>
            <div class="quelle">
                <a class="btn" href="https://de.wikipedia.org/wiki/Projektmanagement" target="_blank">Quelle</a>
            </div>
        </section>
        <section class="container" id="projekten">
            <h2>12.2 Definition von Projekten</h2>
            <p>Ein Projekt darf jeder auf seine Weise und mit verschiedenen Schwerpunkten definieren.</p>
            <p> Ein Projekt ist ein Vorhaben, das im Wesentlichen durch Einmaligkeit der Bedingungen in ihrer Gesamtheit gekennzeichnet ist, wie z. B.: Zielvorgabe, zeitliche, finanzielle, personelle oder andere Bedingungen, Abgrenzungen gegenüber anderen Vorhaben und projektspezifische Organisation </p>
            <div class="quelle">
                <a class="btn" href="https://t2informatik.de/wissen-kompakt/projekt/" target="_blank">Quelle</a>
            </div>
        </section>
        <section class="container" id="notwendiger">
            <h2>12.3 Fachbegriff Pflichtenheft und notwendiger Inhalt</h2>
            <p>Das Pflichtenheft ist ein Dokument im Projektmanagement, das die Anforderungen und Spezifikationen eines Projekts festlegt. Es dient als formelle Grundlage für die Planung, Durchführung und Überwachung des Projekts. Der notwendige Inhalt eines Pflichtenhefts kann je nach Art des Projekts variieren, aber im Allgemeinen umfasst es folgende Informationen: </p>
            <ul class="left">
                <li><strong>Einleitung: </strong>Eine kurze Einführung, die den Zweck des Pflichtenhefts erklärt und die beteiligten Parteien identifiziert. </li>
                <li><strong>Projektbeschreibung: </strong>Eine allgemeine Beschreibung des Projekts, einschließlich des Ziels, des Umfangs, der Ziele und der Hauptmerkmale. </li>
                <li><strong>Anforderungen: </strong>Eine detaillierte Aufschlüsselung der funktionalen und nicht-funktionalen Anforderungen des Projekts. Funktionale Anforderungen beschreiben, welche Funktionen das System haben soll, während nicht-funktionale Anforderungen Aspekte wie Leistung, Sicherheit, Zuverlässigkeit und Benutzerfreundlichkeit definieren. </li>
                <li><strong>Benutzeroberfläche: </strong>Beschreibung der Benutzeroberfläche, einschließlich Mockups, Wireframes oder Beschreibungen der Benutzeroberfläche, um zu verdeutlichen, wie Benutzer mit dem System interagieren können. </li>
                <li><strong>Datenanforderungen: </strong>Spezifikationen für Daten, die im System verwendet oder generiert werden, einschließlich Datenstrukturen, Datenbankanforderungen und Datenflussdiagrammen. </li>
                <li><strong>Leistungsanforderungen: </strong>Spezifikationen für die Leistung des Systems, einschließlich Geschwindigkeit, Antwortzeiten und Skalierbarkeit. </li>
                <li><strong>Qualitätsstandards: </strong>Definition der Qualitätsstandards und -kriterien, die das Projekt erfüllen muss, einschließlich Test- und Validierungskriterien. </li>
                <li><strong>Lieferumfang: </strong>Beschreibung der zu liefernden Ergebnisse, Produkte oder Dienstleistungen, einschließlich Zeitrahmen und Meilensteine. </li>
                <li><strong>Risikomanagement: </strong>Identifizierung und Bewertung von Risiken im Zusammenhang mit dem Projekt sowie Strategien zur Risikominderung und -bewältigung. </li>
                <li><strong>Annahmen und Abhängigkeiten: </strong>Aufstellung von Annahmen, die während des Projekts getroffen wurden, sowie von Abhängigkeiten, die die Durchführung des Projekts beeinflussen können. </li>
                <li><strong>Genehmigung und Änderungsverwaltung: </strong>Festlegung des Verfahrens zur Genehmigung des Pflichtenhefts sowie zur Verwaltung von Änderungsanträgen und -genehmigungen während des Projekts. </li>
            </ul>
            <p>Das Pflichtenheft ist ein wesentliches Dokument, das als Referenzpunkt für alle Projektbeteiligten dient und sicherstellt, dass das Projekt gemäß den vereinbarten Anforderungen und Spezifikationen durchgeführt wird.
            </p>
            <div class="quelle">
                <a class="btn" href="https://de.wikipedia.org/wiki/Pflichtenheft#:~:text=Das%20Pflichtenheft%20beschreibt%20in%20konkreter,entwickelt%20oder%20produziert%20haben%20m%C3%B6chte.
" target="_blank">Quelle</a>
            </div>
        </section>
        <section class="container" id="lastenheft">
            <h2>12.4 Fachbegriff Lastenheft und notwendiger Inhalt</h2>
            <p>Ein Lastenheft ist ein Dokument, das im Rahmen von Projektmanagement und Softwareentwicklung verwendet wird. Es definiert die Anforderungen und Spezifikationen, die ein zu entwickelndes Produkt oder eine zu erbringende Dienstleistung erfüllen muss. Der Inhalt eines Lastenhefts kann Folgendes umfassen: </p>
            <ul class="list">
                <li><strong>Projektübersicht: </strong>Ziele und Hintergrund des Projekts. </li>
                <li><strong>Zielgruppe: </strong>Endnutzer oder Stakeholder, für die das Projekt bestimmt ist. </li>
                <li><strong>Anforderungen: </strong>Detaillierte Beschreibung der fachlichen, technischen und organisatorischen Anforderungen. </li>
                <li><strong>Lieferumfang: </strong>Was genau geliefert werden soll, einschließlich Produktfunktionen und -dienstleistungen. </li>
                <li><strong>Abnahmekriterien: </strong>Bedingungen, unter denen das Produkt als fertiggestellt gilt. </li>
                <li><strong>Terminplan: </strong>Zeitrahmen und Meilensteine. </li>
                <li><strong>Budget: </strong>Kostenrahmen für die Umsetzung. </li>
                <li><strong>Risiken: </strong>Potentielle Risiken und Umgang mit diesen. </li>
            </ul>
            <p>Das Lastenheft wird üblicherweise vom Auftraggeber erstellt und an den Auftragnehmer übergeben, der darauf basierend das Pflichtenheft erstellt. </p>
            <div class="quelle">
                <a class="btn" href="https://de.wikipedia.org/wiki/Lastenheft#:~:text=Das%20Lastenheft%20(auch%20Anforderungsspezifikation%2C%20Anforderungskatalog,Lieferungen%20und%20Leistungen%20eines%20Auftragnehmers. " target="_blank">Quelle</a>
                <a class="btn" href="https://www.projektmagazin.de/glossarterm/lastenheft " target="_blank">Quelle</a>
                <a class="btn" href="https://www.ionos.at/digitalguide/websites/web-entwicklung/lastenheft/ " target="_blank">Quelle</a>
            </div>
        </section>
        <section class="container" id="spannungsfelder">
            <h2>12.5 Kenntnisse über Spannungsfelder in einem Projekt</h2>
            <h3>Kosten vs. Zeit  </h3>
            <p>Die Dimensionen Kosten und Zeit geraten dann in Konflikt, wenn sich die Fertigstellung des Projektes zu verzögern droht. Entweder es wird akzeptiert, dass der angestrebte Termin nicht eingehalten werden kann, oder es werden mehr Mittel investiert, um das Projekt pünktlich beenden zu können </p>
            <h3>Zeit vs. Qualität  </h3>
            <p>Wenn die Zeit nicht mehr ausreicht, um das Projekt termingerecht zu beenden, ist es eine Möglichkeit, die Leistungen zu reduzieren. Das beeinträchtigt allerdings die Qualität.  </p>
            <h3>Qualität vs. Kosten  </h3>
            <p>Das Budget für das Projekt wird knapp. Es reicht nicht aus, um alle gewünschten Leistungen zu erbringen. Nun hat man die Wahl, ob man diesen Umstand akzeptiert und so eine Verschiebung der Qualitätsdimension herbeiführt oder ob man mehr Mittel bereitstellt. </p>
            <div class="quelle">
                <a class="btn" href="https://www.agile-master.de/magisches-dreieck-projektmanagement/" target="_blank">Quelle</a>
            </div>
        </section>
        <section class="container" id="projektziel">
            <h2>12.6 Kenntnisse über den Fachbegriff Primäres Projektziel</h2>
            <p>Das primäre Projektziel bezieht sich auf das Hauptziel oder den zentralen Zweck eines Projekts. Es repräsentiert den übergeordneten Zweck, warum das Projekt ins Leben gerufen wurde, und dient als Leitfaden für alle Aktivitäten und Entscheidungen im Verlauf des Projekts. Das primäre Projektziel ist oft der entscheidende Maßstab für den Erfolg oder Misserfolg eines Projekts. </p>
            <h3>Klare Definition: </h3>
            <p>Das primäre Projektziel sollte klar und prägnant definiert werden, um sicherzustellen, dass alle Beteiligten ein gemeinsames Verständnis davon haben. Es sollte verständlich und messbar sein. </p>
            <h3>Ausrichtung mit den Unternehmenszielen: </h3>
            <p>Das primäre Projektziel sollte sich in der Regel direkt mit den übergeordneten Zielen und strategischen Interessen der Organisation oder des Unternehmens abstimmen. Es sollte einen Beitrag zur Erfüllung der Gesamtmission und -vision leisten. </p>
            <h3>SMART-Kriterien: </h3>
            <p>Idealerweise sollte das primäre Projektziel den SMART-Kriterien entsprechen, d.h., es sollte spezifisch, messbar, erreichbar, relevant und zeitgebunden sein. Diese Kriterien helfen dabei, das Ziel klar zu definieren und die Fortschritte zu überwachen. </p>
            <h3>Fokus auf wesentliche Ergebnisse: </h3>
            <p>Das primäre Projektziel konzentriert sich auf die entscheidenden Ergebnisse oder den Wert, den das Projekt für das Unternehmen oder die Organisation bringen soll. Es hebt die wichtigsten Aspekte hervor, die den größten Nutzen bringen. </p>
            <h3>Änderungen und Anpassungen: </h3>
            <p>Das primäre Projektziel kann sich im Laufe des Projekts ändern, basierend auf sich ändernden Anforderungen, Erkenntnissen oder externen Einflüssen. Es ist wichtig, dass solche Änderungen kommuniziert und dokumentiert werden. </p>
            <div class="quelle">
                <a class="btn" href="https://lehrerfortbildung-bw.de/st_kompetenzen/weiteres/projekt/projektmanagement/3.html" target="_blank">Quelle</a>
            </div>
        </section>
        <section class="container" id="projektorganisation">
            <h2>12.7 Kenntnisse über Vor- und Nachteile einer Projekt&shy;organisation</h2>
            <h3>Die Matrixorganisation </h3>
            <p>Vorteile </p>
            <ul class="left">
                <li>Mitarbeiter verbleiben in ihren Abteilungen, so dass eine Wiedereingliederung nach Projektende entfällt. </li>
                <li>Mitarbeiter können vom Wissen und dem Austausch in ihrer Fachabteilung profitieren. </li>
                <li>Flexibler Zugriff auf Ressourcen.</li>
            </ul>
            <p>Nachteile </p>
            <ul class="left">
                <li>Konflikte zwischen Projekt- und Abteilungsleitung möglich (Mitarbeiter haben zwei Vorgesetzte). </li>
                <li>Probleme bei der Priorisierung zwischen Linien- und Projektarbeit.</li>
            </ul>
            <h3>Die reine Projektorganisation </h3>
            <p>Vorteile </p>
            <ul class="left">
                <li>Hohe Identifikation der Projektmitarbeiter mit dem Projekt. </li>
                <li>Klare Strukturen und sowohl fachliches als auch disziplinarisches Weisungsrecht durch den Projektleiter. </li>
                <li>Direkte Kommunikation. </li>
            </ul>
            <p>Nachteile </p>
            <ul class="left">
                <li>Hoher Aufwand bei Wiedereingliederung der Projektmitarbeiter in die Linienorganisation. </li>
                <li>Wissensaustausch mit Fachabteilungen oft schwierig. </li>
                <li>Die Mitarbeiter stehen ihren Stammabteilungen für die Dauer des Projektes gar nicht mehr zur Verfügung. </li>
                <li>Bei Schlüsselressourcen kann das zu einem ernsthaften Problem werden.</li>
            </ul>
            <h3>Die Stabsorganisation </h3>
            <p>Vorteile</p>
            <ul class="left">
                <li>Die Organisationsstruktur wird nicht verändert. </li>
                <li>Die Projektorganisation kann schnell eingerichtet und aufgelöst werden. </li>
                <li>Projektmitarbeiter verbleiben in ihren Abteilungen und können ihr Fachwissen von dort beziehen.	 </li>
            </ul>
            <p>Nachteile </p>
            <ul class="left">
                <li>Der Projektleiter verfügt über keine direkten Weisungsrechte. </li>
                <li>Abstimmung und Koordination ist sehr aufwändig. </li>
                <li>Maßnahmen sind manchmal schwierig durchzusetzen. </li>
            </ul>
            <div class="quelle">
                <a class="btn" href="https://projekte-leicht-gemacht.de/blog/methoden/projektorganisation/projektorganisationsformen/" target="_blank">Quelle</a>
            </div>
        </section>
        <section class="container" id="einerProjektdokumentation">
            <h2>12.8 Ziel einer Projekt&shy;dokumentation</h2>
            <p>Die Projektdokumentation hat mehrere Ziele, die dazu dienen, den gesamten Projektablauf transparent, nachvollziehbar und effektiv zu gestalten. </p>
            <p><strong>Nachvollziehbarkeit: </strong>Eine Projektdokumentation ermöglicht es allen Beteiligten, den Verlauf des Projekts nachzuvollziehen. Durch eine klare Dokumentation können Teammitglieder verstehen, warum bestimmte Entscheidungen getroffen wurden und wie der Projektverlauf war. </p>
            <p><strong>Kommunikation: </strong>Die Dokumentation dient als Kommunikationsmittel innerhalb des Teams und mit externen Partnern oder Stakeholdern. Durch die schriftliche Festhaltung von Informationen wird sichergestellt, dass alle Beteiligten auf dem gleichen Stand. </p>
            <p><strong>Qualitätssicherung: </strong>Die Dokumentation unterstützt die Qualitätssicherung, indem sie den Projektablauf, die Ergebnisse und die erreichten Meilensteine überwacht. </p>
            <p><strong>Wissensweitergabe: </strong>Die Dokumentation dient als Grundlage für die Weitergabe von Wissen an neue Teammitglieder. Dies erleichtert die Einarbeitung neuer Mitarbeiter und sorgt für einen reibungslosen Übergang zwischen verschiedenen Projektphasen. </p>
            <div class="quelle">
                <a class="btn" href="https://www.timetrackapp.com/blog/projektdokumentation-wichtige-grundregeln/" target="_blank">Quelle</a>
            </div>
        </section>
        <section class="container" id="struktogramm">
            <h2>12.9 Fachbegriff Struktogramm</h2>
            <p>Mit einem Struktogramm stellst du den Ablauf eines Computerprogramms auf dem Papier dar. Mit Hilfe eines Struktogramms kannst du also Algorithmen unabhängig von einer Programmiersprache aufschreiben. Das Struktogramm nennst du auch Nassi-Shneiderman-Diagramm. Die Bezeichnung stammt von den beiden Entwicklern des Struktogramms, Isaac Nassi und Ben Shneiderman.
                Struktogramme wurden eingeführt, weil viele Computerprogramme mit der Zeit immer komplexer und somit auch unübersichtlicher wurden.
                Die Einführung der Struktogramme wirkte diesem Problem entgegen: Mit dem Struktogramm kannst du komplexe Programmabläufe gründlich und ohne Lücken planen. Die entstandenen Programmabläufe kannst du auch als strukturierte Programmierung bezeichnen.
            </p>
            <p>
                Ein Struktogramm veranschaulicht Algorithmen mit Hilfe geometrischer Formen. Ihr Grundbaustein ist das Rechteck. Rechtecke können aufeinander gestapelt und ineinander geschachtelt werden. Dabei ist jedes Rechteck mit einer elementaren Anweisung beschriftet oder es stellt eine Kontrollstruktur dar.
                Kontrollstrukturen geben an, wie eine Anweisung ausgeführt werden soll. Die Anweisung kann nach einer bestimmten Reihenfolge ausgeführt werden oder es handelt sich um eine Anweisung mit bestimmter Bedingung. Beispiele für Kontrollstrukturen sind eine Verzweigung oder eine Schleife.
                <br>
                Struktogramme sind unabhängig von jeglichen Programmiersprachen formuliert. Dadurch kann jeder das, was im Struktogramm dargestellt wird, einfach verstehen. Zudem kann das Struktogramm als Codiervorschrift in jede Programmiersprache umgesetzt werden. Es stellt also einen wichtigen Zwischenschritt vom Problem zur Lösung dar.
            </p>
            <div class="quelle">
                <a class="btn" href="https://studyflix.de/informatik/struktogramm-5715" target="_blank">Quelle</a>
            </div>
        </section>
        <section class="container" id="ablaufdiagramm">
            <h2>12.10 Fachbegriff Ablaufdiagramm (Flowchart)</h2>
            <p>
                Ein Ablaufdiagramm ist eine grafische Darstellung des Programmablaufs, die durch die Verwendung von Symbolen wie Rechtecken, Rauten und Pfeilen die logische Abfolge von Anweisungen, Entscheidungen und Schleifen im Code verdeutlicht. Durch diese visuelle Repräsentation erhalten Entwickler einen klaren Einblick in den Datenfluss und die Kontrollstruktur des Programms, was die Analyse, das Design und die Optimierung komplexer Prozesse erleichtert.
            </p>
            <img style="width: 300px" src="/img/Flowchart_de.svg.png" width="220" alt="Flowchart">
            <span class="bildQuelle"><a href="https://de.wikipedia.org/wiki/Kontrollstruktur" target="_blank" title="wiki Kontrollstrucktur" >Bild Quelle Kontrollstrucktur</a></span>
            <h3>Beispiel:</h3>
            <p>Die Abbildung zeigt eine Zählschleife. Die Zählvariable i wird vor Beginn der Schleife auf ihren Startwert i=1 gesetzt. Danach wird die Variable i ausgegeben. Die zweite Anweisung ist eine Auswahl, die prüft, ob i den Wert 39 besitzt. Wenn dies der Fall ist, wird i auf den Wert 61 gesetzt und die Schleife beginnt mit dem nächsten Durchlauf. Falls i nicht 39 ist, wird i in der nachfolgenden Anweisung um eins erhöht und anschließend geprüft, ob die Schleifen&shy;fortsetzungs&shy;bedingung i≤100 gültig ist. Falls ja, erfolgt ein nochmaliger Schleifendurchlauf. Ausgegeben würden alle natürlichen Zahlen von 1 bis 39 sowie 61 bis 100. </p>
            <div class="quelle">
                <a class="btn" href="https://de.wikipedia.org/wiki/Programmablaufplan " target="_blank">Quelle</a>
                <a href="https://www.programiz.com/article/flowchart-programming" class="btn">Quelle</a>
            </div>
        </section>
        <section class="container" id="wesentliche">
            <h2>12.11 Kenntnisse über wesentliche Schritte einer Projektplanung</h2>
            <h3>Projektziele und -umfang definieren: </h3>
            <p>Klare Festlegung der Projektziele und des Umfangs, um zu verstehen, was erreicht werden soll und welche Arbeit dafür erforderlich ist. </p>
            <h3>Ressourcen identifizieren: </h3>
            <p>Bestimmung der benötigten Ressourcen wie Personal, Budget, Ausrüstung und Materialien für die Durchführung des Projekts. </p>
            <h3>Arbeitspakete definieren: </h3>
            <p>Zerlegung des Projekts in kleinere, handhabbare Einheiten von Arbeitspaketen, um die Arbeit zu organisieren und zu delegieren. </p>
            <h3>Zeitplan erstellen: </h3>
            <p>Erstellung eines detaillierten Zeitplans, der die Reihenfolge der Aktivitäten, ihre Dauer und Abhängigkeiten festlegt, um sicherzustellen, dass das Projekt rechtzeitig abgeschlossen wird. </p>
            <h3>Risiken identifizieren und bewerten: </h3>
            <p>Identifizierung potenzieller Risiken, die den Erfolg des Projekts gefährden könnten, sowie Bewertung ihrer Auswirkungen und Wahrscheinlichkeiten. </p>
            <h3>Risikomanagementplan entwickeln: </h3>
            <p>Entwicklung von Strategien zur Vermeidung, Minderung oder Bewältigung identifizierter Risiken, um sicherzustellen, dass das Projekt auf Kurs bleibt. </p>
            <h3>Qualitätsstandards festlegen: </h3>
            <p>Festlegung der Qualitätsstandards und -kriterien, die das Projekt erfüllen muss, sowie der Prozesse und Verfahren zur Sicherstellung der Qualität. </p>
            <h3>Kommunikationsplan erstellen: </h3>
            <p>Entwicklung eines Kommunikationsplans, der festlegt, wer welche Informationen erhalten soll, wann und wie sie kommuniziert werden sollen. </p>
            <h3>Budget erstellen: </h3>
            <p>Schätzung der Kosten für das Projekt und Erstellung eines Budgets, um sicherzustellen, dass das Projekt innerhalb der finanziellen Grenzen bleibt. </p>
            <h3>Team zusammenstellen und Rollen zuweisen: </h3>
            <p>Auswahl und Zusammenstellung des Projektteams sowie Zuweisung von Rollen und Verantwortlichkeiten, um sicherzustellen, dass alle Aufgaben abgedeckt sind. </p>
            <h3>Genehmigung des Projektplans einholen: </h3>
            <p>Präsentation des Projektplans den relevanten Stakeholdern zur Überprüfung und Genehmigung, um sicherzustellen, dass alle Beteiligten mit dem Plan einverstanden sind. </p>
            <p>Die Projektplanung legt den Rahmen für den gesamten Projektablauf fest und ist entscheidend für den Erfolg des Projekts. Durch die Durchführung dieser Schritte können potenzielle Probleme frühzeitig identifiziert und gelöst werden, was die Wahrscheinlichkeit eines erfolgreichen Projektabschlusses erhöht.
            </p>
            <div class="quelle">
                <a class="btn" href="https://www.meistertask.com/blog/projektzeitplan-erstellen/?lang=de&utm_term=&utm_campaign=DACH_de_Pmax&utm_source=adwords&utm_medium=ppc&hsa_acc=8361758703&hsa_cam=17263546688&hsa_grp=&hsa_ad=&hsa_src=x&hsa_tgt=&hsa_kw=&hsa_mt=&hsa_net=adwords&hsa_ver=3&gad_source=1&gclid=CjwKCAjwte-vBhBFEiwAQSv_xXCFfEfXl8llmQDHB9Fnbx3cf45frxoFpJwmukj9VN-W-8R6qJnmAhoC0kMQAvD_BwE" target="_blank">Quelle</a>
            </div>
        </section>
        <section class="container" id="eigenschaften">
            <h2>12.12 Kenntnisse über Eigenschaften eines Projektleiters</h2>
            <p>IT-Projektleiter und IT-Projektleiterinnen sind für die Betreuung von IT-Projekten zuständig. Dabei beginnen sie schon bei der Konzeption und Planung eines Projekts sowie beim ersten Kundengespräch mit ihrer Arbeit. Sie sind für einen Großteil des Projektes verantwortlich und sorgen dafür, dass alles rund läuft </p>
            <ul class="left" style="list-style: decimal">
                <li>Projekt von A bis Z durchplanen </li>
                <li>Projekt in Aufgaben einteilen </li>
                <li>Team für diese Aufgaben zusammenstellen </li>
                <li>definiert das Projektziel nach Kundenwunsch </li>
                <li>setzt das Gewinnziel für das Unternehmen </li>
                <li>Budget einplanen </li>
                <li>legt einen Abgabetermin fest </li>
                <li>legt die Deadline fest an dem das Projekt fertig und dem Kunden übergeben werden muss </li>
                <li>verteilt er die Aufgaben an verschiedene Abteilungen bzw. Mitarbeiter und weist sie gegebenenfalls ein</li>
                <li>ständig in der Überwachung des Projektfortschritts involviert </li>
                <li>hält die Klientel so auf dem Laufenden </li>
                <li>Kommunikationsschnittstelle zwischen den Menschen innerhalb der Firma, zwischen Vorgesetzten und Angestellten und zwischen den Abteilungen, sowie zwischen Kunden und Unternehmen </li>
                <li>kontrolliert die Qualität des Projektes und gibt Verbesserungsvorschläge </li>
                <li>dokumentiert er den Ablauf des Projekts </li>
                <li>Nach Abschluss des Projekts präsentiert er es dem Kunden und analysiert den Erfolg und die Effizienz des Projekts </li>
                <li>Er steht den Kunden weiterhin als Ansprechpartner zur Verfügung </li>
            </ul>
            <div class="quelle">
                <a class="btn" href="https://www.gulp.de/bewerber/berufsbilder/it-projektleiter" target="_blank">Quelle</a>
            </div>
        </section>
        <section class="container" id="projektleiters">
            <h2>12.13 Aufgaben eines Projektleiters</h2>
            <p>Die Aufgaben eines Projektleiters sind vielfältig und umfassen verschiedene Aspekte des Projektmanagements. Hier sind einige der wichtigsten Aufgaben eines Projektleiters: </p>
            <ul class="left">
                <li>Projektplanung: Der Projektleiter ist für die Planung des gesamten Projekts verantwortlich, einschließlich der Definition von Zielen, Umfang, Zeitplan, Ressourcenbedarf und Budget.</li>
                <li>Teamführung und -management: Der Projektleiter stellt sicher, dass das Projektteam effektiv arbeitet, indem er Teammitglieder auswählt, Rollen und Verantwortlichkeiten zuweist, Kommunikation erleichtert und Konflikte löst.</li>
                <li>Kommunikation: Der Projektleiter ist für die Kommunikation mit den Stakeholdern verantwortlich, einschließlich der Berichterstattung über den Projektstatus, der Klärung von Anforderungen und der Lösung von Problemen.</li>
                <li>Risikomanagement: Der Projektleiter identifiziert potenzielle Risiken im Projekt und entwickelt Strategien zur Vermeidung, Minderung oder Bewältigung dieser Risiken.</li>
                <li>Qualitätsmanagement: Der Projektleiter legt Qualitätsstandards fest und überwacht die Qualität der Arbeit, um sicherzustellen, dass das Projekt die erforderlichen Standards erfüllt.</li>
                <li>Zeit- und Ressourcenmanagement: Der Projektleiter überwacht den Zeitplan und die Ressourcen des Projekts, um sicherzustellen, dass es rechtzeitig und innerhalb des Budgets abgeschlossen wird.</li>
                <li>Problembehandlung: Der Projektleiter ist für die Identifizierung und Lösung von Problemen im Projekt verantwortlich, um sicherzustellen, dass das Projekt auf Kurs bleibt.</li>
                <li>Dokumentation: Der Projektleiter erstellt und pflegt alle erforderlichen Dokumente und Berichte im Zusammenhang mit dem Projekt, einschließlich des Projektplans, Statusberichte und Änderungsanträge.</li>
                <li>Stakeholder-Management: Der Projektleiter arbeitet eng mit den Stakeholdern zusammen, um sicherzustellen, dass ihre Anforderungen und Erwartungen erfüllt werden und sie über den Fortschritt des Projekts informiert sind.</li>
                <li>Abschluss und Bewertung: Der Projektleiter führt die Abschlussarbeiten durch und bewertet das Projekt, um sicherzustellen, dass die Ziele erreicht wurden und um Erfahrungen und Erkenntnisse für zukünftige Projekte zu dokumentieren.</li>
            </ul>
            <p>Diese Aufgaben erfordern ein breites Spektrum an Fähigkeiten, darunter Führungsfähigkeiten, Kommunikationsfähigkeiten, Zeitmanagement und Problemlösungsfähigkeiten. Der Projektleiter spielt eine entscheidende Rolle bei der Sicherstellung des Erfolgs des Projekts und bei der Gewährleistung einer effektiven Zusammenarbeit innerhalb des Teams und mit den Stakeholdern </p>
            <div class="quelle">
                <a class="btn" href="https://www.integrata-cegos.de/job-profile/berufsbilder-des-projektmanagements/berufsbild-it-projektleiter " target="_blank">Quelle</a>
            </div>
        </section>
        <section class="container" id="dokumentationen">
            <h2>12.14 Kenntnisse über Dokumentationen eines Projektes</h2>
            <p>Die Dokumentation eines Projektes ist ein wesentlicher Bestandteil des Projektmanagements und der Softwareentwicklung. Sie dient dazu, den Fortschritt, die Entscheidungen und die spezifischen Details eines Projekts festzuhalten. Zu einer umfassenden Projektdokumentation gehören in der Regel: </p>
            <ul class="left">
                <li>Projektvorschlag oder -initiierungsdokument: Dies beschreibt den Zweck, die Ziele und den Umfang des Projekts.</li>
                <li>Lastenheft: Enthält die Anforderungen des Auftraggebers.</li>
                <li>Pflichtenheft: Beschreibt, wie die Anforderungen umgesetzt werden sollen.</li>
                <li>Projektplan: Enthält Zeitplan, Ressourcenplanung und Kostenübersicht.</li>
                <li>Fortschrittsberichte: Dokumentieren den Status des Projekts zu bestimmten Zeitpunkten.</li>
                <li>Technische Dokumentation: Beschreibt die Architektur, den Code und die Verwendung von Software oder Systemen.</li>
                <li>Benutzerdokumentation: Anleitungen für Endbenutzer zur Nutzung des Produkts.</li>
                <li>Testdokumentation: Testpläne, Testfälle und Testberichte.</li>
                <li>Abschlussbericht: Eine Zusammenfassung der Ergebnisse, der gelieferten Produkte und der geleisteten Arbeit.</li>
            </ul>
            <p>Gute Dokumentation erleichtert die Kommunikation innerhalb des Teams und mit Stakeholdern, ermöglicht eine effiziente Übergabe an Wartungsteams und stellt sicher, dass Projektziele klar und nachvollziehbar erreicht werden.</p>
            <div class="quelle">
                <a class="btn" href="https://www.wirtschaftswissen.de/unternehmensfuehrung/projektmanagement/projektdokumentation-je-genauer-sie-ist-desto-weniger-arbeit-haben-sie-mit-nachfolgeprojekten/ " target="_blank">Quelle</a>
                <a class="btn" href="https://www.trackplus.com/blog/de/kurzanleitung-zur-projektdokumentation-wichtige-tipps-und-beispiele/ " target="_blank">Quelle</a>
                <a class="btn" href="https://www.techsmith.de/blog/gute-technische-dokumentation-erstellen/" target="_blank">Quelle</a>
            </div>
        </section>
        <section class="container" id="projektauftrag">
            <h2>12.15 Fachbegriff Projektauftrag</h2>
            <p>Der Projektauftrag ist ein Dokument, das die Existenz eines Projektes formell bestätigt. Der Projektauftrag ist Teil des Umfangsmanagements und wird in der Regel von einer Managerin oder einem Manager einer höheren Ebene unterzeichnet. Mit dem Projektauftrag wird meist der Projektleiter benannt und das Projektbudget freigegeben. </p>
            <p>Der Begriff 'Projektauftrag' ist nicht normiert und wird unterschiedlich verwendet. Teilweise wird allgemein von 'Auftrag' oder von 'Projektvereinbarung' gesprochen. Synonym wird häufig der Begriff 'Projektleitervereinbarung' benutzt, wobei Umfang und Funktion des Projektauftrages über eine bloße Benennung des Projektleiters hinausgehen. Bei Projekten mit externen Dienstleistern wird der Projektauftrag oft durch einen formellen Vertrag ersetzt. </p>
            <p>Dem Projektauftrag geht meist ein Projektantrag bzw. Projektvorschlag voraus, in dem die Ausgangslage, Ziele, Projektergebnisse, Kosten und Nutzen sowie Organisation skizziert ist. Aufgrund des Projektantrages wird über die Durchführung eines Projektes entschieden. Der Projektauftrag ist der formelle Startschuss zum Projekt. Dies ist von Bedeutung, weil die Definition eines Projektes eine genau festgelegte Zeitspanne umfasst. Ohne Vorliegen eines Projektauftrages kann im Nachhinein der Beginn eines Projektes oft nicht mehr nachvollzogen werden. Dies zieht dann meist Probleme bei der Abrechnung oder Verantwortlichkeit nach sich.</p>
            <p>Der Projektauftrag bildet die Grundlage eines jeden Projektes. Er ist als Vertrag zwischen Projektleiter und Projektauftraggeber zu sehen, der sowohl die Zusammenarbeit regelt als auch gewährleistet, dass beide dieselben Ziele vor Augen haben </p>
            <div class="quelle">
                <a class="btn" href="https://de.wikipedia.org/wiki/Projektauftrag " target="_blank">Quelle</a>
            </div>
        </section>
        <section class="container" id="projektstrukturplan">
            <h2>12.16 Fachbegriff Projektstrukturplan</h2>
            <p>
                Der Fachbegriff "Projektstrukturplan" (PSP) bezieht sich auf eine hierarchische Darstellung der Elemente, Aufgaben und Arbeitspakete eines Projekts. Der Projektstrukturplan ist ein wichtiger Bestandteil des Projektmanagements und hilft dabei, die Organisationsstruktur und den Umfang eines Projekts zu visualisieren.
            </p>
            <div class="quelle">
                <a class="btn" href="https://lehrerfortbildung-bw.de/st_kompetenzen/weiteres/projekt/projektmanagement/3.html" target="_blank">Quelle</a>
            </div>
        </section>
        <section class="container" id="arbeitspaket">
            <h2>12.17 Fachbegriff Arbeitspaket</h2>
            <p>
                Ticketing- und Projektmanagement-Plattformen wie JIRA oder OpenProject ermöglichen es, Projekte und Aufgaben effizient zu organisieren und zuzuweisen. Ein wesentlicher Bestandteil solcher Plattformen ist das Konzept des Arbeitspakets, das eine definierte Leistung innerhalb eines Projekts darstellt. Es legt fest, welche Personen welche Aufgaben bis wann und mit welchem Aufwand erfüllen sollen, wodurch eine strukturierte und nachvollziehbare Projektplanung und -durchführung unterstützt wird.
            </p>
            <div class="quelle">
                <a class="btn" href="https://www.projectfacts.de/glossar/arbeitspaket/#:~:text=Das%20Arbeitspaket%20ist%20ein%20Teil,mit%20welchem%20Aufwand%20erbringen%20sollen. " target="_blank">Quelle</a>
            </div>
        </section>
        <section class="container" id="meilenstein">
            <h2>12.18 Fachbegriff Meilenstein</h2>
            <p>Ein Meilenstein ist ein Ereignis von besonderer Bedeutung im Projektmanagement. Meilensteine teilen den Projektverlauf in Etappen mit überprüfbaren Zwischenzielen und erleichtern damit sowohl die Projektplanung als auch die Kontrolle des Projektfortschritts. </p>
            <p>Solche Ereignisse sind insbesondere:  </p>
            <ul class="left">
                <li>Entscheidungen über den weiteren Fortgang des Projekts</li>
                <li>Das Vorliegen von Liefergegenständen oder Zwischenergebnissen</li>
                <li>Abnahmen, Zwischenabnahmen und Prüfungen</li>
                <li>Zusammenführen oder Verzweigen von Projektpfaden</li>
            </ul>
            <p>Nutzen von Meilensteinen: </p>
            <ul class="left">
                <li>Sie reduzieren das Risiko von Fehlentwicklungen, denn sie unterstützen die Überwachung des Projektfortschritts mittels Projektcontrolling.</li>
                <li>Sie unterstützen einen geordneten Übergang zwischen den Projektphasen.</li>
                <li>Sie ermöglichen durch Entscheidungen zum Projektabschluss und zur Phasenfreigabe eine kontinuierliche Einbindung des Auftraggebers.</li>
                <li>Sie ermöglichen eine fortlaufende Zielorientierung der Mitarbeiter, schaffen Erfolgserlebnisse und synchronisieren die Zusammenarbeit. Somit sind sie auch ein Mittel zur Führung und Motivation.</li>
            </ul>
            <div class="quelle">
                <a class="btn" href="https://de.wikipedia.org/wiki/Meilenstein_(Projektmanagement) " target="_blank">Quelle</a>
            </div>
        </section>
        <section class="container" id="externesProjekt">
            <h2>12.19 Unterschiede internes / externes Projekt</h2>
            <h3>Externe Projekte </h3>
            <p>Auftraggeber externer Projekte sind Personen oder Institutionen außerhalb der Organisation, die das Projekt realisiert. Solche Projekte werden auch Auftragsprojekte genannt und sie gibt es vor allem in Branchen, in denen die Leistungserstellung mit Projektcharakter dominiert. Dazu gehören zum Beispiel der Hoch- und Tiefbau, der Anlagen- und Großmaschinenbau, aber auch die Software- und die Beratungsbranche.
                Wichtigste Aufgabe des potenziellen Auftragnehmers ist zu prüfen, ob es sich für ihn lohnt, dem potenziellen Auftraggeber ein Angebot zu unterbreiten. Der Auftraggeber hat dagegen die Aufgabe einen geeigneten Anbieter zu ermitteln.
                Es gibt verschiedene Methoden, um festzustellen, welcher Anbieter die gestellte Aufgabe voraussichtlich am besten erledigt. Ein Weg ist es, Referenzen einzuholen. Diese geben Aufschluss über die Kompetenz im jeweiligen Fachgebiet und im Projektmanagement. Ein anderer Ansatz besteht darin, ausdrücklich die Anwendung von Projektmanagementstandards und -methoden sowie einen formalen Qualifikationsnachweis für das im Projekt eingesetzte Personal zu fordern.
                Nimmt der Auftraggeber das Angebot – mit oder ohne Änderungen – an, dann schließen beide Seiten einen Vertrag miteinander ab, der dann die Grundlage der Projektbearbeitung bildet. </p>
            <h3>Interne Projekte</h3>
            <p>
                Bei internen Projekten ist der Auftraggeber eine Person oder eine Institution, die dem Unternehmen selbst angehört. Beispiele sind die Geschäftsleitung, das Projektportfolioboard oder auch die Vorgesetzten von Fachabteilungen. Der Anstoß für interne Projekte sowie Finanzierungsbeiträge können aber durchaus auch von Externen kommen. Wenn am Projekt nur Mitglieder der eigenen Organisation mitwirken, existiert oftmals kein förmlicher Vertrag zwischen Auftraggeber und Auftragnehmer. Wurde ein Projektauftrag nur mündlich erteilt, sollte vom Auftragnehmer der Auftrag schriftlich formuliert und dem Auftraggeber vorgelegt werden. Damit kann Missverständnissen vorgebeugt und eine solide Basis für qualifizierte Projektarbeit, auch bei internen Projekten gelegt werden.
                Interne Projekte gibt es vor allem in den Forschungs- und Entwicklungsabteilungen von Industrieunternehmen und bei Reorganisationen, wie z. B. bei der Umstrukturierung einer Produktionsabteilung. Gerade im Entwicklungsbereich liegt oft eine große Zahl von Vorschlägen für Projekt vor. Sie können aber häufig wegen begrenzter Kapazitäten und Budgets nicht alle gleichzeitig realisiert werden. Deshalb müssen qualifizierte Entscheidungen zur Projektauswahl getroffen werden. </p>
            <div class="quelle">
                <a class="btn" href="https://www.iapm.net/de/blog/projektarten/#:~:text=Auftraggeber%20externer%20Projekte%20sind%20PersonenStakeholderdie%20Leistungserstellung%20mit%20Projektcharakter%20dominiert. " target="_blank">Quelle</a>
            </div>
        </section>
        <section class="container" id="projektkostenplanung">
            <h2>12.20 Kenntnis Projektkosten&shy;planung</h2>
            <p>Projektkostenplanung bedeutet, die finanziellen Ressourcen für die Umsetzung eines Softwareprojekts zu schätzen und zu managen. Das beinhaltet Budgetierung, Zuweisung von Ressourcen und Kostenkontrolle, um sicherzustellen, dass das Projekt effizient und innerhalb der finanziellen Vorgaben abgeschlossen wird. </p>
            <h3>Die Planung erfolgt oft in drei Phasen: </h3>
            <ul class="left">
                <li>Bewertung der Kosten eines Projekts: Sie geschieht unter Bezugnahme auf die tatsächlichen Kosten früherer, ähnlicher Projekte und ist nach Möglichkeit mit der Schätzung von Projektetappen verknüpft. </li>
                <li>Projektbudgetierung: Das Gesamtbudget wird entsprechend der Projektstruktur in kleinere Finanzmittelpakete unterteilt. </li>
                <li>Kostenkontrolle</li>
            </ul>

            <div class="quelle">
                <a class="btn" href="https://www.appvizer.de/magazin/organisation-planung/projektmanagement/projektbudgetplanung" target="_blank">Quelle</a>
            </div>
        </section>
        <div class="center">
            <a class="btn" href="InformatikTeil2.php">Zurück zu Informatik Teil 2</a>
            <a class="btn" href="ProjektmethodenTools.php">Weiter zu Projektmethoden, Tools</a>
        </div>
    </article>
</main>
<?php include'include/footer.php' ?>