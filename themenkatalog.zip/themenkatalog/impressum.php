<?php
$title = 'Impressum - CodeAbschlussGuide';
$description = 'Offizielles Impressum von CodeAbschlussGuide. Verantwortlich für den Inhalt: Johannes Jobst. Erfahren Sie mehr über unsere Kontaktinformationen, Haftungsausschluss, Urheberrecht und Datenschutz.';
$keywords = 'Impressum, CodeAbschlussGuide, Kontaktinformationen, Haftungsausschluss, Urheberrecht, Datenschutz';
$canonical = 'https://www.codeabschlussguide.at/impressum';
include 'include/header.php'
?>

<main class="reponsive">

    <section>
        <h1>Impressum</h1>
        <div class="container">
        <p><strong>Verantwortlich für den Inhalt:</strong></p>
        <p>Johannes Jobst<br>
            [Straße und Hausnummer]Coming soon <br>
            [PLZ und Ort]Coming soon <br>
            [Land]Coming soon </p>

        <h2>Kontakt:</h2>
        <p>Telefon: [Telefonnummer]Coming soon <br>
            <a href="mailto:Info@codeabschlussguide.at">E-Mail: Info@codeabschlussguide.at</a> </p>

        <h3>Haftungsausschluss:</h3>
        <p>Die Inhalte meiner Seiten wurden mit größter Sorgfalt erstellt. Für die Richtigkeit, Vollständigkeit und Aktualität der Inhalte kann ich jedoch keine Gewähr übernehmen. Als Diensteanbieter bin ich für eigene Inhalte auf diesen Seiten nach den allgemeinen Gesetzen verantwortlich. Ich bin jedoch nicht verpflichtet, übermittelte oder gespeicherte fremde Informationen zu überwachen oder nach Umständen zu forschen, die auf eine rechtswidrige Tätigkeit hinweisen.</p>

        <h3>Urheberrecht:</h3>
        <p>Die durch die Seitenbetreiber erstellten Inhalte und Werke auf diesen Seiten unterliegen dem österreichischen Urheberrecht. Die Vervielfältigung, Bearbeitung, Verbreitung und jede Art der Verwertung außerhalb der Grenzen des Urheberrechtes bedürfen der schriftlichen Zustimmung des jeweiligen Autors bzw. Erstellers. Downloads und Kopien dieser Seite sind nur für den privaten, nicht kommerziellen Gebrauch gestattet.</p>

        <h3>Datenschutz:</h3>
        <p>Die Nutzung meiner Webseite ist in der Regel ohne Angabe personenbezogener Daten möglich. Soweit auf meinen Seiten personenbezogene Daten (beispielsweise Name, Anschrift oder E-Mail-Adressen) erhoben werden, erfolgt dies, soweit möglich, stets auf freiwilliger Basis. Diese Daten werden ohne Ihre ausdrückliche Zustimmung nicht an Dritte weitergegeben.</p>

        <p>Ich weise darauf hin, dass die Datenübertragung im Internet (z.B. bei der Kommunikation per E-Mail) Sicherheitslücken aufweisen kann. Ein lückenloser Schutz der Daten vor dem Zugriff durch Dritte ist nicht möglich.</p>
        </div>
    </section>

</main>
<?php include'include/footer.php' ?>