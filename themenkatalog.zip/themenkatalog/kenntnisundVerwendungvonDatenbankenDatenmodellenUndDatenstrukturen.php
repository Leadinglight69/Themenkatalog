<?php
$title = 'Datenbanken, Datenmodelle und Datenstrukturen: Grundlagen und Anwendungen';
$description = 'Erfahren Sie alles über Datenbanksysteme, Datenmodelle und Datenstrukturen, inklusive relationaler und objektorientierter Datenbanken, Multimedia-Datenbanken, Data-Warehousing, OLAP, SQL-Abfragen, DBMS, CMS, Integrität, Redundanz, Datenmodellierung, grundlegende Datenbankoperationen, Normalformen, Schlüsselkonzepte, Indizes, Freeware Datenbanken, Sicherungsmethoden, und mehr. Ideal für Entwickler, Datenanalytiker und IT-Profis.';
$keywords = 'Datenbanksysteme, Datenmodelle, Datenstrukturen, Relationale Datenbanken, Objektorientierte Datenbanken, Multimedia-Datenbanken, Data-Warehouse, OLAP, SQL, DBMS, CMS, Datenintegrität, Datenredundanz, Datenmodellierung, SQL-Abfragen, Normalformen, Primärschlüssel, Fremdschlüssel, Indexes, Freeware Datenbanken, Sicherungsmethoden, ERP-Systeme, BI-Systeme, BW-Systeme, Datenmigration, Datenverschlüsselung';
$canonical = 'https://www.codeabschlussguide.de/datenbanken-datenmodelle-datenstrukturen';
include 'include/header.php'
?>
<main class="responsive">
    <section>
        <h1>16) Kenntnis und Verwendung von Datenbanken, Datenmodellen und Datenstrukturen</h1>
        <ul class="listLegend"  style="list-style: none">
            <li><a href="#datenbanksysteme">16.1 Fachbegriff Datenbanksysteme (Traditionelle Datenbanken (RDB), Objektorientierte</a></li>
            <li><a href="#multimedia">16.2 Datenbanken, Multimedia - Datenbanken (GIS), Data-Warehouse und OLAP)</a></li>
            <li><a href="#datenbankabfragen">16.3 Fachbegriffe zu Datenbankabfragen (z.B.: SQL, SQL/XML)</a></li>
            <li><a href="#dbms">16.4 Fachbegriff Datenbank&shy;managementsystem (DBMS)</a></li>
            <li><a href="#cms">16.5 Fachbegriff Content Management System (CMS)</a></li>
            <li><a href="#zusammenhang">16.6 Fachbegriff Integrität im Zusammenhang mit Datenbanken</a></li>
            <li><a href="#redundanz">16.7 Fachbegriff Redundanz im Zusammenhang mit Datenbanken</a></li>
            <li><a href="#rdb">16.8 Vorgangsweise bei der Datenmodellierung (RDB)</a></li>
            <li><a href="#grundlegende">16.9 Kenntnisse über grundlegende Datenbank&shy;operationen (SELECT, FROM, WHERE, …)</a></li>
            <li><a href="#normalformen">16.10 Kenntnisse über die ersten drei Normalformen im Zusammenhang mit Datenbanken</a></li>
            <li><a href="#primärschlüssel">16.11 Fachbegriffe Primärschlüssel, Fremdschlüssel, Relationen</a></li>
            <li><a href="#indexes">16.12 Kenntnis über Vor- und Nachteile bei Verwendung eines Indexes</a></li>
            <li><a href="#freeware">16.13 Vor- und Nachteile von Freeware Datenbanken</a></li>
            <li><a href="#sicherungsmethoden">16.14 Kenntnisse über Sicherungsmethoden</a></li>
            <li><a href="#sperrtabelle">16.15 Fachbegriff Sperrtabelle und Sperrverhalten</a></li>
            <li><a href="#bis">16.16 Fachbegriff BIS (Betriebliches Informations&shy;system)</a></li>
            <li><a href="#erp">16.17 Kenntnisse / Fachbegriff ERP Systeme</a></li>
            <li><a href="#bibw">16.18 Kenntnisse / Fachbegriff BI/BW Systeme</a></li>
            <li><a href="#prozessschritte">16.19 Kenntnisse der Abläufe und Prozessschritte (Auswählen DBMS, Erstellen des physischen Modells, Performance- und Stresstests, Datensicherheit, Datenschutz, Datenverschlüsselung – Kryptografie, Datenmigration) zum Umsetzen von Datenmodellen in eine Datenbank</a></li>
            <li><a href="#zugriffsschnittstelle">16.20 Kenntnisse der Abläufe und Prozessschritte (Zugriffs&shy;schnittstelle, Zugriffstechnologie, Transaktionskonzept, Programmierung, Testreihen, Benutzerabnahmetest, Ergebnisprüfung)</a></li>
        </ul>
        <aside class="floatingNav">
            <div class="floatingDot" data-section="#datenbanksysteme"><span class="floatingText">16.1 </span></div>
            <div class="floatingDot" data-section="#multimedia"><span class="floatingText">16.2 </span></div>
            <div class="floatingDot" data-section="#datenbankabfragen"><span class="floatingText">16.3 </span></div>
            <div class="floatingDot" data-section="#dbms"><span class="floatingText">16.4 </span></div>
            <div class="floatingDot" data-section="#cms"><span class="floatingText">16.5 </span></div>
            <div class="floatingDot" data-section="#zusammenhang"><span class="floatingText">16.6 </span></div>
            <div class="floatingDot" data-section="#redundanz"><span class="floatingText">16.7 </span></div>
            <div class="floatingDot" data-section="#rdb"><span class="floatingText">16.8 </span></div>
            <div class="floatingDot" data-section="#grundlegende"><span class="floatingText">16.9 </span></div>
            <div class="floatingDot" data-section="#normalformen"><span class="floatingText">16.10 </span></div>
            <div class="floatingDot" data-section="#primärschlüssel"><span class="floatingText">16.11 </span></div>
            <div class="floatingDot" data-section="#indexes"><span class="floatingText">16.12 </span></div>
            <div class="floatingDot" data-section="#freeware"><span class="floatingText">16.13 </span></div>
            <div class="floatingDot" data-section="#sicherungsmethoden"><span class="floatingText">16.14 </span></div>
            <div class="floatingDot" data-section="#sperrtabelle"><span class="floatingText">16.15 </span></div>
            <div class="floatingDot" data-section="#bis"><span class="floatingText">16.16 </span></div>
            <div class="floatingDot" data-section="#erp"><span class="floatingText">16.17 </span></div>
            <div class="floatingDot" data-section="#bibw"><span class="floatingText">16.18 </span></div>
            <div class="floatingDot" data-section="#prozessschritte"><span class="floatingText">16.19 </span></div>
            <div class="floatingDot" data-section="#zugriffsschnittstelle"><span class="floatingText">16.20 </span></div>
        </aside>
    </section>

    <article>
        <section class="container" id="datenbanksysteme">
            <h2>16.1 Fachbegriff Datenbanksysteme (Traditionelle Datenbanken (RDB), Objektorientierte</h2>
            <h3>Objektorientierte Datenbank: </h3>
            <p>Ein Vorteil objektorientierter Datenbanken ist, dass sie komplexere Daten speichern können als relationale Datenbanken.
                Ein Nachteil ist, dass sie schwieriger abzufragen sein können als relationale Datenbanken. Der Grund dafür ist dass objektorientierte Datenbanken nicht dieselbe Art von Abfragesprache verwenden wie relationale Datenbanken.
            </p>
            <h3>Relationale Datenbank:</h3>
            <p>Relationale Datenbanken haben viele Vorteile gegenüber objektorientierten Datenbanken. Ein Vorteil ist, dass sie viel einfacher abzufragen sind als objektorientierte Datenbanken.
                Die Verwendung einer relationalen Datenbank hat jedoch auch einige Nachteile. Ein Nachteil ist, dass sie Daten nur auf eine begrenzte Anzahl von Arten speichern können. Das bedeutet, dass Ihr Unternehmen, wenn es Daten in einem komplexen Format speichern muss, eine objektorientierte Datenbank verwenden muss.
            </p>
            <div class="quelle">
                <a class="btn" href="https://www.linkedin.com/pulse/die-vor-und-nachteile-objektorientierter-datenbanken-/?originalSubdomain=de" target="_blank">Quelle Objektorientierte Datenbank</a>
                <a class="btn" href="https://www.linkedin.com/pulse/die-vor-und-nachteile-objektorientierter-datenbanken-/?originalSubdomain=de" target="_blank">Quelle Relationale Datenbank</a>
            </div>
        </section>
        <section class="container" id="multimedia">
            <h2>16.2 Datenbanken, Multimedia - Datenbanken (GIS), Data - Warehouse und OLAP)</h2>
            <h3>Multimedia (GIS): </h3>
            <p>Multimedia-Datenbanksysteme (MMDBS) sind Datenbanksysteme, die außer einfach strukturierten Daten (Zahlen, Zeichenketten) auch noch digitale Medien speichern können. Sie sollen insbesondere die Datenun- abhängigkeit für solche Mediendaten realisieren. Datenunabhängigkeit ist hier leider nicht selbstverständlich. </p>
            <h3>Data Warehouse: </h3>
            <p>Ein Data Warehouse speichert aktuelle und historische Daten für das gesamte Unternehmen und dient als Grundlage für BI und Analysen. Data Warehouses verwenden einen Datenbankserver, um Daten aus den Datenbanken eines Unternehmens zu beziehen. </p>
            <h3>OLAP: </h3>
            <p>Online Analytical Processing (OLAP) ist eine Methode, die es Benutzern ermöglicht, Daten einfach und selektiv zu extrahieren und abzufragen, um sie aus verschiedenen Blickwinkeln zu analysieren. OLAP-Abfragen helfen unter anderem bei Trendanalysen, Finanzberichterstattungen, Umsatzprognosen, Budgetierung und anderen Planungszwecken. </p>

            <p>Eine Datenbank, auch Datenbanksystem genannt, ist ein System zur elektronischen Datenverwaltung. Die wesentliche Aufgabe einer Datenbank ist es, große Datenmengen effizient, widerspruchsfrei und dauerhaft zu speichern und benötigte Teilmengen in unterschiedlichen, bedarfsgerechten Darstellungsformen für Benutzer und Anwendungsprogramme bereitzustellen.  </p>
            <p>Ein Datenbanksystem besteht aus zwei Teilen: der Verwaltungssoftware, genannt Datenbankmanagementsystem (DBMS), und der Menge der zu verwaltenden Daten, der Datenbank (DB). Die Verwaltungssoftware organisiert intern die strukturierte Speicherung der Daten und kontrolliert alle lesenden und schreibenden Zugriffe auf die Datenbank. Zur Abfrage und Verwaltung der Daten bietet ein Datenbanksystem eine Datenbanksprache an. </p>
            <p>Die gebräuchlichste Form einer Datenbank ist eine relationale Datenbank. Die Struktur der Daten wird durch ein Datenbankmodell festgelegt. </p>
            <p>Geographische Informationssysteme (GIS) ist ein Informationssystem zur Erfassung, Bearbeitung, Organisation, Analyse und Präsentation räumlicher Daten. Geoinformationssysteme umfassen die dazu benötigte Hardware, Software, Daten und Anwendungen. Geoinformationssysteme werden unter anderem in der Geographie, Umweltforschung, Marketing, Stadtplanung, im Ressourcenmanagement und im Gesundheitswesen genutzt. Mithilfe eines GIS ist es Katastrophenschutzbeauftragten beispielsweise möglich, Informationen für Evakuierungspläne zusammenzustellen. </p>
            <p>Ein Data Warehouse ist eine für Analysezwecke optimierte zentrale Datenbank, die Daten aus mehreren, in der Regel heterogenen Quellen zusammenführt. </p>
            <p>Online Analytical Processing (OLAP) wird neben dem Data-Mining zu den Methoden der analytischen Informationssysteme gezählt. OLAP wird weiterhin den hypothesengestützten Analysemethoden zugeordnet. Der Analyst muss vor der eigentlichen Untersuchung wissen, welche Anfragen er an das OLAP-System stellen möchte. Seine Hypothese wird dann durch das Analyseergebnis bestätigt oder widerlegt. OLAP-Systeme bilden in diesem Zusammenhang oft die technologische Grundlage für aktuelle Business-Intelligence Anwendungen. Typische Einsatzszenarien für entsprechende OLAP-Systeme sind u.a. das Berichtswesen und Analyse, aber auch Planung und Budgetierung in folgenden Bereichen: Controlling, Finanzabteilungen, Vertrieb, Produktion, Personal und Management Unternehmenssteuerung. </p>
            <div class="quelle">
                <a class="btn" href="https://wwwlgis.informatik.uni-kl.de/archiv/wwwdvs.informatik.uni-kl.de/courses/MMDB/WS2003/Vorlesungsunterlagen/Einfuehrung.full.pdf" target="_blank">Quelle Multimedia (GIS)</a>
                <a class="btn" href="https://www.sap.com/austria/products/technology-platform/datasphere/what-is-a-data-warehouse.html#:~:text=Ein%20Data%20Warehouse%20speichert%20aktuelle,Datenbanken%20eines%20Unternehmens%20zu%20beziehen" target="_blank">Quelle Data Warehouse</a>
                <a class="btn" href="https://www.computerweekly.com/de/definition/Online-Analytical-Processing-OLAP" target="_blank">Quelle OLAP</a>
                <a class="btn" href="https://de.wikipedia.org/wiki/Datenbank" target="_blank">Quelle</a>
            </div>
        </section>
        <section class="container" id="datenbankabfragen">
            <h2>16.3 Fachbegriffe zu Datenbank&shy;abfragen (z.B.: SQL, SQL/XML)</h2>
            <div class="codeContainer">
                <h3>Einfache SQL-Abfragen und ihre Anwendungen</h3>
                <h4>Einfache Abfrage</h4>
                <pre class="codeBlock"><code>SELECT * FROM Student;</code></pre>
                <p>Listet alle Spalten und alle Zeilen der Tabelle Student auf.</p>
                <h4>Abfrage mit Spaltenauswahl</h4>
                <pre class="codeBlock"><code>SELECT VorlNr, Titel FROM Vorlesung;</code></pre>
                <p>Listet die Spalten VorlNr und Titel aller Zeilen der Tabelle Vorlesung auf.</p>
                <h4>Abfrage mit eindeutigen Werten (DISTINCT)</h4>
                <pre class="codeBlock"><code>SELECT DISTINCT MatrNr FROM hoert;</code></pre>
                <p>Listet nur unterschiedliche Einträge der Spalte MatrNr aus der Tabelle hoert auf. Dies zeigt die Matrikelnummern aller Studenten, die mindestens eine Vorlesung hören, wobei mehrfach auftretende Matrikelnummern nur einmal ausgegeben werden.</p>
                <h4>Abfrage mit Umbenennung (AS)</h4>
                <pre class="codeBlock"><code>SELECT MatrNr AS Matrikelnummer, Name FROM Student;</code></pre>
                <p>Listet die Spalten MatrNr und Name aller Zeilen der Tabelle Student auf. MatrNr wird beim Anzeigeergebnis als Matrikelnummer aufgeführt.</p>
                <h4>Abfrage mit Filter (WHERE)</h4>
                <pre class="codeBlock"><code>SELECT VorlNr, Titel FROM Vorlesung WHERE Titel = 'ET';</code></pre>
                <p>Listet VorlNr und Titel aller derjenigen Zeilen der Tabelle Vorlesung auf, deren Titel ET ist.</p>
                <h4>Abfrage mit Filter nach Inhalt (WHERE ... LIKE ...)</h4>
                <pre class="codeBlock"><code>SELECT Name FROM Student WHERE Name LIKE 'F%';</code></pre>
                <p>Listet die Namen aller Studenten auf, deren Name mit F beginnt (im Beispiel: Fichte und Fauler). LIKE kann mit verschiedenen Platzhaltern verwendet werden: _ steht für ein einzelnes beliebiges Zeichen, % steht für eine beliebige Zeichenfolge. Manche Datenbanksysteme bieten weitere solcher Wildcard-Zeichen an, etwa für Zeichenmengen.</p>
            </div>
            <div class="quelle">
                <a class="btn" href="https://de.wikipedia.org/wiki/SQL#Einfache_Abfrage" target="_blank">Quelle</a>
                <a class="btn" href="https://learnsql.de/kurs/sql-abfragen " target="_blank">Quelle</a>
            </div>
        </section>
        <section class="container" id="dbms">
            <h2>16.4 Fachbegriff Datenbank&shy;managementsystem (DBMS)</h2>
            <p>Ein Datenbankmanagementsystem ist eine Software, die die Organisation, Speicherung und den effizienten Zugriff auf Daten in einer Datenbank ermöglicht. Es verwaltet Datenbankstrukturen, stellt Schnittstellen für Datenabfragen bereit, gewährleistet die Integrität der Daten und bietet Funktionen wie Sicherheit und Transaktionskontrolle. DBMS erleichtern die Verwaltung großer Mengen von strukturierten Informationen in Unternehmen und Anwendungen.
                <br>
                Beispiele: MySQL, Oracle Database, Microsoft SQL Server, MongoDB
            </p>
            <div class="quelle">
                <a class="btn" href="https://www.ionos.de/digitalguide/hosting/hosting-technik/datenbankmanagementsystem-dbms-erklaert/ " target="_blank">Quelle</a>
            </div>
        </section>
        <section class="container" id="cms">
            <h2>16.5 Fachbegriff Content Management System (CMS)</h2>
            <p>Ein Content Management System (CMS) ist eine Softwareanwendung, die es Benutzern ermöglicht, digitale Inhalte wie Texte, Bilder, Videos und andere multimediale Elemente effizient zu erstellen, zu bearbeiten, zu organisieren, zu veröffentlichen und zu verwalten. Ein CMS wird häufig verwendet, um Websites, Blogs, Portale und andere Arten von Webanwendungen zu erstellen und zu verwalten. Hier sind einige wichtige Merkmale und Funktionen von CMS: </p>
            <ul class="left" style="list-style: decimal">
                <li><strong>Inhaltsbearbeitung: </strong>CMS bieten in der Regel eine benutzerfreundliche Oberfläche zur Erstellung und Bearbeitung von Inhalten, die es Benutzern ermöglicht, Inhalte direkt im Webbrowser zu erstellen und zu bearbeiten, ohne technische Kenntnisse über HTML oder andere Programmiersprachen zu benötigen. </li>
                <li><strong>Inhaltsorganisation: </strong>CMS ermöglichen es Benutzern, Inhalte in Kategorien, Tags und andere hierarchische Strukturen zu organisieren, um eine effiziente Verwaltung großer Mengen von Inhalten zu ermöglichen. </li>
                <li><strong>Versionierung: </strong>Viele CMS bieten Funktionen zur Versionierung von Inhalten, die es Benutzern ermöglichen, ältere Versionen von Inhalten wiederherzustellen oder zu vergleichen und Änderungen nachzuverfolgen. </li>
                <li><strong>Benutzerverwaltung und Rollenberechtigungen: </strong>CMS bieten Funktionen zur Verwaltung von Benutzern und zur Festlegung von Rollen und Berechtigungen, um den Zugriff auf bestimmte Funktionen und Inhalte zu steuern und die Sicherheit zu gewährleisten. </li>
                <li><strong>Vorlagen und Designs: </strong>CMS bieten oft eine Vielzahl von vorgefertigten Vorlagen und Designs, die es Benutzern ermöglichen, schnell und einfach ansprechende Websites zu erstellen. Sie ermöglichen auch die Anpassung von Designs durch die Verwendung von Themes und Templates. </li>
                <li><strong>Plugins und Erweiterungen: </strong>Viele CMS bieten eine Vielzahl von Plugins, Erweiterungen und Integrationen, die zusätzliche Funktionen und Funktionalität hinzufügen, wie z.B. E-Commerce, Social-Media-Integration, SEO-Tools und mehr. </li>
                <li><strong>SEO-Freundlichkeit: </strong>Moderne CMS bieten Funktionen zur Optimierung von Websites für Suchmaschinen (SEO), wie z.B. die Anpassung von Meta-Tags, die Erstellung von suchmaschinenfreundlichen URLs und die Optimierung von Seitengeschwindigkeit und Leistung. </li>
            </ul>
            <p>Ein CMS erleichtert die Verwaltung und Aktualisierung von Webinhalten erheblich und ermöglicht es Unternehmen, Organisationen und Einzelpersonen, eine professionelle Online-Präsenz ohne umfangreiche technische Kenntnisse zu erstellen und zu pflegen. Zu den bekannten CMS gehören WordPress, Joomla, Drupal, TYPO3, Wix und viele andere. </p>
            <div class="quelle">
                <a class="btn" href="https://de.wikipedia.org/wiki/Content-Management-System#:~:text=Ein%20Content%2DManagement%2DSystem%20(,Digital%20Signage%20und%20anderen%20Medienformen." target="_blank">Quelle</a>
            </div>
        </section>
        <section class="container" id="zusammenhang">
            <h2>16.6 Fachbegriff Integrität im Zusammenhang mit Datenbanken</h2>
            <p>Durch die Datenintegrität wird sichergestellt, dass die in Ihrer Datenbank gespeicherten Daten gefunden und mit anderen Daten verknüpft werden können</p>
            <p>Die Datenintegrität in einer Datenbank deckt alle Aspekte der Datenqualität ab und verbessert sich weiter, indem mehrere Regeln und Verfahren ausgeführt werden, die überwachen, wie Informationen eingegeben, hinterlegt, übertragen werden</p>
            <ul class="left">
                <li>Beschränken Sie den Zugriff auf Daten und ändern Sie Berechtigungen, um Änderungen an Daten durch nicht genehmigte Parteien einzuschränken. </li>
                <li>Konzentrieren Sie sich auf die Datenvalidierung, um die Richtigkeit der Daten bei der Erfassung oder Integration sicherzustellen. </li>
                <li>Führen Sie eine regelmäßige Datensicherung durch. </li>
                <li>Verwenden Sie Protokolle, um zu überwachen, wann Daten eingegeben, geändert oder gelöscht werden. </li>
                <li>Führen Sie systematische interne Audits durch, um sicherzustellen, dass die Informationen auf dem neuesten Stand sind. </li>
            </ul>
            <div class="quelle">
                <a class="btn" href="https://www.astera.com/de/type/blog/data-integrity-in-a-database/" target="_blank">Quelle</a>
            </div>
        </section>
        <section class="container" id="redundanz">
            <h2>16.7 Fachbegriff Redundanz im Zusammenhang mit Datenbanken</h2>
            <p>In Datenbanken bezieht sich der Fachbegriff "Redundanz" auf das Vorhandensein derselben Dateninformationen an mehreren Stellen innerhalb der Datenbank oder zwischen verschiedenen Datenbanken. Dies kann aus verschiedenen Gründen auftreten, einschließlich fehlender Normalisierung, ineffizienter Datenmodellierung oder unzureichender Datenbankwartung. Hier sind einige Aspekte, die im Zusammenhang mit Redundanz in Datenbanken wichtig sind: </p>
            <ul class="left">
                <li><strong>Datenintegrität: </strong>Datenintegrität: Redundanz kann die Datenintegrität beeinträchtigen, da Inkonsistenzen auftreten können, wenn sich redundante Daten an verschiedenen Stellen widersprechen oder inkonsistent aktualisiert werden. </li>
                <li><strong>Speicherplatzverbrauch: </strong>Durch Redundanz kann unnötig Speicherplatz in der Datenbank verwendet werden, da dieselben Dateninformationen mehrmals gespeichert werden müssen. </li>
                <li><strong>Aktualisierungsschwierigkeiten: </strong>Wenn redundante Daten vorhanden sind, müssen Änderungen oder Aktualisierungen an diesen Daten an mehreren Stellen vorgenommen werden, was die Wartung und Verwaltung der Datenbank erschwert und die Gefahr von Inkonsistenzen erhöht. </li>
                <li><strong>Performance: </strong>Redundanz kann sich negativ auf die Performance auswirken, da zusätzliche Ressourcen für das Speichern und Aktualisieren redundanter Daten benötigt werden. Dies kann zu längeren Abfragen und langsameren Antwortzeiten führen. </li>
            </ul>
            <p>Um Redundanz in Datenbanken zu reduzieren oder zu eliminieren, werden verschiedene Techniken angewendet, darunter: </p>
            <ul class="left">
                <li><strong>Normalisierung: </strong>Durch Normalisierung werden Daten in logisch zusammengehörige Tabellenstrukturen organisiert, um Redundanz zu minimieren und die Datenintegrität zu verbessern. </li>
                <li><strong>Verwendung von Fremdschlüsseln: </strong>Die Verwendung von Fremdschlüsseln und Beziehungen zwischen Tabellen kann dazu beitragen, Datenkonsistenz sicherzustellen und Redundanz zu reduzieren. </li>
                <li><strong>Datenbankdesign-Prinzipien: </strong>Die Einhaltung bewährter Datenbankdesign-Prinzipien wie dem Third Normal Form (3NF) kann dazu beitragen, Redundanz zu reduzieren und die Effizienz der Datenbank zu verbessern. </li>
                <li><strong>Datenbereinigung und -migration: </strong>Regelmäßige Datenbereinigung und -migration können dazu beitragen, redundante Daten zu identifizieren und zu entfernen oder zu konsolidieren. </li>
            </ul>
            <p>Die Reduzierung von Redundanz in Datenbanken trägt dazu bei, die Datenintegrität, die Effizienz und die Leistungsfähigkeit der Datenbank zu verbessern und die Wartungskosten zu senken. </p>
            <div class="quelle">
                <a class="btn" href="https://www.talend.com/de/resources/what-is-data-redundancy/#:~:text=Eine%20Datenredundanz%20liegt%20vor%2C%20wenn,mehreren%20Softwareplattformen%20oder%20Umgebungen%20vorliegen." target="_blank">Quelle</a>
            </div>
        </section>
        <section class="container" id="rdb">
            <h2>16.8 Vorgangsweise bei der Datenmodellierung (RDB)</h2>
            <p>Die Datenmodellierung für relationale Datenbanken ist ein mehrstufiger Prozess, der sicherstellt, dass die entworfene Datenbank die Geschäftsdaten effizient speichert, verarbeitet und bereitstellt.</p>
            <h4>Anforderungsanalyse</h4>
            <p>Sammlung und Analyse von Anforderungen durch Gespräche mit Stakeholdern, Analyse von Geschäftsprozessen und Bewertung von Datenbedarf.</p>
            <h4>Konzeptuelles Modellieren</h4>
            <p>Entwicklung eines konzeptuellen Schemas, oft in Form eines Entity-Relationship-Diagramms (ERD), das die hohen Datenstrukturen abbildet. Identifizierung von Entitäten, deren Attribute und Beziehungen.</p>
            <h4>Logisches Modellieren</h4>
            <p>Umwandlung des ERDs in ein relationales Modell, wobei Entitäten zu Tabellen, Beziehungen zu Fremdschlüsselverknüpfungen und Attribute zu Spalten werden. Definition der Primärschlüssel.</p>
            <h4>Normalisierung</h4>
            <p>Aufteilung der Tabellen in kleinere, logisch konsistente Einheiten, um Redundanzen zu reduzieren und die Datenintegrität zu erhöhen. Streben nach der dritten Normalform, es sei denn, Leistungsüberlegungen diktieren anders.</p>
            <h4>Physisches Modellieren</h4>
            <p>Anpassung des logischen Schemas an die physischen Gegebenheiten der Ziel-Datenbank, einschließlich der Festlegung von Speicherorten, dem Aufbau von Indizes zur Leistungssteigerung und der Implementierung von Sicherheitsmechanismen.</p>
            <h4>Implementierung und Testing</h4>
            <p>Erstellung der Datenbank mit dem physischen Schema und Durchführung von Tests, um sicherzustellen, dass die Anforderungen erfüllt sind und die Performance angemessen ist.</p>
            <h4>Überprüfung und Anpassung</h4>
            <p>Nach der Erstellung des Modells werden oft Anpassungen vorgenommen, um es an sich ändernde Anforderungen oder Erkenntnisse anzupassen.</p>
            <div class="quelle">
                <a class="btn" href="https://de.wikipedia.org/wiki/Datenmodellierung " target="_blank">Quelle</a>
            </div>
        </section>
        <section class="container" id="grundlegende">
            <h2>16.9 Kenntnisse über grundlegende Datenbank&shy;operationen (SELECT, FROM, WHERE, …)</h2>
            <p>SQL (Structured Query Language) bietet eine Vielzahl von Anweisungen für die Manipulation und Abfrage von Daten in relationalen Datenbanken. Hier sind einige der grundlegenden Anweisungen:</p>
            <ul>
                <li><strong>SELECT:</strong> Wird verwendet, um Daten aus einer oder mehreren Tabellen abzurufen.</li>
                <li><strong>FROM:</strong> Gibt die Tabelle an, aus der Daten abgerufen werden sollen.</li>
                <li><strong>WHERE:</strong> Filtert die Datensätze basierend auf einer bestimmten Bedingung.</li>
                <li><strong>INSERT INTO:</strong> Fügt neue Datensätze in eine Tabelle ein.</li>
                <li><strong>UPDATE:</strong> Aktualisiert vorhandene Datensätze in einer Tabelle.</li>
                <li><strong>DELETE:</strong> Löscht Datensätze aus einer Tabelle.</li>
            </ul>
            <h4>Beispiel eines SELECT Statements</h4>
            <div class="codeContainer">
                <pre class="codeBlock"><code>SELECT firstname, lastname FROM customer WHERE id = 1;</code></pre>
            </div>
            <p>Mit einem SELECT Statement können Daten aus bestimmten Tabellen abgefragt werden. Mit <strong>SELECT</strong> wählt man die Spalten aus, die im Ergebnis enthalten sein sollten, mit <strong>FROM</strong> wählt man die Tabelle aus und mit der <strong>WHERE</strong>-clause grenzt man das Ergebnis ein.</p>
            <div class="quelle">
                <a class="btn" href="https://www.ionos.at/digitalguide/server/knowhow/mysql-lernen-leicht-gemacht/" target="_blank">Quelle</a>
            </div>
        </section>
        <section class="container" id="normalformen">
            <h2>16.10 Kenntnisse über die ersten drei Normalformen im Zusammenhang mit Datenbanken</h2>
            <h3>Erste Normalform (1NF): </h3>
            <p>In der 1. Normalform müssen alle Attribute (Felder) einer Tabelle atomar sein, das heißt, sie dürfen keine wiederholenden Gruppen oder mehrwertigen Attribute enthalten. Jede Zelle in der Tabelle sollte einen einzigen Wert enthalten, und es sollten keine wiederholenden Gruppen von Attributen in einer Zeile vorhanden sein. </p>
            <h3>Zweite Normalform (2NF): </h3>
            <p>In der 2. Normalform muss eine Tabelle bereits in 1NF sein, und zusätzlich müssen alle Nicht-Schlüsselattribute von der gesamten Primschlüssel abhängen. Mit anderen Worten, es sollten keine teilweisen Abhängigkeiten von einem Teil des Primärschlüssels vorhanden sein. Wenn ein Primärschlüssel aus mehreren Attributen besteht, sollten alle anderen Attribute von der gesamten Kombination der Schlüsselattribute abhängen. </p>
            <h3>Dritte Normalform (3NF): </h3>
            <p>In der 3. Normalform muss eine Tabelle bereits in 2NF sein, und es dürfen keine Transitivitäten von Nicht-Schlüsselattributen abhängen. Das bedeutet, dass ein Nicht-Schlüsselattribut nicht von einem anderen Nicht-Schlüsselattribut abhängen sollte. Jedes Nicht-Schlüsselattribut sollte nur von einem Primärschlüsselattribut abhängen. </p>
            <div class="quelle">
                <a class="btn" href="https://www.nachhilfe-team.net/lernen-leicht-gemacht/normalformen/ " target="_blank">Quelle</a>
            </div>
        </section>
        <section class="container" id="primärschlüssel">
            <h2>16.11 Fachbegriffe Primärschlüssel, Fremdschlüssel, Relationen</h2>
            <p><strong>Primärschlüssel (Primary Key): </strong>Ein einzigartiges Merkmal, das jeden Datensatz in einer Tabelle eindeutig identifiziert. Dies kann ein einzelnes Feld oder eine Kombination von Feldern sein, solange die Gesamtheit einzigartig bleibt. Ein typisches Beispiel ist die Mitarbeiternummer in einer Mitarbeitertabelle. </p>
            <p><strong>Fremdschlüssel (Foreign Key): </strong>Ein Feld oder eine Gruppe von Feldern in einer Tabelle, die auf den Primärschlüssel einer anderen Tabelle verweisen. Fremdschlüssel definieren und verstärken die Beziehung zwischen den Daten zweier Tabellen, wodurch die Konsistenz und Integrität der Datenbank gewährleistet werden. Zum Beispiel könnte in einer Tabelle für Arbeitsaufträge das Feld "Mitarbeiternummer" als Fremdschlüssel dienen, der auf den Primärschlüssel in der Mitarbeitertabelle verweist. </p>
            <p><strong>Relationen (Relations): </strong>Die Art der Beziehungen zwischen Tabellen in einer relationalen Datenbank, definiert durch Primär- und Fremdschlüssel. Diese Beziehungen helfen dabei, Daten effizient zu organisieren und abzufragen, ohne Duplikate zu erstellen. Wichtige Beziehungstypen sind: </p>
            <p><strong>1:1-Beziehung: </strong>Ein Datensatz in Tabelle A ist genau einem Datensatz in Tabelle B zugeordnet, und umgekehrt. </p>
            <p><strong>1:n-Beziehung: </strong>Ein Datensatz in Tabelle A kann mit mehreren Datensätzen in Tabelle B verknüpft sein, aber jeder Datensatz in Tabelle B ist nur einem Datensatz in Tabelle A zugeordnet. </p>
            <p><strong>n:m-Beziehung: </strong>Datensätze in Tabelle A können mit mehreren Datensätzen in Tabelle B verknüpft sein und umgekehrt </p>
            <div class="quelle">
                <a class="btn" href="https://databasecamp.de/daten/primaerschluessel#:~:text=Prim%C3%A4rschl%C3%BCssel%20werden%20verwendet%2C%20um%20eindeutige,w%C3%A4hrend%20Fremdschl%C3%BCssel%20Nullwerte%20enthalten%20k%C3%B6nnen." target="_blank">Quelle</a>
            </div>
        </section>
        <section class="container" id="indexes">
            <h2>16.12 Kenntnis über Vor- und Nachteile bei Verwendung eines Indexes</h2>
            <p>Ein Datenbankindex, oder kurz Index, ist eine von der Datenstruktur getrennte Indexstruktur in einer Datenbank, die die Suche und das Sortieren nach bestimmten Feldern beschleunigt. </p>
            <p>Ein Index besteht aus einer Ansammlung von Zeigern (Verweisen), die eine Ordnungsrelation auf eine oder mehrere Spalten in einer Tabelle definieren. Wird bei einer Abfrage eine indizierte Spalte als Suchkriterium herangezogen, sucht das Datenbankmanagementsystem (DBMS) die gewünschten Datensätze anhand dieser Zeiger. </p>
            <h3>Vorteile: </h3>
            <p>Der Einsatz von Indizes empfiehlt sich für Datenbanken die große Datenmengen speichern und sehr häufig abgefragt werden. Hier kommt es darauf an welche Informationen dabei eine zentrale Rolle spielen.
                Welcher Index bei einer Abfrage tatsächlich verwendet wird, entscheidet in letzter Instanz der Abfrageoptimierer der Datenbank. Dieser erstellt für eine Abfrage mehrere Ausführungspläne, um die Kosten für die Abfrage zu ermitteln. Wird diese nun ausgeführt, wählt er den kostengünstigsten Ausführungsplan. Dieser berücksichtigt nicht nur Indizes, sondern auch die Systemauslastung. </p>
            <h3>Nachteile: </h3>
            <p>Das Anlegen von Indexstrukturen führt zur Belegung von Plattenspeicher und kann bei einer großen Anzahl von Indizes einen nicht unerheblichen Speicherverbrauch verursachen.
                Ein weiterer Nachteil ist, dass der Einsatz von Indizes zu einem größeren Aufwand beim Schreiben von Datensätzen führt. Das Datenbankmanagementsystem muss in diesem Fall auch den Index berücksichtigen und diesen entsprechend laden. Je mehr Indizes eine Tabelle hat, desto größer ist der Performance-Verlust beim Speichern neuer Datensätze. </p>
            <div class="quelle">
                <a class="btn" href="https://de.wikipedia.org/wiki/Datenbankindex " target="_blank">Quelle</a>
                <a class="btn" href="https://www.datenbanken-verstehen.de/datenmodellierung/datenbank-index/ " target="_blank">Quelle</a>
            </div>
        </section>
        <section class="container" id="freeware">
            <h2>16.13 Vor- und Nachteile von Freeware Datenbanken</h2>
            <p>Freeware-Datenbanken sind Datenbankmanagement-Systeme (DBMS), die kostenlos verfügbar sind. Hier sind einige der Vor- und Nachteile:</p>
            <h4>Vorteile:</h4>
            <ul class="left">
                <li><strong>Kostenlos:</strong> Der offensichtlichste Vorteil ist, dass sie kostenlos sind, was besonders bei Budgetbeschränkungen vorteilhaft sein kann.</li>
                <li><strong>Community-Support:</strong> Eine aktive Benutzer-Community kann zur schnelleren Problemlösung beitragen, da Nutzer ihre Erfahrungen und Lösungen teilen.</li>
                <li><strong>Einfache Nutzung:</strong> Viele sind benutzerfreundlich und ermöglichen eine einfache Implementierung, was für kleinere Unternehmen oder Entwickler mit begrenzten Ressourcen nützlich ist.</li>
                <li><strong>Flexibilität:</strong> Sie sind oft offen für Anpassungen und können in verschiedenen Umgebungen eingesetzt werden, was sie flexibel und vielseitig macht.</li>
            </ul>
            <h4>Nachteile:</h4>
            <ul class="left">
                <li><strong>Begrenzter Funktionsumfang:</strong> Sie bieten möglicherweise nicht denselben Funktionsumfang wie kostenpflichtige Alternativen, was fortgeschrittene Funktionen und Leistungsoptimierungen angeht.</li>
                <li><strong>Begrenzter Support:</strong> Der Support kann im Vergleich zu kommerziellen Datenbanken begrenzt sein, was für Unternehmen mit geschäftskritischen Anwendungen ein Nachteil sein kann.</li>
                <li><strong>Sicherheitsbedenken:</strong> Die Sicherheit kann eine Herausforderung darstellen, da die Behebung von Sicherheitslücken länger dauern und es weniger Ressourcen für die Sicherheitsüberwachung geben kann.</li>
                <li><strong>Skalierbarkeit:</strong> Die Skalierbarkeit könnte geringer sein als bei kostenpflichtigen Lösungen, was bei starkem Wachstum einer Anwendung zu Leistungsproblemen führen kann.</li>
            </ul>
            <div class="quelle">
                <a class="btn" href="https://www.ionos.at/digitalguide/hosting/hosting-technik/open-source-datenbanken-im-vergleich/" target="_blank">Quelle</a>
            </div>
        </section>
        <section class="container" id="sicherungsmethoden">
            <h2>16.14 Kenntnisse über Sicherungsmethoden</h2>
            <p><strong>Optische Medien</strong> wie CDs, CDs-RW, DVDs, DVD-RW und Blu-rays sind für die Archivierung von Musik und Fotos im privaten Bereich geeignet. Allerdings erfordern sie optimale Lagerbedingungen und sind anfällig für Kratzer, Aufkleber mit schädlichen Lösungsmitteln, zu harte Spitzen bei der Beschriftung, Fingerabdrücke und Sonneneinstrahlung. </p>
            <p><strong>USB-Sticks, Flash-Karten und SSD-Festplatten</strong> sind im Allgemeinen gute Optionen für die Datenarchivierung. Sie sind langlebig, aber die Qualität ist entscheidend, um Verschleiß durch wiederholtes Beschreiben der Speicherzellen zu verhindern. </p>
            <p><strong>Festplatten mit USB-, Firewire- oder Netzwerkanschlüssen (NAS- und SAN-Systeme) </strong>Festplatten mit USB-, Firewire- oder Netzwerkanschlüssen (NAS- und SAN-Systeme) eignen sich gut als Langzeitspeicher aufgrund ihrer großen Kapazitäten und ihres geringen Platzbedarfs. Unter Verwendung von RAID-Systemen oder S.M.A.R.T. können Hardwareschäden minimiert werden. Vorgefertigte Netzwerkspeicher-Systeme bieten diese Vorteile bereits von Anfang an. </p>
            <p><strong>Die Cloud </strong>Die Cloud als Datensicherungsmedium bietet verschlüsselte Übertragung und Ablage der Daten. Datenverlust durch Hardwaredefekte ist bei professionellen Anbietern unwahrscheinlich, da die Daten redundant auf verschiedenen Systemen gesichert werden. Die Wiederherstellung großer Datenmengen kann jedoch länger dauern, und fortlaufende Kosten sind zu berücksichtigen. Bei der Wahl eines Cloud-Providers ist ein europäischer Anbieter aus Datenschutzgründen ratsam. </p>
            <div class="quelle">
                <a class="btn" href="https://wdns.at/thema-datensicherung-sicherungsmedien-und-aufbewahrungsorte/ " target="_blank">Quelle</a>
            </div>
        </section>
        <section class="container" id="sperrtabelle">
            <h2>16.15 Fachbegriff Sperrtabelle und Sperrverhalten</h2>
            <p>Der Fachbegriff "Sperrtabelle" bezieht sich auf eine Datenbanktabelle, die verwendet wird, um Datensätze während eines bestimmten Prozesses oder einer bestimmten Transaktion zu sperren, um Konsistenz und Integrität der Daten sicherzustellen. Das Sperrverhalten beschreibt, wie und in welchem Umfang Sperren auf Datensätze oder Tabellen angewendet werden, um Dateninkonsistenzen und Wettbewerbsbedingungen zu vermeiden. Hier sind einige wichtige Aspekte des Sperrverhaltens: </p>
            <ul class="left">
                <li><strong>Granularität der Sperren: </strong>Das Sperrverhalten kann variieren, je nachdem, ob Sperren auf Zeilenebene, Tabellenebene oder auf anderen Ebenen angewendet werden. Granulare Sperren auf Zeilenebene ermöglichen eine feinere Steuerung und minimieren die Auswirkungen von Sperren auf die gleichzeitige Zugriffszeit anderer Benutzer. </li>
                <li><strong>Arten von Sperren: </strong>Das Sperrverhalten kann verschiedene Arten von Sperren umfassen, darunter Lesesperren (Shared Locks), Schreibsperren (Exclusive Locks) und Update-Sperren (Update Locks). Lesesperren ermöglichen mehreren Benutzern gleichzeitig den Lesezugriff auf Daten, während Schreibsperren den exklusiven Schreibzugriff auf Daten gewähren. </li>
                <li><strong>auer der Sperren: </strong>DDas Sperrverhalten kann auch die Dauer der Sperren beeinflussen, einschließlich der Möglichkeit, Sperren für kurze Zeit oder für die gesamte Dauer einer Transaktion aufrechtzuerhalten. </li>
                <li><strong>Transaktionsisolationsstufen: </strong>Das Sperrverhalten wird oft in Bezug auf die Transaktionsisolationsstufen betrachtet, die festlegen, wie stark Transaktionen voneinander isoliert sind und welche Art von Sperren zwischen Transaktionen angewendet werden. Beispiele für Transaktionsisolationsstufen sind READ UNCOMMITTED, READ COMMITTED, REPEATABLE READ und SERIALIZABLE. </li>
                <li><strong>Deadlocks und Konflikte: </strong>Ein wichtiger Aspekt des Sperrverhaltens ist die Behandlung von Deadlocks und Konflikten, die auftreten können, wenn zwei oder mehr Transaktionen aufeinander warten, um Sperren freizugeben. Das Sperrverhalten sollte Mechanismen zur Erkennung und Auflösung von Deadlocks bereitstellen. </li>
            </ul>
            <p>Das Sperrverhalten ist ein wesentlicher Bestandteil von Datenbankmanagementsystemen (DBMS), da es die gleichzeitige Verarbeitung von Daten und die Konsistenz der Datenbank sicherstellt. Eine angemessene Konfiguration und Verwaltung des Sperrverhaltens ist entscheidend, um eine gute Leistung, Skalierbarkeit und Zuverlässigkeit von Datenbankanwendungen sicherzustellen. </p>
            <div class="quelle">
                <a class="btn" href="https://www.datenbanken-verstehen.de/lexikon/sperrverfahren-datenbanken/" target="_blank">Quelle</a>
            </div>
        </section>
        <section class="container" id="bis">
            <h2>16.16 Fachbegriff BIS (Betriebliches Informationssystem)</h2>
            <h3>Betriebliches Informationssystem</h3>
            <p>Ein betriebliches Informationssystem ist ein Informationssystem, dessen vorrangige Rolle es ist, den betrieblichen Funktionen Daten effizient zur Verfügung zu stellen.</p>
            <h4>Ansätze zur Schaffung eines betrieblichen Informationssystems:</h4>
            <ul>
                <li><strong>Funktionsorientierte Vorgehensweise:</strong> Betrachtet werden betriebliche Funktionen wie Einkauf. Zu jeder Funktion werden Datenstrukturen bestimmt, die sich in getrennten Datenbeständen widerspiegeln.</li>
                <li><strong>Datenorientierte Vorgehensweise:</strong> Funktionsunabhängig werden Daten betrachtet, die für die untersuchten betrieblichen Funktionen relevant sind. Ziel ist ein globales konzeptionelles Datenmodell in einer gemeinsamen Datenbasis. Die Verwaltung der Datenbasis übernimmt ein Datenbankverwaltungssystem (DBVS).</li>
            </ul>
            <h4>Unterkategorien von betrieblichen Informationssystemen:</h4>
            <ul>
                <li><strong>Administrations- und Dispositionssysteme:</strong> Systeme der operativen Anwendung.</li>
                <li><strong>Führungssysteme:</strong> Systeme zur Entscheidungs- und Planungsunterstützung.</li>
                <li><strong>Querschnittssysteme:</strong> Bereichsübergreifende Hilfssysteme, z. B. zur Kommunikation, Office-Programme.</li>
            </ul>
            <div class="quelle">
                <a class="btn" href="https://de-academic.com/dic.nsf/dewiki/165341" target="_blank">Quelle</a>
            </div>
        </section>
        <section class="container" id="erp">
            <h2>16.17  Kenntnisse/Fachbegriff ERP Systeme</h2>
            <p>ERP steht für Enterprise Resource Planning, auf Deutsch "Unternehmensressourcenplanung". Ein ERP-System ist eine integrierte Softwarelösung, die verwendet wird, um alle Geschäftsprozesse eines Unternehmens zu automatisieren, zu verwalten und zu integrieren. Es dient dazu, die Ressourcen eines Unternehmens effizient zu planen, zu steuern und zu optimieren. Hier sind einige wichtige Kenntnisse und Merkmale von ERP-Systemen: </p>
            <ul class="left">
                <li><strong>Integrierte Anwendungssuite: </strong>ERP-Systeme umfassen eine breite Palette von Anwendungen, die verschiedene Geschäftsfunktionen unterstützen, einschließlich Finanzwesen, Buchhaltung, Personalwesen, Beschaffung, Vertrieb, Lagerhaltung, Produktion und mehr. Diese Anwendungen sind in der Regel in einem zentralen System integriert und teilen eine gemeinsame Datenbank. </li>
                <li><strong></strong>Zentrale Datenbank: Ein zentrales Merkmal von ERP-Systemen ist eine gemeinsame Datenbank, die alle Geschäftsdaten des Unternehmens speichert. Dies ermöglicht eine nahtlose Integration und einen einheitlichen Datenzugriff für alle Anwendungen und Benutzer innerhalb des Unternehmens. </li>
                <li><strong></strong>Automatisierung von Geschäftsprozessen: ERP-Systeme automatisieren und optimieren Geschäftsprozesse, indem sie repetitive Aufgaben automatisieren, den Informationsfluss verbessern und die Effizienz steigern. Dies ermöglicht es Unternehmen, ihre Betriebskosten zu senken und die Produktivität zu steigern. </li>
                <li><strong></strong>Echtzeit-Informationen und Berichterstattung: ERP-Systeme bieten Echtzeit-Zugriff auf Geschäftsdaten und ermöglichen es Unternehmen, schnell fundierte Entscheidungen zu treffen. Sie bieten auch leistungsstarke Analyse- und Berichtsfunktionen, um Einblicke in die Leistung des Unternehmens zu gewinnen und Trends zu identifizieren. </li>
                <li><strong></strong>Skalierbarkeit und Anpassungsfähigkeit: ERP-Systeme sind in der Regel skalierbar und anpassungsfähig, um den sich ändernden Anforderungen und Wachstumszielen eines Unternehmens gerecht zu werden. Sie können auch durch Module und Add-Ons erweitert werden, um spezifische Anforderungen oder Branchenbedürfnisse zu erfüllen. </li>
                <li><strong></strong>Compliance und Sicherheit: ERP-Systeme bieten Funktionen zur Einhaltung gesetzlicher Vorschriften und Branchenstandards sowie Mechanismen zur Sicherung sensibler Unternehmensdaten und zum Schutz vor Cyberbedrohungen. </li>
            </ul>
            <p>Die Implementierung eines ERP-Systems kann eine bedeutende Investition für Unternehmen sein, aber es bietet auch eine Reihe von Vorteilen, darunter verbesserte Effizienz, bessere Entscheidungsfindung, erhöhte Kundenzufriedenheit und eine bessere Wettbewerbsposition. Es ist wichtig, das richtige ERP-System entsprechend den spezifischen Anforderungen und Zielen eines Unternehmens auszuwählen und eine sorgfältige Implementierung und Schulung durchzuführen, um den Erfolg des Projekts sicherzustellen </p>
            <div class="quelle">
                <a class="btn" href="https://de.wikipedia.org/wiki/Enterprise-Resource-Planning" target="_blank">Quelle</a>
            </div>
        </section>
        <section class="container" id="bibw">
            <h2>16.18 Kenntnisse / Fachbegriff BI/BW Systeme</h2>

            <div class="quelle">
                <a class="btn" href="" target="_blank">Quelle</a>
            </div>
        </section>
        <section class="container" id="prozessschritte">
            <h2>16.19 Kenntnisse der Abläufe und Prozessschritte (Auswählen DBMS, Erstellen des physischen Modells, Performance- und Stresstests, Datensicherheit, Datenschutz, Datenverschlüsselung – Kryptografie, Datenmigration) zum Umsetzen von Datenmodellen in eine Datenbank</h2>
            <p><strong>Business Intelligence</strong> (BI) bezieht sich auf Technologien, Anwendungen und Praktiken für die Sammlung, Integration, Analyse und Darstellung von Geschäftsinformationen. Der Zweck von BI ist es, bessere Geschäftsentscheidungen durch datengestützte Einblicke zu ermöglichen. Typische BI-Systemfunktionen umfassen Berichterstattung, Online Analytical Processing (OLAP), Datenanalyse, Dashboard-Entwicklung, Data Mining und Predictive Analytics. </p>
            <p><strong>Business Warehouse </strong>(BW) oder Business Warehousing bezieht sich oft auf SAP BW (SAP Business Warehouse), eine umfassende Data-Warehouse-Software, die Teil der SAP NetWeaver-Plattform ist. Es ermöglicht die Konsolidierung, Transformation und Bereitstellung von Daten, bietet Werkzeuge für die Datenextraktion, das Management und die Speicherung sowie Reporting-Funktionen. BW-Systeme sind darauf ausgelegt, Unternehmen bei der effektiven Nutzung ihrer Datenbestände zu unterstützen, indem sie Daten aus verschiedenen Quellen zusammenführen und für komplexe Analysen aufbereiten Lösungs Beispiele, POWER-BI -> Mircosoft
            </p>
            <div class="quelle">
                <a class="btn" href="https://de.wikipedia.org/wiki/Business_Intelligence " target="_blank">Quelle</a>
                <a class="btn" href="https://de.wikipedia.org/wiki/SAP_NetWeaver_Business_Intelligence " target="_blank">Quelle</a>
            </div>
        </section>
        <section class="container" id="zugriffsschnittstelle">
            <h2>16.20 Kenntnisse der Abläufe und Prozessschritte (Zugriffsschnittstelle, Zugriffstechnologie, Transaktionskonzept, Programmierung, Testreihen, Benutzerabnahmetest, Ergebnisprüfung)</h2>
            <h4>Auswählen eines DBMS:</h4>
            <ul>
                <li>Anforderungsanalyse: Identifizieren der Anforderungen Ihrer Anwendung oder Ihres Systems.</li>
                <li>Datenmodellierung: Auswahl des passenden Datenmodells (relational, dokumentenorientiert, graphenbasiert usw.).</li>
                <li>Skalierbarkeit: Berücksichtigung der erwarteten Datenmenge und des zukünftigen Bedarfs an Skalierbarkeit.</li>
                <li>Sicherheit: Auswahl eines DBMS mit geeigneten Sicherheitsfunktionen.</li>
                <li>Kosten: Berücksichtigung aller relevanten Kosten.</li>
            </ul>

            <h4>Erstellen des physischen Modells:</h4>
            <ul>
                <li>Umsetzung des logischen Modells in spezifische Datenbankobjekte (Tabellen, Indizes, Sichten usw.).</li>
                <li>Indexierung: Planung der zu indizierenden Spalten zur Leistungsverbesserung.</li>
                <li>Festlegung von Datentypen und Constraints zur Sicherstellung der Datenintegrität.</li>
                <li>Partitionierung: Entscheidung über die Partitionierung von Daten in Tabellen zur Leistungsoptimierung.</li>
                <li>Normalisierung/Denormalisierung: Anpassung des Modells für Datenkonsistenz und Leistung.</li>
            </ul>
            <div class="quelle">
                <a class="btn" href="https://www.ionos.de/digitalguide/hosting/hosting-technik/datenbankmanagementsystem-dbms-erklaert/" target="_blank">Quelle</a>
            </div>
        </section>
        <div class="center">
            <a class="btn" href="grundkenntnisseDesProgrammierens.php">Zurück zu Grundkenntnisse des Programmierens</a>
            <a class="btn" href="systementwicklungTestkonzepte.php">Weiter zu Systementwicklung / Testkonzepte</a>
        </div>
    </article>
</main>
<?php include'include/footer.php' ?>