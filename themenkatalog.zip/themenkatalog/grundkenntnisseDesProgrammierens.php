<?php
$title = 'Grundlagen der Programmierung: Von Algorithmen bis objektorientierter Programmierung';
$description = 'Entdecken Sie die Grundlagen der Programmierung, einschließlich der Stadien der Softwareentwicklung, Unterschiede zwischen prozeduraler und objektorientierter Programmierung, Algorithmen, Pseudocode, Sortier- und Suchalgorithmen, den Ablauf der Programmentwicklung, Aufbau einer Programmiersprache, Interpreter vs. Compiler, die Verwendung eines Debuggers, den Begriff Assembler, rekursive Funktionen, ASCII-Tabellen, Variablenarten, Datentypen, Unterschied zwischen Variable und Konstante, Gültigkeitsbereiche von Variablen, Schleifen, Verzweigungen und die Grundlagen der objektorientierten Programmierung.';
$keywords = 'Programmierung Grundlagen, Softwareentwicklung, prozedurale Programmierung, objektorientierte Programmierung, Algorithmen, Pseudocode, Sortieralgorithmen, Suchalgorithmen, Programmentwicklung, Programmiersprache Syntax, Interpreter, Compiler, Debugger, Assembler, rekursive Funktionen, ASCII-Tabellen, Variablenarten, Datentypen, Variable vs. Konstante, Gültigkeitsbereiche, Schleifen, Verzweigungen, objektorientierte Programmierung';
$canonical = 'https://www.codeabschlussguide.at/grundlagen-der-programmierung';
include 'include/header.php'
?>
<body>
<main class="responsive">
    <section>
        <h1>15) Grundkenntnisse des Programmierens</h1>
        <ul class="listLegend"  style="list-style: none">
            <li><a href="#softwareentwicklung">15.1 Stadien der Software&shy;entwicklung</a></li>
            <li><a href="#prozedurale">15.2 Fachbegriffe Prozedurale Programmierung, Objektorientierte Programmierung, Unterschiede</a></li>
            <li><a href="#algorithmus">15.3 Fachbegriff Algorithmus</a></li>
            <li><a href="#pseudocode">15.4 Fachbegriff Pseudocode</a></li>
            <li><a href="#sortieralgorithmen">15.5 Kenntnisse über Sortier&shy;algorithmen (Bubblesort, Quicksort)</a></li>
            <li><a href="#suchalgorithmen">15.6 Kenntnisse über Suchalgorithmen (sequentielle Suche, binäre Suche)</a></li>
            <li><a href="#programmentwicklung">15.7 Ablauf der Programmentwicklung</a></li>
            <li><a href="#programmiersprache">15.8 Fachbegriffe zum Aufbau einer Programmier&shy;sprache (Syntax, Semantik, Kommentare, Schlüsselwörter, Anweisung)</a></li>
            <li><a href="#interpreter">15.9 Fachbegriffe Interpreter und Compiler (Unterschiede, Vor- und Nachteile)</a></li>
            <li><a href="#debugger">15.10 Fachbegriff Debugger (Einsatz)</a></li>
            <li><a href="#assembler">15.11 Fachbegriff Assembler</a></li>
            <li><a href="#rekursive">15.12 Fachbegriff Rekursive Funktionen</a></li>
            <li><a href="#ascii">15.13 Kenntnisse über ASCII-Tabellen</a></li>
            <li><a href="#variablenarten">15.14 Kenntnisse über Variablenarten, Datentypen und Definitionen</a></li>
            <li><a href="#variable">15.15 Unterschied Variable und Konstante</a></li>
            <li><a href="#gültigkeitsbereiche">15.16 Gültigkeits&shy;bereiche (Lebensdauer) von Variablen</a></li>
            <li><a href="#schleifen">15.17 Fachbegriff Schleifen, Beispiele für Schleifen</a></li>
            <li><a href="#kopfgesteuert">15.18 Fachbegriffe "kopfgesteuert" bzw. "fußgesteuert" im Zusammenhang mit Schleifen</a></li>
            <li><a href="#verzweigungen">15.19 Kenntnisse über Verzweigungen und Fallunterscheidungen</a></li>
            <li><a href="#objektorientierten">15.20 Kenntnis der objektorientierten Programmierung (Klassen, Objekte, Vererbung, …)</a></li>
        </ul>
        <aside class="floatingNav">
            <div class="floatingDot" data-section="#softwareentwicklung"><span class="floatingText">15.1 </span></div>
            <div class="floatingDot" data-section="#prozedurale"><span class="floatingText">15.2 </span></div>
            <div class="floatingDot" data-section="#algorithmus"><span class="floatingText">15.3 </span></div>
            <div class="floatingDot" data-section="#pseudocode"><span class="floatingText">15.4 </span></div>
            <div class="floatingDot" data-section="#sortieralgorithmen"><span class="floatingText">15.5 </span></div>
            <div class="floatingDot" data-section="#suchalgorithmen"><span class="floatingText">15.6 </span></div>
            <div class="floatingDot" data-section="#programmentwicklung"><span class="floatingText">15.7 </span></div>
            <div class="floatingDot" data-section="#programmiersprache"><span class="floatingText">15.8 </span></div>
            <div class="floatingDot" data-section="#interpreter"><span class="floatingText">15.9 </span></div>
            <div class="floatingDot" data-section="#debugger"><span class="floatingText">15.10 </span></div>
            <div class="floatingDot" data-section="#assembler"><span class="floatingText">15.11 </span></div>
            <div class="floatingDot" data-section="#rekursive"><span class="floatingText">15.12 </span></div>
            <div class="floatingDot" data-section="#ascii"><span class="floatingText">15.13 </span></div>
            <div class="floatingDot" data-section="#variablenarten"><span class="floatingText">15.14 </span></div>
            <div class="floatingDot" data-section="#variable"><span class="floatingText">15.15 </span></div>
            <div class="floatingDot" data-section="#gültigkeitsbereiche"><span class="floatingText">15.16 </span></div>
            <div class="floatingDot" data-section="#schleifen"><span class="floatingText">15.17 </span></div>
            <div class="floatingDot" data-section="#kopfgesteuert"><span class="floatingText">15.18 </span></div>
            <div class="floatingDot" data-section="#verzweigungen"><span class="floatingText">15.19 </span></div>
            <div class="floatingDot" data-section="#objektorientierten"><span class="floatingText">15.20 </span></div>

        </aside>
    </section>

    <article>
        <section class="container" id="softwareentwicklung">
            <h2>15.1 Stadien der Software&shy;entwicklung</h2>
            <p>Die Softwareentwicklung durchläuft mehrere Stadien, die oft als Softwareentwicklungslebenszyklus (Software Development Life Cycle, SDLC) bezeichnet werden. Die genauen Phasen können je nach Modell und Methodik variieren, aber im Allgemeinen umfassen sie: </p>
            <h3>Anforderungsanalyse: </h3>
            <p>In dieser Phase werden die Anforderungen des Kunden oder der Stakeholder erfasst und analysiert, um ein klares Verständnis für die Funktionalitäten und Ziele des zu entwickelnden Systems zu erhalten. </p>
            <h3>Planung: </h3>
            <p>Basierend auf den Anforderungen wird ein Entwicklungsplan erstellt, der Ressourcen, Zeitpläne, Budgets und andere relevante Faktoren berücksichtigt. Die Planung legt den Rahmen für den gesamten Entwicklungsprozess fest. </p>
            <h3>Entwurf: </h3>
            <p>Während dieser Phase wird die Systemarchitektur entworfen, einschließlich der Aufteilung in Module oder Komponenten. Hier werden auch Designentscheidungen für Benutzeroberfläche, Datenbanken, Sicherheit und andere Aspekte getroffen. </p>
            <h3>Implementierung (Codierung): </h3>
            <p>In dieser Phase wird der eigentliche Code geschrieben und die Software gemäß den Spezifikationen und dem Design entwickelt. Die Programmierer setzen die Pläne aus der Entwurfsphase um.</p>
            <h3>Testen:</h3>
            <p>Die entwickelte Software wird verschiedenen Tests unterzogen, um sicherzustellen, dass sie den Anforderungen entspricht, fehlerfrei läuft und die erwartete Leistung erbringt. Dies umfasst Einheitstests, Integrationstests, Systemtests und möglicherweise auch Benutzertests. </p>
            <h3>Abnahme (Deployment): </h3>
            <p>Nach erfolgreichem Abschluss der Tests wird die Software in der Produktionsumgebung implementiert oder den Benutzern zur Verfügung gestellt. Dieser Prozess wird als Deployment oder Auslieferung bezeichnet.</p>
            <h3>Wartung und Aktualisierung: </h3>
            <p>Nach der Bereitstellung wird die Software gewartet und bei Bedarf aktualisiert. Fehlerkorrekturen, Leistungsoptimierungen und das Hinzufügen neuer Funktionen können Teil dieser Wartungsphase sein. </p>
            <div class="quelle">
                <a class="btn" href="https://www.seo-analyse.com/seo-lexikon/e/entwicklungsstadium/ " target="_blank">Quelle</a>
            </div>
        </section>
        <section class="container" id="prozedurale">
            <h2>15.2 Fachbegriffe Prozedurale Programmierung, Objektorientierte Programmierung, Unterschiede</h2>
            <p>Im prozeduralen Paradigma wird der Code in Funktionen und Prozeduren unterteilt, die miteinander interagieren, um das gewünschte Ergebnis zu erreichen. Daten und Verarbeitung sind getrennt,</p>
            <p>In der objektorientierten Programmierung ist der Code in Klassen und Objekten strukturiert, die Methoden und Attribute enthalten, Vererbung, polymofismus, Kapselung</p>
            <div class="quelle">
                <a class="btn" href="https://www.studysmarter.de/schule/informatik/programmieren-basics/prozedurale-programmierung/#:~:text=Im%20prozeduralen%20Paradigma%20wird%20der,die%20Methoden%20und%20Attribute%20enthalten. " target="_blank">Quelle</a>
            </div>
        </section>
        <section class="container" id="algorithmus">
            <h2>15.3 Fachbegriff Algorithmus</h2>
            <p>Ein Algorithmus ist eine eindeutige Handlungsvorschrift zur Lösung eines Problems oder einer Klasse von Problemen. Algorithmen bestehen aus endlich vielen, wohldefinierten Einzelschritten. Damit können sie zur Ausführung in ein Computerprogramm implementiert, aber auch in menschlicher Sprache formuliert werden. Bei der Problemlösung wird eine bestimmte Eingabe in eine bestimmte Ausgabe überführt. </p>
            <h3>Eigenschaften eines Algorithmus: </h3>
            <ul class="left" style="list-style: decimal">
                <li>Das Verfahren muss in einem endlichen Text eindeutig beschreibbar sein (Finitheit). </li>
                <li>Jeder Schritt des Verfahrens muss tatsächlich ausführbar sein (Ausführbarkeit). </li>
                <li>Das Verfahren darf zu jedem Zeitpunkt nur endlich viel Speicherplatz benötigen (Dynamische Finitheit).</li>
                <li>Das Verfahren darf nur endlich viele Schritte benötigen (Terminierung) </li>
            </ul>
            <p>Darüber hinaus wird der Begriff Algorithmus in praktischen Bereichen oft auf die folgenden Eigenschaften eingeschränkt: </p>
            <ul class="left" style="list-style: decimal">
                <li>Der Algorithmus muss bei denselben Voraussetzungen das gleiche Ergebnis liefern (Determiniertheit). </li>
                <li>Die nächste anzuwendende Regel im Verfahren ist zu jedem Zeitpunkt eindeutig definiert (Determinismus). </li>
            </ul>
            <div class="quelle">
                <a class="btn" href=" https://de.wikipedia.org/wiki/Algorithmus " target="_blank">Quelle</a>
            </div>
        </section>
        <section class="container" id="pseudocode">
            <h2>15.4 Fachbegriff Pseudocode</h2>
            <p>Pseudocode ist eine detaillierte und dennoch lesbare Beschreibung dessen, was ein Computerprogramm oder ein Algorithmus machen soll. Pseudocode wird in einer formal gestalteten, natürlichen Sprache und nicht in einer Programmiersprache ausgedrückt. </p>
            <p>Pseudocode wird oft als wichtiger Schritt im Entwicklungsprozess eines Programms verwendet. Es erlaubt Designern oder Programmierern, das Design detailliert auszudrücken und stellt dem Programmierer eine ausgearbeitete Vorlage für den nächsten Schritt zur Verfügung, Code in einer bestimmten Programmiersprache zu schreiben. </p>
            <p>Da Pseudocode detailliert und dennoch lesbar ist, kann er von einem Team von Designern und Programmierern geprüft werden, um sicherzustellen, dass die tatsächliche Programmierung den Designvorgaben entspricht. </p>
            <p>Das Abfangen von Fehlern in der Pseudocode-Phase ist weniger kostspielig als das Abfangen im späteren Entwicklungsprozess. Sobald der Pseudocode akzeptiert wurde, wird er mit dem Vokabular und der Syntax einer Programmiersprache neu geschrieben. Pseudocode wird manchmal in Verbindung mit computergestützten Softwareentwicklungsmethoden verwendet. </p>
            <p>Es ist möglich, Programme zu schreiben, die eine bestimmte Pseudocode-Sprache in eine bestimmte Programmiersprache umwandeln. </p>
            <div class="quelle">
                <a class="btn" href="https://www.computerweekly.com/de/definition/Pseudocode#:~:text=Pseudocode%20ist%20eine%20detaillierte%20und,nicht%20in%20einer%20Programmiersprache%20ausgedr%C3%BCckt " target="_blank">Quelle</a>
            </div>
        </section>
        <section class="container" id="sortieralgorithmen">
            <h2>15.5 Kenntnisse über Sortier&shy;algorithmen (Bubblesort, Quicksort)</h2>
            <p>Sortieralgorithmen sind Methoden, deren Zweck es ist Elemente in einer bestimmten Reihenfolge anzuordnen (aufsteigen, absteigen etc.). </p>
            <h3>Bubblesort:  </h3>
            <p>Iteriert durch eine Liste, vergleicht benachbarte Elemente und tauscht sie nach Bedarf um. Dieser Prozess wird wiederholt, bis alle Elemente in der gewollten Reihenfolge sind. </p>
            <h3>Quicksort: </h3>
            <p>Es wird ein Element ausgewählt (Pivot-Element) und basierend auf diesem Element wird die Liste in Zwei Teile geteilt (z.B. Alles kleiner als Pivot, alles Größer als Pivot). Danach wird ein Pivot-Element in diesen Teilen gewählt und der Prozess rekursiv wiederholt, bis die Liste sortiert ist. </p>
            <div class="quelle">
                <a class="btn" href="https://studyflix.de/informatik/bubblesort-1325 " target="_blank">Quelle Bubblesort</a>
                <a class="btn" href="https://studyflix.de/informatik/quicksort-1322 " target="_blank">Quelle Quicksort</a>
            </div>
        </section>
        <section class="container" id="suchalgorithmen">
            <h2>15.6 Kenntnisse über Suchalgorithmen (sequentielle Suche, binäre Suche)</h2>
            <h3>Sequentielle Suche (Lineare Suche) </h3>
            <p>Die sequentielle Suche ist einer der einfachsten Suchalgorithmen. Sie wird verwendet, um ein bestimmtes Element in einer Liste zu finden, indem jedes Element der Liste der Reihe nach überprüft wird, bis das gesuchte Element gefunden oder das Ende der Liste erreicht ist. </p>
            <h3>Eigenschaften der sequentiellen Suche: </h3>
            <ul class="left">
                <li>Einfach zu implementieren. </li>
                <li>Funktioniert gut bei kleinen Datenmengen. </li>
                <li>Keine Voraussetzung, dass die Daten sortiert sein müssen. </li>
                <li>Im schlimmsten Fall müssen alle Elemente durchlaufen werden, was zu einer Zeitkomplexität von O(n) führt, wobei n die Anzahl der Elemente in der Liste ist. </li>
            </ul>
            <div class="quelle">
                <a class="btn" href="" target="_blank">Quelle</a>
            </div>
            <h3>Binäre Suche </h3>
            <p>Die binäre Suche ist ein effizienter Algorithmus, der auf sortierten Daten angewendet wird. Sie funktioniert, indem das mittlere Element des Datenbereichs mit dem gesuchten Wert verglichen wird. Wenn der Wert des mittleren Elements kleiner als der gesuchte Wert ist, wird die Suche in der rechten Hälfte der Daten fortgesetzt, andernfalls in der linken Hälfte. Dieser Prozess wird wiederholt, bis das gesuchte Element gefunden wird oder die Größe des betrachteten Bereichs 0 erreicht. </p>
            <h3>Eigenschaften der binären Suche: </h3>
            <ul class="left">
                <li>Effizient für die Suche in großen Datenmengen, vorausgesetzt, die Daten sind sortiert. </li>
                <li>Die Zeitkomplexität im schlimmsten Fall und im durchschnittlichen Fall ist O(log n), wobei n die Anzahl der Elemente in der Liste ist. </li>
                <li>Nicht geeignet für unsortierte Datensätze, da die Daten vor der Anwendung der binären Suche sortiert werden müssen. </li>
                <li>Implementierung ist komplizierter als die der sequentiellen Suche. </li>
            </ul>
            <div class="quelle">
                <a class="btn" href="https://de.wikipedia.org/wiki/Bin%C3%A4re_Suche" target="_blank">Quelle</a>
            </div>
        </section>
        <section class="container" id="programmentwicklung">
            <h2>15.7 Ablauf der Programm&shy;entwicklung</h2>
            <p>Jedes Programm muss zuerst mit Hilfe eines Editors geschrieben werden, dann wird es übersetzt und gebunden und am Schluss erfolgt der Test. Ist der Test nicht zufrieden stellend verlaufen, so benützt man wieder den Editor, verbessert das Programm, und der oben beschriebene Ablauf beginnt von vorne. Dieser Zyklus wird im Laufe einer Programmentwicklung meist mehrere Male durchlaufen, bis das endgültige Produkt fertig ist</p>
            <div class="quelle">
                <a class="btn" href="http://www.vias.org/mikroelektronik/b2_02_prog_development.html " target="_blank">Quelle</a>
            </div>
        </section>
        <section class="container" id="programmiersprache">
            <h2>15.8 Fachbegriffe zum Aufbau einer Programmier&shy;sprache (Syntax, Semantik, Kommentare, Schlüsselwörter, Anweisung)</h2>
            <p>In der Softwareentwicklung sind die Begriffe Syntax, Semantik, Kommentare, Schlüsselwörter und Anweisungen zentral für das Verständnis und die Anwendung von Programmiersprachen. Hier ist eine Zusammenfassung dieser Begriffe: </p>
            <h3>Syntax </h3>
            <p>Die Syntax einer Programmiersprache definiert die Regeln und Strukturen, die verwendet werden, um Anweisungen und Programme zu schreiben. Sie bestimmt, wie Schlüsselwörter, Operatoren, Variablennamen und andere Elemente der Sprache kombiniert werden dürfen, um gültigen Code zu erzeugen. </p>
            <h3>Semantik</h3>
            <p>Die Semantik beschäftigt sich mit der Bedeutung des Codes und was die Anweisungen bewirken. Während die Syntax die Form des Codes festlegt, bestimmt die Semantik seine Funktion. Es ist möglich, syntaktisch korrekten Code zu schreiben, der semantisch keinen Sinn ergibt oder nicht das gewünschte Verhalten aufweist. </p>
            <h3>Kommentare </h3>
            <p>Kommentare sind Texte im Quellcode, die nicht vom Compiler oder Interpreter ausgeführt werden. Sie dienen dazu, den Code für menschliche Entwickler verständlicher zu machen. In den meisten Sprachen werden Kommentare durch spezielle Zeichen oder Zeichenfolgen eingeleitet, wie // für eine Zeilenkommentare oder /* ... */ für Blockkommentare in C-ähnlichen Sprachen. </p>
            <h3>Schlüsselwörter </h3>
            <p>Schlüsselwörter sind reservierte Wörter in einer Programmiersprache, die eine spezielle Bedeutung haben. Sie sind Teil der Syntax und dürfen nicht als Namen für Variablen oder Funktionen verwendet werden. Beispiele sind if, else, while, return, class und public in Sprachen wie Java oder C++. </p>
            <h3>Anweisungen </h3>
            <p>Anweisungen sind die kleinsten ausführbaren Einheiten innerhalb eines Programms, die eine bestimmte Aktion ausführen. Sie können einfache Aufgaben wie eine Zuweisung (a = b + c;), das Ausführen einer Schleife (for, while) oder das Treffen einer Entscheidung (if, switch) beinhalten.</p>
            <p>Jede Programmiersprache hat ihre eigene spezifische Syntax und Semantik, aber das grundlegende Konzept von Schlüsselwörtern und Anweisungen bleibt gleich. Sie sind die Bausteine, aus denen Programme konstruiert werden, und die Kenntnis ihrer korrekten Anwendung ist entscheidend für das Programmieren.</p>
            <div class="quelle">
                <a class="btn" href="https://www.ibm.com/docs/de/networkmanager/4.2.0?topic=statement-eval-keywords https://de.wikipedia.org/wiki/Schl%C3%BCsselwort_(Programmierung) " target="_blank">Quelle</a>
            </div>
        </section>
        <section class="container" id="interpreter">
            <h2>15.9 Fachbegriffe Interpreter und Compiler (Unterschiede, Vor- und Nachteile)</h2>
            <h3>Was ist ein Interpreter?</h3>
            <p>Ein Interpreter ist ein Computerprogramm, das den Quellcode eines Software-Projekts während dessen Laufzeit verarbeitet und als Schnittstelle zwischen diesem Projekt und dem Prozessor fungiert. Dabei geht ein Interpreter immer Codezeile für Codezeile vor, sodass die einzelnen Anweisungen der Reihe nach gelesen, analysiert und für den Prozessor aufbereitet werden. Dieses Prinzip gilt auch für wiederkehrende Anweisungen, die jeweils neu ausgeführt werden, sobald sie an der Reihe sind. Für die Verarbeitung des Software-Codes greifen Interpreter auf eigene, interne Bibliotheken zurück: Ist eine Quellcode-Zeile in die entsprechenden, maschinenlesbaren Befehle umgewandelt, wird sie direkt an den Prozessor weitergeleitet.</p>
            <p>Der Umwandlungsprozess ist erst dann abgeschlossen, wenn der gesamte Code interpretiert ist. Er wird lediglich dann vorzeitig unterbrochen, wenn bei der Verarbeitung ein Fehler auftritt – ein Umstand, der die Fehlerbehandlung erheblich vereinfacht, da die problematische Codezeile sofort mit dem Auftauchen des Fehlers gefunden ist.</p>

            <h3>Was ist ein Compiler?</h3>
            <p>Ein Compiler ist ein Computerprogramm, das den gesamten Quellcode eines Software-Projekts noch vor dessen Ausführung in Maschinensprache übersetzt. Erst im Anschluss wird das Projekt dann vom Prozessor ausgeführt, dem dadurch von Beginn an sämtliche Anweisungen in Maschinencode zur Verfügung stehen. Auf diese Weise hat der Prozessor alle notwendigen Bausteine parat, um die jeweilige Software auszuführen, Eingaben zu verarbeiten und die Ausgabe zu erzeugen. In vielen Fällen findet während des Compilierungsprozesses aber noch ein entscheidender Zwischenschritt statt: Vor der endgültigen Übersetzung in Maschinensprache wandeln die meisten Compiler Quellcode häufig zunächst in einen Zwischencode (auch „Objektcode“) um, der oft für verschiedene Plattformen geeignet ist und zudem von einem Interpreter verwendet werden kann.</p>
            <p>Compiler legen im Rahmen der Code-Generierung fest, welche Anweisungen dem Prozessor in welcher Reihenfolge übermittelt werden. Sofern die Instruktionen nicht voneinander abhängig sind, kann dieser die Anweisungen dabei sogar parallel verarbeiten.</p>

            <h3>Compiler vs. Interpreter: Die Unterschiede im tabellarischen Überblick</h3>
            <div class="tableContainer">
                <table>
                    <thead class="tableHead">
                    <tr>
                    <td> </td>
                    <td>Interpreter</td>
                    <td>Compiler</td>
                </tr>
                </thead>
                <tbody>
                <tr class="tableRow">
                    <td>Zeitpunkt der Quellcode-Übersetzung</td>
                    <td>während der Laufzeit der Software</td>
                    <td>vor der Ausführung der Software</td>
                </tr>
                <tr class="tableRow">
                    <td>Vorgehensweise bei der Übersetzung</td>
                    <td>Zeile für Zeile</td>
                    <td>immer gesamter Code</td>
                </tr>
                <tr class="tableRow">
                    <td>Anzeige von Codefehlern</td>
                    <td>nach jeder Zeile</td>
                    <td>gesammelt nach kompletter Compilierung</td>
                </tr>
                <tr class="tableRow">
                    <td>Übersetzungsgeschwindigkeit</td>
                    <td>hoch</td>
                    <td>niedrig</td>
                </tr>
                <tr class="tableRow">
                    <td>Übersetzungseffizienz</td>
                    <td>niedrig</td>
                    <td>hoch</td>
                </tr>
                <tr class="tableRow">
                    <td>Entwicklungsaufwand</td>
                    <td>Niedrig</td>
                    <td>hoch</td>
                </tr>
                <tr class="tableRow">
                    <td>Typische Sprachen</td>
                    <td>PHP, Perl, Python, Ruby, BASIC</td>
                    <td>C, C++, Pascal</td>
                </tr>
                </tbody>
            </table>
            </div>

            <p>Vorteil und Nachteil von Interpreter und Compiler:</p>
            <ul>
                <li><strong>Interpreter:</strong> Einfacher Entwicklungsprozess (insbesondere Debugging), ineffizient    er Übersetzungsprozess und langsame Ausführungsgeschwindigkeit.</li>
                <li><strong>Compiler:</strong> Übermittelt dem Prozessor den kompletten einsatzfertigen, ausführbaren Maschinencode, jegliche Anpassungen am Code erfordern eine Neuübersetzung (Fehlerbehandlung, Software-Erweiterung etc.).</li>
            </ul>

            <h3>Hybridlösung aus Compiler und Interpreter: Just-in-time-Compiler</h3>
            <p>Um die Schwächen der jeweiligen Übersetzungslösung auszugleichen, existiert außerdem das Modell des sogenannten Just-in-time-Compilers (engl. für termingerecht, rechtzeitig). Diese spezielle Compiler-Art, die vereinzelt auch als Compreter (Kofferwort aus Compiler und Interpreter) bezeichnet wird, bricht mit dem eigentlichen Compiler-Ansatz und übersetzt den Programmcode – wie Interpreter – erst zur Laufzeit. Auf diese Weise wird die (dank Compiler) hohe Ausführungsgeschwindigkeit um einen vereinfachten Entwicklungsprozess ergänzt.</p>
            <p>Eines der bekanntesten Beispiele für eine Sprache, die auf das Prinzip der Just-in-time-Compilierung setzt, ist Java: Als Komponente der Java-Laufzeitumgebung (JRE) verbessert dort ein solcher JIT-Compiler die Performance von Java-Applikationen, indem er bereits zuvor erzeugten Bytecode zur Laufzeit in Maschinencode umwandelt.</p>

            <p>Ein Interpreter verarbeitet den Quellcode eines Projekts zur Laufzeit. Dazu geht der Interpreter Zeile für Zeile vor: Eine Anweisung wird eingelesen, analysiert und sofort ausgeführt. Dann geht es mit der nächsten Anweisung weiter, bis schließlich das Ende des Programms erreicht ist; oder bis ein Fehler auftritt. Ein Compiler wandelt Quellcode in Maschinensprache um, übersetzt also das gesamte Programm von einer Programmiersprache in Maschinencode. Der Code wird vollständig übersetzt, bevor das Programm ausgeführt wird. Häufig wird der Quellcode noch in einen Zwischencode umgewandelt, zum Beispiel Objektcode.</p>
            <div class="quelle">
                <a class="btn" href="https://www.ionos.at/digitalguide/websites/web-entwicklung/compiler-vs-interpreter/ " target="_blank">Quelle</a>
            </div>
        </section>
        <section class="container" id="debugger">
            <h2>15.10 Fachbegriff Debugger (Einsatz)</h2>
            <p>Ein Debugger ist ein Werkzeug oder eine Software-Anwendung, die von Entwicklern verwendet wird, um Fehler (Bugs) in einem Computerprogramm zu finden und zu beheben. Der Debugger ermöglicht es den Entwicklern, den Programmcode schrittweise zu durchlaufen, Variablen zu überwachen, den Zustand des Programms zu überprüfen und so die Ursache von Fehlern zu identifizieren. </p>
            <h3>Breakpoints: </h3>
            <p>Ein Entwickler kann sogenannte "Breakpoints" im Code setzen. Wenn das Programm diese Stelle erreicht, wird die Ausführung des Codes gestoppt, und der Entwickler kann den Zustand des Programms und den Wert von Variablen überprüfen. </p>
            <h3>Variablenüberwachung: </h3>
            <p>Der Debugger ermöglicht die Überwachung von Variablen während der Programmausführung. Entwickler können den aktuellen Wert von Variablen anzeigen, um zu verstehen, wie sich der Programmzustand ändert </p>
            <h3>Stack Trace:</h3>
            <p>Der Debugger liefert oft einen sogenannten "Stack Trace", der die Aufrufhierarchie von Funktionen zeigt. Dies kann sehr hilfreich sein, um zu verstehen, wie das Programm zu einem bestimmten Zeitpunkt aufgerufen wurde und welche Funktionen gerade ausgeführt werden. </p>
            <div class="quelle">
                <a class="btn" href="https://www.ionos.at/digitalguide/websites/web-entwicklung/debugger/ " target="_blank">Quelle</a>
            </div>
        </section>
        <section class="container" id="assembler">
            <h2>15.11 Fachbegriff Assembler</h2>
            <p>Assemblersprache
                Ein Assembler ist ein Computerprogramm, das Quelltext in Maschinensprache übersetzt. Der Quelltext eines Assemblerprogramms ist in Textform mit Hilfe mnemonische Symbole in Assemblersprache geschrieben. Assembler zählen zu den von Programmierern verwendeten Werkzeugen. </p>
            <div class="quelle">
                <a class="btn" href="https://de.wikipedia.org/wiki/Assembler" target="_blank">Quelle</a>
            </div>
        </section>
        <section class="container" id="rekursive">
            <h2>15.12 Fachbegriff Rekursive Funktionen</h2>
            <p>Bei der rekursiven Funktion ruft sich eine Funktion oder Methode in einem Computerprogramm selbst wieder auf (d.h. enthält eine Rekursion). Auch der gegenseitige Aufruf stellt eine Rekursion dar. </p>
            <p>Wichtig bei der rekursiven Funktion ist eine Abbruchbedingung, weil sich die rekursive Funktion sonst theoretisch unendlich oft selbst aufrufen würde. </p>
            <p>Eine rekursive Funktion kann unter anderem in prozeduralen und objektorientierten Programmiersprachen angewandt werden. Obwohl diese Sprachen in ihrem Sprachstandard die Rekursion ausdrücklich zulassen, stellen Selbstaufrufe und gegenseitige Aufrufe hier (aufgrund der verwendeten Programmierparadigmen) jedoch eher die Ausnahme dar. Auch wenn in der Praxis zur Verbesserung des Programmierstils auch hier durchaus häufig auf Rekursion zurückgegriffen wird, sind die meisten Funktionen in diesen Sprachen doch rein iterativ. </p>
            <p>In einigen Sprachen, wie z. B. in manchen funktionalen Programmiersprachen oder Makroprozessoren, muss die rekursive Programmiermethode zwingend verwendet werden, da iterative Sprachkonstrukte fehlen. </p>
            <div class="quelle">
                <a class="btn" href="https://de.wikipedia.org/wiki/Rekursive_Programmierung " target="_blank">Quelle</a>
            </div>
        </section>
        <section class="container" id="ascii">
            <h2>15.13 Kenntnisse über ASCII - Tabellen</h2>
            <p>ASCII(American Standard Code for Information Interchange) ist ein Standard zur Darstellung von Zeichen durch elektronische Geräte. Um zu verstehen, was das heißt, muss man sich darüber im Klaren sein, wie ein Rechner überhaupt funktioniert: Bei einem Computer basieren die Rechenprozesse immer auf dem binären System. Das heißt: Einsen und Nullen bestimmen die Vorgänge eines Computers. Deshalb ist auch ASCII auf diesem System aufgebaut. Der ursprüngliche ASCII-Standard definiert innerhalb von sieben Bits – also sieben Stellen, die entweder eine 0 oder 1 zeigen – unterschiedliche Zeichen.</p>
            <p>So entspricht jedem Zeichen eine siebenstellige Folge von Nullen und Einsen, die man als Dezimalzahl oder als hexadezimale Zahl darstellen kann. Die ASCII-Zeichen lassen sich in mehrere Gruppen aufteilen: </p>
            <ul class="left">
                <li><strong>Steuerzeichen (0–31 & 127): </strong>Die Steuerzeichen sind nicht druckbare Zeichen. Sie dienen dazu, Kommandos an den PC oder den Drucker zu übermitteln und beruhen auf Techniken von Fernschreibern. Mit diesen Zeichen werden beispielsweise Zeilenumbrüche oder Tabulatoren gesetzt. Viele dieser Zeichen sind heute kaum noch in Gebrauch. </li>
                <li><strong>Sonderzeichen (32–47 / 58–64 / 91–96 / 123–126): </strong>Sonderzeichen (32–47 / 58–64 / 91–96 / 123–126): Sonderzeichen umfassen alle druckbaren Zeichen, die weder Buchstaben noch Ziffern sind, wie z.B. Satzzeichen oder technisch-mathematische Zeichen. ASCII zählt dazu auch das Leerzeichen, das dort als nicht sichtbares, aber druckbares Zeichen gilt – und das somit nicht zu den Steuerzeichen gehört, wie man vermuten könnte. </li>
                <li><strong>Ziffern (30–39): </strong>Die Ziffern umfassen die zehn arabischen Ziffern von Null bis Neun. </li>
                <li><strong>Buchstaben (65–90 / 97–122): </strong>Die Buchstaben sind in zwei Blöcke unterteilt, wobei die erste Gruppe die Groß- und die zweite die Kleinbuchstaben enthält. </li>
            </ul>
            <div class="quelle">
                <a class="btn" href="https://www.ionos.at/digitalguide/server/knowhow/ascii-american-standard-code-for-information-interchange/" target="_blank">Quelle</a>
            </div>
        </section>
        <section class="container" id="variablenarten">
            <h2>15.14 Kenntnisse über Variablenarten, Datentypen und Definitionen</h2>
            <h3>Variablen (Benannter Speicherplatz für Daten): </h3>
            <ul class="left">
                <li>Lokale Variable: Begrenzt auf Funktion oder Methode.</li>
                <li>Globale Variable: Verwendbar im ganzen Programm. </li>
                <li>Wertevariablen: Wert wird direkt in der Variable gespeichert. </li>
                <li>Referenzielle Variable: die Speicheradresse des eigentlichen Wertes wird als Wert gespeichert. </li>
            </ul>
            <h3>Datentypen (Bestimmt die Art der Daten, die eine Variable halten kann): </h3>
            <ul class="left">
                <li>Primitive Datentypen: Grundlegende Datenarten wie Zahlen, Zeichen und boolesche Werte. Int, double, char, boolean, byte, short, long, float.</li>
                <li>Referenzdatentypen: Umfassen Klassen, Schnittstellen und Arrays. String, Array, benutzerdefinierte Objekte. </li>
            </ul>
            <h3>Sonstige Begriffe: </h3>
            <ul class="left">
                <li>Deklaration: Anweisung, eine Variable mit einem bestimmten Datentyp zu erstellen. </li>
                <li>Initialisierung: Zuweisung eines Anfangswerts bei der Deklaration oder später im Code. </li>
                <li>Konstante: Variable mit einem festen, unveränderlichen Wert. </li>
            </ul>
            <div class="quelle">
                <a class="btn" href="https://de.wikipedia.org/wiki/Variable_(Programmierung)#Arten_von_Variablen " target="_blank">Quelle</a>
                <a class="btn" href="https://de.wikipedia.org/wiki/Datentyp " target="_blank">Quelle</a>
            </div>
        </section>
        <section class="container" id="variable">
            <h2>15.15 Unterschied Variable und Konstante</h2>
            <p>Variablen und Konstanten sind beide Elemente in der Programmierung, die Werte speichern können, aber sie unterscheiden sich in ihrer Natur und Verwendung. Hier sind die Hauptunterschiede zwischen Variablen und Konstanten: </p>
            <h3>Veränderbarkeit: </h3>
            <ul class="left">
                <li>Eine Variable ist ein Speicherbereich, der einen Wert enthält, der während der Ausführung eines Programms geändert werden kann. Das bedeutet, dass der Wert einer Variablen im Laufe des Programms variieren kann. </li>
                <li>Eine Konstante hingegen ist ein Speicherbereich, der einen Wert enthält, der während der Laufzeit des Programms nicht verändert werden kann. Der Wert einer Konstante bleibt während der gesamten Laufzeit des Programms konstant. </li>
            </ul>
            <h3>Deklaration und Initialisierung: </h3>
            <ul class="left">
                <li>Variablen werden normalerweise deklariert und initialisiert, indem sie einen Namen erhalten und einen Wert zugewiesen bekommen. Der Wert einer Variablen kann dann im Programmverlauf geändert werden. </li>
                <li>Konstanten werden ebenfalls deklariert und initialisiert, indem sie einen Namen erhalten und einen Wert zugewiesen bekommen. Der Unterschied besteht darin, dass der Wert einer Konstanten nach der Initialisierung nicht geändert werden kann. </li>
            </ul>
            <h3>Typisierung:</h3>
            <ul class="left">
                <li>In vielen Programmiersprachen können Variablen unterschiedliche Datentypen speichern, wie z. B. ganze Zahlen, Gleitkommazahlen, Zeichenfolgen usw. Die Art des gespeicherten Werts kann sich im Laufe des Programms ändern. </li>
                <li>Konstanten haben in der Regel einen festen Datentyp und können nur Werte desselben Typs speichern. </li>
            </ul>
            <h3>Anwendung: </h3>
            <ul class="left">
                <li>Variablen werden verwendet, um Daten zu speichern, die sich im Programmverlauf ändern können. Sie werden häufig für temporäre Zwischenspeicherung, Berechnungen und andere dynamische Anwendungen verwendet. </li>
                <li>Konstanten werden verwendet, um Werte zu speichern, die während der Ausführung des Programms konstant bleiben sollen, wie z. B. mathematische Konstanten, Konfigurationsparameter oder andere Werte, die sich nicht ändern dürfen. </li>
            </ul>
            <p>Zusammenfassend kann gesagt werden, dass Variablen dazu dienen, Daten dynamisch zu speichern und zu ändern, während Konstanten dazu dienen, Werte zu speichern, die während der Laufzeit des Programms konstant bleiben müssen. </p>
            <div class="quelle">
                <a class="btn" href="" target="_blank">Quelle</a>
            </div>
        </section>
        <section class="container" id="gültigkeitsbereiche">
            <h2>15.16 Gültigkeitsbereiche (Lebensdauer) von Variablen</h2>
            <p>Der Gültigkeitsbereich einer Variablen bezeichnet den Teil des
                Programms, in dem auf die Variable zugegriffen werden kann. </p>
            <p>Die Lebensdauer einer Variablen ist die Zeit von der
                Erzeugung der Variablen bis zu dem Zeitpunkt, in dem
                sie im Speicher gelöscht wird. </p>
            <div class="quelle">
                <a class="btn" href="https://www.uni-ulm.de/fileadmin/website_uni_ulm/iui.proghilfe/2008ss/sichtbarkeit.pdf " target="_blank">Quelle</a>
            </div>
        </section>
        <section class="container" id="schleifen">
            <h2>15.17 Fachbegriff Schleifen, Beispiele für Schleifen</h2>
            <h3>Fachbegriff Schleifen: Beispiele für Schleifen</h3>
            <p>Der Fachbegriff "Schleifen" in der Programmierung bezieht sich auf eine Struktur, die es ermöglicht, eine Gruppe von Anweisungen wiederholt auszuführen, bis eine bestimmte Bedingung erfüllt ist. Schleifen sind ein grundlegendes Konstrukt in der Programmierung und ermöglichen die Automatisierung von wiederkehrenden Aufgaben. Hier sind einige Beispiele für Schleifen in verschiedenen Programmiersprachen:</p>
            <div class="codeContainer">
                <h4>For-Schleife:</h4>
                <pre class="codeBlock">
                    <code>
                        for (let i = 0; i < 5; i++) {
                        console.log(i);
                        }
                    </code>
                </pre>
                <h4>While-Schleife:</h4>
                <pre class="codeBlock">
                    <code>
                        let i = 0;
                        while (i < 5) {
                        console.log(i);
                        i++;
                        }
                </code>
                </pre>
                <h4>Do-While-Schleife:</h4>
                <pre class="codeBlock">
                    <code>
                        let i = 0;
                        do {
                        console.log(i);
                        i++;
                        } while (i < 5);
                </code>
                </pre>
                <h4>For-Each-Schleife:</h4>
                <pre class="codeBlock">
                    <code>
                        const numbers = [1, 2, 3, 4, 5];
                        numbers.forEach(number => {
                        console.log(number);
                        });
                </code>
                </pre>
                <p>JavaScript hat keine nativen Repeat-Until-Schleifen, aber Sie können das Verhalten mit einer While-Schleife nachahmen:</p>
                <pre class="codeBlock">
                    <code>
                        let i = 0;
                        do {
                        console.log(i);
                        i++;
                        } while (i < 5);
                    </code>
                </pre>
            </div>
            <p>Diese Beispiele zeigen die Verwendung verschiedener Arten von Schleifen in JavaScript für unterschiedliche Anwendungsfälle.</p>
            <div class="quelle">
                <a class="btn" href="" target="_blank">Quelle</a>
            </div>
        </section>
        <section class="container" id="kopfgesteuert">
            <h2>15.18 Fachbegriffe "kopfgesteuert" bzw. "fußgesteuert" im Zusammenhang mit Schleifen</h2>
            <p>In der Programmierung beziehen sich die Begriffe "kopfgesteuert" und "fußgesteuert" auf die Art, wie Schleifen kontrolliert werden: </p>
            <p><strong>Kopfgesteuerte Schleife (auch als "pre-test loop" bekannt): </strong>Hier wird die Bedingung, die über die Fortsetzung oder Beendigung der Schleife entscheidet, am Anfang der Schleife überprüft, bevor der Codeblock innerhalb der Schleife ausgeführt wird. Die häufigste kopfgesteuerte Schleife ist die while-Schleife in vielen Programmiersprachen. Wenn die Bedingung zu Beginn falsch ist, wird der Schleifenkörper überhaupt nicht ausgeführt. </p>
            <p><strong>Fußgesteuerte Schleife (auch als "post-test loop" bekannt): </strong>Bei dieser Schleife wird die Bedingung am Ende des Schleifenkörpers überprüft. Das bedeutet, dass der Codeblock innerhalb der Schleife mindestens einmal ausgeführt wird, selbst wenn die Bedingung von Anfang an falsch ist. Ein typisches Beispiel für eine fußgesteuerte Schleife ist die do-while-Schleife.</p>
            <div class="quelle">
                <a class="btn" href="https://www.inf-schule.de/informatiksysteme/robotik/lejoseinstieg/schleifen/gesteuerteschleife" target="_blank">Quelle</a>
            </div>
        </section>
        <section class="container" id="verzweigungen">
            <h2>15.19 Kenntnisse über Verzweigungen und Fallunterscheidungen</h2>
            <h3>Kenntnisse über Verzweigungen und Fallunterscheidungen</h3>
            <p>In vielen Programmiersprachen werden Verzweigungen und Fallunterscheidungen verwendet, um den Programmfluss basierend auf bestimmten Bedingungen zu steuern. Hier sind einige grundlegende Konzepte:</p>
            <h4>if-Anweisungen:</h4>
            <p>Die if-Anweisung ist die grundlegende Form der Verzweigung. Sie ermöglicht es, einen Block von Code nur dann auszuführen, wenn eine bestimmte Bedingung erfüllt ist.</p>
            <h4>else-Anweisungen:</h4>
            <p>Neben der if-Anweisung gibt es auch die else-Anweisung, die es ermöglicht, einen anderen Block von Code auszuführen, wenn die Bedingung der if-Anweisung nicht erfüllt ist.</p>
            <h4>elif-Anweisungen (else if):</h4>
            <p>Manchmal benötigen Sie mehr als zwei Möglichkeiten. Hier kommt die elif-Anweisung ins Spiel. Sie ermöglicht es, eine weitere Bedingung zu überprüfen, wenn die vorherige Bedingung falsch ist.</p>
            <h4>switch-Anweisungen:</h4>
            <p>Einige Programmiersprachen unterstützen auch switch-Anweisungen, die eine kompaktere Möglichkeit bieten, zwischen verschiedenen Fällen zu unterscheiden.</p>
            <p>Diese Konzepte sind in vielen Programmiersprachen ähnlich, obwohl es einige Unterschiede in der Syntax geben kann. Verzweigungen und Fallunterscheidungen sind entscheidend für die Strukturierung von Programmen und die Implementierung von bedingten Logiken.</p>
            <h4>Bedingte Anweisungen und Verzweigungen:</h4>
            <p>Eine bedingte Anweisung ist in der Programmierung ein Programmabschnitt, der nur unter einer bestimmten Bedingung ausgeführt wird. Eine Verzweigung legt fest, welcher von zwei (oder mehr) Programmabschnitten, abhängig von einer (oder mehreren) Bedingungen, ausgeführt wird.</p>
            <div class="quelle">
                <a class="btn" href="https://de.wikipedia.org/wiki/Bedingte_Anweisung_und_Verzweigung" target="_blank">Quelle</a>
            </div>
        </section>
        <section class="container" id="objektorientierten">
            <h2>15.20 Kenntnis der objekt&shy;orientierten Programmierung (Klassen, Objekte, Vererbung, …)</h2>
            <h3>Klassen und Objekte:</h3>
            <p>Klassen sind Baupläne oder Schablonen für die Erstellung von Objekten. Objekte sind Instanzen von Klassen, die bestimmte Eigenschaften (Attribute) und Methoden (Funktionen) haben.</p>
            <h3>Vererbung:</h3>
            <p>Vererbung ist ein Konzept, das es ermöglicht, Eigenschaften und Methoden einer bestehenden Klasse in einer neuen Klasse wiederzuverwenden. Eine abgeleitete Klasse (Kindklasse) erbt von einer Basisklasse (Elternklasse).</p>
            <h3>Polymorphismus:</h3>
            <p>Polymorphismus ermöglicht es, dass verschiedene Klassen in einem einheitlichen Interface verwendet werden können. Dies kann durch Vererbung und Schnittstellen erreicht werden. Polymorphismus ermöglicht es, dass Objekte unterschiedlicher Klassen auf eine einheitliche Weise verwendet werden können.</p>
            <h3>Encapsulation (Kapselung):</h3>
            <p>Kapselung bezieht sich auf die Idee, dass die Daten (Attribute) und die Methoden, die auf diese Daten zugreifen, in einer Klasse gebündelt werden. Dies hilft, den Zustand eines Objekts vor direktem Zugriff von außen zu schützen.</p>
            <h3>Abstraktion:</h3>
            <p>Abstraktion beinhaltet die Fokussierung auf die wesentlichen Merkmale eines Objekts und die Ignorierung der unwichtigen Details. Klassen und Objekte sind Werkzeuge der Abstraktion, die es ermöglichen, komplexe Systeme zu modellieren.</p>
            <h3>Schnittstellen:</h3>
            <p>Eine Schnittstelle definiert eine Sammlung von Methoden, die von Klassen implementiert werden müssen. Sie ermöglicht die Definition von Verhalten, ohne die spezifische Implementierung anzugeben.</p>
            <h3>Methodenüberladung und -überschreibung:</h3>
            <p>Methodenüberladung ermöglicht es, mehrere Methoden mit dem gleichen Namen in einer Klasse zu haben, aber mit unterschiedlichen Parametern. Methodenüberschreibung tritt auf, wenn eine abgeleitete Klasse eine Methode ihrer Basisklasse mit der gleichen Signatur ersetzt.</p>
            <p>Objektorientierte Programmierung bietet eine modulare und gut strukturierte Möglichkeit, Software zu entwerfen und zu entwickeln. Sie fördert die Wiederverwendbarkeit von Code, erleichtert die Wartung von Software und unterstützt die Entwicklung komplexer Anwendungen durch klare Abstraktionen. OOP wird in vielen Programmiersprachen wie Java, C++, Python und anderen eingesetzt.</p>
            <div class="quelle">
                <a class="btn" href="https://programmieren-starten.de/blog/objektorientierte-programmierung/ " target="_blank">Quelle</a>
            </div>
        </section>
        <div class="center">
            <a class="btn" href="qualitätssicherung.php">Zurück zu Qualitätssicherung</a>
            <a class="btn" href="kenntnisundVerwendungvonDatenbankenDatenmodellenUndDatenstrukturen.php">Weiter zu Kenntnis und Verwendung von Datenbanken, Datenmodellen und Datenstrukturen</a>
        </div>
    </article>
</main>
<?php include'include/footer.php' ?>