<?php
$title = 'Datenschutzerklärung - CodeAbschlussGuide';
$description = 'Unsere Datenschutzerklärung informiert Sie über den Umgang mit Ihren persönlichen Daten auf CodeAbschlussGuide. Datenschutz steht bei uns an erster Stelle.';
$keywords = 'Datenschutzerklärung, Datenschutz, persönliche Daten, CodeAbschlussGuide, Datenschutzgesetze';
$canonical = 'https://www.codeabschlussguide.at/datenschutzerklaerung';
include 'include/header.php'
?>
    <main class="responsive">
        <section>
            <h1>Datenschutzerklärung</h1>
            <p>Datum: 23.03.2024</p>
            <p>Wir nehmen den Schutz deiner persönlichen Daten sehr ernst und halten uns strikt an die Regeln der Datenschutzgesetze. Personenbezogene Daten werden auf dieser Webseite nur im technisch notwendigen Umfang erhoben. In keinem Fall werden die erhobenen Daten verkauft oder aus anderen Gründen an Dritte weitergegeben.</p>

            <h2>Datenverarbeitung auf dieser Internetseite</h2>
            <p>Johannes Jobst erhebt und speichert automatisch in ihren Server Log Files Informationen, die dein Browser an uns übermittelt. Dies sind:</p>
            <ul>
                <li>Browsertyp/ -version</li>
                <li>verwendetes Betriebssystem</li>
                <li>Referrer URL (die zuvor besuchte Seite)</li>
                <li>Hostname des zugreifenden Rechners (IP Adresse)</li>
                <li>Uhrzeit der Serveranfrage.</li>
            </ul>
            <p>Diese Daten sind für Johannes Jobst nicht bestimmten Personen zuordenbar. Eine Zusammenführung dieser Daten mit anderen Datenquellen wird nicht vorgenommen.</p>

            <h2>E-Mail-Kontakt</h2>
            <p>Wenn du uns per E-Mail Anfragen zukommen lässt, werden deine Angaben aus der E-Mail inklusive der von dir dort angegebenen Kontaktdaten zwecks Bearbeitung der Anfrage und für den Fall von Anschlussfragen bei uns gespeichert. Diese Daten geben wir nicht ohne deine Einwilligung weiter.</p>

            <h2>Deine Rechte: Auskunft, Löschung, Sperrung</h2>
            <p>Du hast jederzeit das Recht auf unentgeltliche Auskunft über deine gespeicherten personenbezogenen Daten, deren Herkunft und Empfänger und den Zweck der Datenverarbeitung sowie ein Recht auf Berichtigung, Sperrung oder Löschung dieser Daten. Hierzu sowie zu weiteren Fragen zum Thema personenbezogene Daten kannst du dich jederzeit unter der im Impressum angegebenen Adresse an uns wenden.</p>
        </section>
    </main>

<?php include'include/footer.php' ?>