<?php
$title = 'Projektmethoden und Tools: Agile Praktiken und Softwareentwicklungsmodelle';
$description = 'Entdecken Sie umfassende Informationen zu modernen Projektmethoden und Tools, einschließlich agiler Praktiken wie Scrum und Kanban, Softwareprozessmodelle wie das Wasserfallmodell und das V-Modell, und innovative Ansätze wie DevOps. Lernen Sie die Rollen des Scrummasters und des Productowners kennen, verstehen Sie die Bedeutung von Backlogs, Sprints, Stakeholdern und Daily Scrums, und erkunden Sie Konzepte wie User Stories und Versionsverwaltung für erfolgreiche Projektumsetzungen.';
$keywords = 'Agiles Projektmanagement, Scrum, Kanban, Wasserfallmodell, V-Modell, DevOps, Scrummaster, Productowner, Backlog, Sprint, Stakeholder, Daily Scrum, User Story, Softwareentwurf, Prototyp, Soll-Ist-Analyse, Versionsverwaltung';
$canonical = 'https://www.codeabschlussguide.de/projektmethoden-tools';
include 'include/header.php'
?>
<main class="responsive">
    <section>
        <h1>13) Projektmethoden, Tools</h1>
        <ul class="listLegend"  style="list-style: none">
            <li><a href="#softwareprozessmodelle">13.1 Kenntnisse über Software&shy;prozessmodelle</a></li>
            <li><a href="#wasserfallmodells">13.2 Kenntnisse über den Aufbau des Wasserfallmodells</a></li>
            <li><a href="#projektmanagement">13.3 Kenntnisse über Agiles Projektmanagement / Methoden</a></li>
            <li><a href="#devOps">13.4 Fachbegriff DevOps</a></li>
            <li><a href="#scrummaster">13.5 Fachbegriff Scrummaster</a></li>
            <li><a href="#productowner">13.6 Fachbegriff Productowner</a></li>
            <li><a href="#backlog">13.7 Fachbegriff Backlog</a></li>
            <li><a href="#sprint">13.8 Fachbegriff Sprint</a></li>
            <li><a href="#stakeholder">13.9 Fachbegriff Stakeholder</a></li>
            <li><a href="#standup">13.10 Fachbegriff Daily Scrum/Daily Standup</a></li>
            <li><a href="#board">13.11 Fachbegriff User Story/Story Board</a></li>
            <li><a href="#wasserfallmodell">13.12 Probleme, die beim Wasserfall&shy;modell auftreten können</a></li>
            <li><a href="#vModells">13.13 Kenntnisse über den Aufbau des V-Modells</a></li>
            <li><a href="#vModell">13.14 Kenntnisse über Vor- und Nachteile des V-Modells</a></li>
            <li><a href="#softwareentwurf">13.15 Fachbegriff Softwareentwurf</a></li>
            <li><a href="#prototyp">13.16 Fachbegriff Prototyp</a></li>
            <li><a href="#analyse">13.17 Fachbegriff Soll - Ist - Analyse</a></li>
            <li><a href="#versionsverwaltung">13.18 Fachbegriff Versionsverwaltung</a></li>
        </ul>
        <aside class="floatingNav">
            <div class="floatingDot" data-section="#softwareprozessmodelle"><span class="floatingText">13.1 </span></div>
            <div class="floatingDot" data-section="#wasserfallmodells"><span class="floatingText">13.2 </span></div>
            <div class="floatingDot" data-section="#projektmanagement"><span class="floatingText">13.3 </span></div>
            <div class="floatingDot" data-section="#devOps"><span class="floatingText">13.4 </span></div>
            <div class="floatingDot" data-section="#scrummaster"><span class="floatingText">13.5 </span></div>
            <div class="floatingDot" data-section="#productowner"><span class="floatingText">13.6 </span></div>
            <div class="floatingDot" data-section="#backlog"><span class="floatingText">13.7 </span></div>
            <div class="floatingDot" data-section="#sprint"><span class="floatingText">13.8 </span></div>
            <div class="floatingDot" data-section="#stakeholder"><span class="floatingText">13.9 </span></div>
            <div class="floatingDot" data-section="#standup"><span class="floatingText">13.10 </span></div>
            <div class="floatingDot" data-section="#board"><span class="floatingText">13.11 </span></div>
            <div class="floatingDot" data-section="#wasserfallmodell"><span class="floatingText">13.12 </span></div>
            <div class="floatingDot" data-section="#vModells"><span class="floatingText">13.13 </span></div>
            <div class="floatingDot" data-section="#vModell"><span class="floatingText">13.14 </span></div>
            <div class="floatingDot" data-section="#softwareentwurf"><span class="floatingText">13.15 </span></div>
            <div class="floatingDot" data-section="#prototyp"><span class="floatingText">13.16 </span></div>
            <div class="floatingDot" data-section="#analyse"><span class="floatingText">13.17 </span></div>
            <div class="floatingDot" data-section="#versionsverwaltung"><span class="floatingText">13.18 </span></div>
        </aside>
    </section>

    <article>
        <section class="container" id="softwareprozessmodelle">
            <h2>13.1 Kenntnisse über Software&shy;prozessmodelle</h2>
            <h3>Wasserfallmodell:</h3>
            <p>Das Wasserfallmodell ist ein sequentielles Modell, bei dem die Entwicklung in aufeinanderfolgenden Phasen erfolgt: Anforderungsanalyse, Entwurf, Implementierung, Test und Wartung. Jede Phase beginnt erst, wenn die vorherige abgeschlossen ist.</p>
            <h3>V-Modell:</h3>
            <p>Das V-Modell ist eine Weiterentwicklung des Wasserfallmodells, das eine stärkere Betonung auf die Verifikation und Validierung legt. Es beschreibt den Prozess als eine Reihe von Aktivitäten, die in einem V-förmigen Diagramm organisiert sind, wobei jede Entwicklungsphase mit einer entsprechenden Testphase verbunden ist.</p>
            <h3>Prototyping-Modell:</h3>
            <p>Das Prototyping-Modell betont die iterative Entwicklung von Prototypen, um Anforderungen zu verstehen, Benutzerfeedback zu sammeln und das endgültige System zu entwickeln. Es wird häufig für Projekte verwendet, bei denen die Anforderungen nicht klar definiert sind.</p>
            <h3>Inkrementelles Modell:</h3>
            <p>Das inkrementelle Modell teilt die Entwicklung in kleinere, inkrementelle Schritte auf, wobei jede Iteration ein funktionsfähiges Teilprodukt liefert. Jede Iteration fügt neue Funktionen hinzu oder verbessert vorhandene Funktionen.</p>
            <h3>Agiles Modell:</h3>
            <p>Agile Methoden wie Scrum, Kanban und Extreme Programming (XP) betonen iterative Entwicklung, flexible Anpassung an sich ändernde Anforderungen, enge Zusammenarbeit mit dem Kunden und ständige Verbesserung. Sie legen den Schwerpunkt auf schnelle Lieferungen von Software in kurzen Zeiträumen.</p>
            <h3>Spiralmodell:</h3>
            <p>Das Spiralmodell kombiniert Elemente des Wasserfallmodells und des Prototyping-Modells und betont die Risikomanagement-Aspekte. Es besteht aus mehreren Spiralen, die iterative Zyklen von Planung, Risikoanalyse, Entwicklung und Bewertung durchlaufen.</p>
            <h3>Lean Development:</h3>
            <p>Lean Development zielt darauf ab, Verschwendung zu minimieren und den Wertzuwachs zu maximieren, indem nur diejenigen Aktivitäten durchgeführt werden, die unmittelbaren Wert für den Kunden schaffen. Es legt den Schwerpunkt auf kontinuierliche Verbesserung und Kundenorientierung.</p>
            <h3>DevOps:</h3>
            <p>DevOps ist kein traditionelles Entwicklungsmodell, sondern eine kulturelle und organisatorische Bewegung, die darauf abzielt, Entwicklung und Betrieb enger miteinander zu integrieren, um die Bereitstellung von Software zu beschleunigen und die Qualität zu verbessern.</p>
            <p>Die Wahl des geeigneten Softwareprozessmodells hängt von den Anforderungen des Projekts, den Zielen, den verfügbaren Ressourcen und den Präferenzen des Entwicklungsteams ab. Jedes Modell hat seine eigenen Vor- und Nachteile und ist für verschiedene Arten von Projekten geeignet.</p>
            <div class="quelle">
                <a class="btn" href="https://www.vdi-wissensforum.de/weiterbildung-automobil/software-prozessmodelle/" target="_blank">Quelle</a>
            </div>
        </section>
        <section class="container" id="wasserfallmodells">
            <h2>13.2 Kenntnisse über den Aufbau des Wasserfall&shy;modells</h2>
            <p>Das Wasserfallmodell (englisch: waterfall model) ist ein lineares Vorgehensmodell, das Entwicklungsprozesse in aufeinanderfolgende Projektphasen unterteilt. Im Gegensatz zu iterativen Modellen wird jede Phase nur einmal durchlaufen. Die Ergebnisse einer jeden Vorgängerphase gehen als Vorannahmen in die Folgephase ein.
                <br>
                Jede Phase schließt mit einem Zwischenergebnis (Meilenstein) ab – beispielsweise mit einem Anforderungskatalog in Form eines Lastenhefts, mit der Spezifikation einer Software-Architektur oder mit einer Anwendung im Alpha oder Beta-Stadium
            </p>
            <div class="quelle">
                <a class="btn" href="https://www.ionos.at/digitalguide/websites/web-entwicklung/wasserfallmodell/" target="_blank">Quelle</a>
            </div>
        </section>
        <section class="container" id="projektmanagement">
            <h2>13.3 Kenntnisse über Agiles Projektmanagement / Methoden</h2>
            <p>Agile Methoden sind iterative Ansätze zur Softwareentwicklung, die Flexibilität und Kundenbeteiligung betonen. Sie beinhalten oft kurze Entwicklungsdurchläufe, kontinuierliches Feedback und Anpassungsfähigkeit.</p>
            <h3>Scrum:</h3>
            <p>Scrum ist eine der beliebtesten agilen Methoden und besteht aus kurzen Entwicklungszyklen, sogenannten Sprints, die in der Regel zwei bis vier Wochen dauern.</p>
            <p>Es gibt klare Rollen wie den Scrum Master, der das Team unterstützt, den Product Owner, der die Anforderungen verwaltet, und das Entwicklungsteam.</p>
            <p>Scrum umfasst regelmäßige Meetings wie das Sprint Planning, das Daily Scrum, das Sprint Review und das Sprint Retrospective, um den Fortschritt zu verfolgen und Feedback zu sammeln.</p>
            <h3>Kanban:</h3>
            <p>Kanban ist eine Methode zur Visualisierung und Verwaltung von Arbeitsabläufen, die es ermöglicht, Engpässe und Flaschenhälse zu identifizieren und die Effizienz zu verbessern.</p>
            <p>Auf einem Kanban-Board werden Aufgaben in Spalten organisiert, die den verschiedenen Phasen des Arbeitsprozesses entsprechen, und durch Karten dargestellt, die den Status der Aufgaben anzeigen.</p>
            <h3>Lean Softwareentwicklung:</h3>
            <p>Lean Softwareentwicklung zielt darauf ab, Verschwendung zu minimieren und den Wertzuwachs zu maximieren, indem nur diejenigen Aktivitäten durchgeführt werden, die unmittelbaren Wert für den Kunden schaffen.</p>
            <p>Es umfasst Prinzipien wie Kundenorientierung, kontinuierliche Verbesserung, Verschwendungsbekämpfung und schnelle Lieferung von inkrementellen Ergebnissen.</p>
            <h3>Dynamic Systems Development Method (DSDM):</h3>
            <p>DSDM ist eine agile Methode, die sich auf die Lieferung von funktionsfähigen Produkten konzentriert und die Anpassung an sich ändernde Anforderungen ermöglicht.</p>
            <p>Es umfasst eine Reihe von Prinzipien und Praktiken, einschließlich der Zusammenarbeit von Teams, der Verwendung von Iterationen und Prototypen, sowie der Festlegung von Prioritäten basierend auf dem geschäftlichen Wert.</p>
            <div class="quelle">
                <a class="btn" href="https://www.wrike.com/de/project-management-guide/faq/was-ist-die-agile-methode-im-projektmanagement/" target="_blank">Quelle</a>
                <a class="btn" href="https://de.wikipedia.org/wiki/DevOps " target="_blank">Quelle</a>
                <a class="btn" href="https://it-service.network/it-lexikon/devops" target="_blank">Quelle</a>
            </div>
        </section>
        <section class="container" id="devOps">
            <h2>13.4 Fachbegriff DevOps</h2>
            <p>DevOps ist eine Methodik und Kultur, die darauf abzielt, die Softwareentwicklung (Development) und den IT-Betrieb (Operations) zu vereinen. Ziel ist es, einen kontinuierlichen Entwicklungszyklus zu schaffen, der eine schnellere und effizientere Entwicklung und Bereitstellung von Software ermöglicht. Zu den Kernpraktiken von DevOps gehören:</p>
            <ul class="left">
                <li>Kontinuierliche Integration (CI): Ständige Zusammenführung von Codeänderungen in ein zentrales Repository, gefolgt von automatisierten Builds und Tests.</li>
                <li>Kontinuierliche Bereitstellung (CD): Automatische Übertragung des Codes in die Produktionsumgebung, was schnelle und häufige Releases ermöglicht.</li>
                <li>Automatisierung: Von Tests über Builds bis hin zur Infrastrukturkonfiguration.</li>
                <li>Monitoring und Logging: Überwachung der Anwendungsleistung und der Infrastruktur in Echtzeit.</li>
                <li>Kollaboration und Kultur: Förderung einer Kultur der Zusammenarbeit zwischen Entwicklern, QA-Teams, IT-Personal und Geschäftsbereichen.</li>
            </ul>
            <p>DevOps fördert eine enge Zusammenarbeit und Feedbackschleifen, wodurch Teams in der Lage sind, schneller auf Kundenbedürfnisse zu reagieren und die Qualität und Sicherheit ihrer Produkte zu verbessern.</p>

            <div class="quelle">
                <a class="btn" href="https://www.arocom.de/fachbegriffe/devops#:~:text=Was%20bedeutet%20der%20Begriff%20DevOps,der%20Bereiche%20Softwareentwicklung%20und%20Systemadministration" target="_blank">Quelle</a>
            </div>
        </section>
        <section class="container" id="scrummaster">
            <h2>13.5 Fachbegriff Scrummaster</h2>
            <h3>Die Rolle des Scrum Masters</h3>
            <p>Der Scrum Master ist dafür verantwortlich, dass Scrum als Rahmenwerk gelingt. Dazu arbeitet er mit dem Entwicklungsteam zusammen, gehört aber selbst nicht dazu. Er führt die Scrum-Regeln ein, überprüft deren Einhaltung und kümmert sich um die Behebung von Störungen und Hindernissen. Dazu gehören mangelnde Kommunikation und Zusammenarbeit sowie persönliche Konflikte im Entwicklungsteam, welchen effektiv mit gesunder und klarer Kommunikation begegnet werden sollte, Störungen in der Zusammenarbeit zwischen Product Owner und Entwicklungsteam sowie Störungen von außen, beispielsweise Aufforderungen der Fachabteilung zur Bearbeitung zusätzlicher Aufgaben während eines Sprints.</p>
            <p>Der Scrum Master moderiert die Sprint Retrospektive und oft auch das Sprint Planning und Backlog Refinement. Ein Scrum Master ist gegenüber dem Entwicklungsteam eine dienende Führungskraft. Er gibt einzelnen Team-Mitgliedern keine Arbeitsanweisungen. Weder beurteilt er sie, noch belangt er sie disziplinarisch. Der Scrum Master ist als Coach für den Prozess und die Beseitigung von Hindernissen verantwortlich. Unterschiedliche Teams und Situationen erfordern vom Scrum Master ein situatives Führen.</p>
            <p>Zu Beginn einer Scrum-Implementierung ist der Scrum Master eine Vollzeitstelle, da die Umstellung der Abläufe, das Zusammenwachsen des Teams und das Einlernen der Rollen meist aufwändig sind. Er bildet das Team in Scrum aus. Ist Scrum erst einmal etabliert, kann der Scrum Master seine Rolle als Change-Manager wahrnehmen. Er hat dann die Zeit und auch die nötige Erfahrung, um Scrum im Unternehmen bekannt zu machen und dessen Akzeptanz zu steigern.</p>
            <h3>Scrum: Ein agiles Vorgehensmodell</h3>
            <p>Scrum (englisch für „Gedränge“) ist ein Vorgehensmodell des Projekt- und Produktmanagements, insbesondere zur agilen Softwareentwicklung.</p>
            <ul class="left">
                <li>Trägt Verantwortung für den Scrum-Prozess und dessen korrekte Implementierung</li>
                <li>Ist ein Vermittler und Unterstützer (Facilitator)</li>
                <li>Strebt maximalen Nutzen und ständige Optimierung an</li>
                <li>Beseitigt Hindernisse</li>
                <li>Sorgt für Informationsfluss zwischen Product Owner und Team</li>
                <li>Moderiert Scrum-Meetings</li>
                <li>Hat die Aktualität der Scrum-Artefakte (Product Backlog, Sprint Backlog, Burndown Charts) im Blick</li>
                <li>Schützt das Team vor unberechtigten Eingriffen während des Sprints</li>
            </ul>

            <div class="quelle">
                <a class="btn" href="https://de.wikipedia.org/wiki/Scrum#Scrum_Master " target="_blank">Quelle</a>
            </div>
        </section>
        <section class="container" id="productowner">
            <h2>13.6 Fachbegriff Productowner</h2>
            <p>Der Fachbegriff "Product Owner" stammt aus dem Bereich des agilen Projektmanagements, insbesondere aus dem Scrum-Framework. Der Product Owner ist eine zentrale Rolle in einem agilen Team und trägt die Verantwortung für die Definition, Priorisierung und Lieferung von Produkten oder Produktinkrementen. </p>
            <div class="quelle">
                <a class="btn" href="" target="_blank">Quelle</a>
            </div>
        </section>
        <section class="container" id="backlog">
            <h2>13.7 Fachbegriff Backlog</h2>
            Ganz allgemein bezieht sich der Begriff Backlog auf eine Menge an Arbeit, die sich im Laufe der Zeit angesammelt hat oder einen Bestand an Aufträgen, die auf ihre Abarbeitung warten.
            <br>
            Im Projektmanagement bezeichnet ein Backlog generell projektbezogene Aufgaben, die noch zu erledigen sind.
            <br>
            Im Speziellen wird der Begriff Backlog im Agilen Projektmanagement in Form eines Product Backlogs und/oder eines Sprint Backlogs verwendet.
            <div class="quelle">
                <a class="btn" href="https://www.inloox.de/projektmanagement-glossar/backlog/ " target="_blank">Quelle</a>
            </div>
        </section>
        <section class="container" id="sprint">
            <h2>13.8 Fachbegriff Sprint</h2>
            <h3>Der Scrum-Sprint: Kern des agilen Projektprozesses</h3>
            <p>Mit Sprint bezeichnet Scrum den wertschöpfenden Projektprozess, bei dem das Entwicklungsteam innerhalb eines Vorgangs mit fixierter Dauer Anforderungen aus dem Sprint Backlog in ein Inkrement umsetzt. Charakteristisch für Scrum ist, dass Sprint eine festgelegte Dauer haben, welche meistens zwischen einer Woche und einem Monat liegt.</p>
            <h4>Die fünf Aktivitäten eines Sprints</h4>
            <ul class="left">
                <li><strong>Sprint Planning:</strong> Das Planen des Sprints.</li>
                <li><strong>Daily Scrum:</strong> Das tägliche Treffen des Entwicklungsteams.</li>
                <li>Umsetzen der Backlog Items für das Inkrement.</li>
                <li><strong>Sprint Review:</strong> Die Präsentation des erstellten Inkrements.</li>
                <li><strong>Sprint Retrospektive:</strong> Die Analyse und Bewertung des methodischen Vorgehens während des Sprints sowie die Planung von Verbesserungsmaßnahmen.</li>
            </ul>
            <p>Der Sprint tritt im agilen Projektmanagement an die Stelle des Arbeitspakets im traditionellen Projektmanagement als kleinste Controlling-Einheit für den Projektfortschritt. Der Projektfortschritt kann bei einem mit Scrum durchgeführten Projekt sinnvoll nur anhand der bisher abgeschlossenen Sprints bewertet werden. Eine weit verbreitete Kennzahl für die Leistungsfähigkeit ist dabei die Velocity, angegeben in Story Points pro Sprint.</p>
            <div class="quelle">
                <a class="btn" href="https://www.projektmagazin.de/glossarterm/sprint-scrum" target="_blank">Quelle</a>
            </div>
        </section>
        <section class="container" id="stakeholder">
            <h2>13.9 Fachbegriff Stakeholder</h2>
            <h3>Stakeholder-Definition</h3>
            <p>Die Stakeholder-Definition ist sehr einfach: Stakeholder bezeichnen all jene Gruppen, Personen oder Institute, die von den Aktivitäten eines Projekts bzw. eines Unternehmens direkt oder indirekt betroffen sind. Diese Gruppen haben somit auch ein gewisses Interesse an dem Projekt und damit auch einen Einfluss.</p>
            <h4>Interne vs. Externe Stakeholder</h4>
            <p>Die sogenannten Stakeholder können verschiedene Gruppen oder Personen sein. Man unterscheidet Interessensgruppen meist nach intern und extern:</p>
            <ul class="left">
                <li><strong>Interne Stakeholder:</strong> Mitarbeiter, Geschäftsführer, Management, Fachabteilungen</li>
                <li><strong>Externe Stakeholder:</strong> Lieferanten, Kunden, Partner, Kapitalgeber</li>
            </ul>
            <p>Bei der Stakeholder-Definition gibt es tatsächlich keine klare Abgrenzung, weshalb bei manchen Projekten theoretisch auch die Gesellschaft oder die Umwelt als Stakeholder-Gruppe definiert werden könnte.</p>
            <h3>Der Stakeholder-Ansatz im strategischen Management</h3>
            <p>Der Stakeholder-Ansatz, oder auch das Stakeholder-Modell, bezeichnet hier einen Ansatz für das strategische Management. Demnach sollte ein Projektleiter Kenntnis darüber haben, welche Interessensgruppen es für dieses Projekt gibt, welche davon relevant sind und wie man die Ansprüche dieser Stakeholder-Gruppen ermittelt und erfüllt.</p>
            <h4>Typische Stakeholder</h4>
            <ul class="left">
                <li>Mitarbeiter und Kunden,</li>
                <li>Lieferanten und Partner,</li>
                <li>Gewerkschaften, Verbände und Verbraucherorganisationen,</li>
                <li>Kapitalgeber wie Eigentümer, stille Teilhaber, Aktionäre oder Banken.</li>
                <li>Darüber hinaus sind auch Konkurrenten,</li>
                <li>Institutionen,</li>
                <li>Behörden oder</li>
                <li>Gesetzgeber</li>
            </ul>
            <p>zu berücksichtigen, was die Komplexität und die Wichtigkeit der Stakeholder-Analyse und -Management in jedem Projekt oder Unternehmen unterstreicht.</p>
            <div class="quelle">
                <a class="btn" href="https://asana.com/de/resources/what-are-project-stakeholders" target="_blank">Quelle</a>
                <a class="btn" href="https://t2informatik.de/wissen-kompakt/stakeholder/ " target="_blank">Quelle</a>
            </div>
        </section>
        <section class="container" id="standup">
            <h2>13.10 Fachbegriff Daily Scrum/Daily Standup</h2>
            <p>
                Ein Daily Scrum/Standup ist ein tägliches Meeting innerhalb eines Entwicklungsteams in dem die Vorhaben, Fortschritte, Herausforderungen und Pläne der jeweiligen Mitarbeiter für diesen Tag besprochen werden. Der Sinn dahinter ist die Kommunikation im Team zu fördern und Probleme/Hindernisse zu identifizieren und sicherzugehen, dass alle am selben Stand sind.
            </p>
            <div class="quelle">
                <a class="btn" href="https://t2informatik.de/wissen-kompakt/daily-scrum/" target="_blank">Quelle</a>
            </div>
        </section>
        <section class="container" id="board">
            <h2>13.11 Fachbegriff User Story/Story Board</h2>
            <h3>User Story im agilen Projektmanagement</h3>
            <p>Der Fachbegriff "User Story" bezieht sich auf eine Technik im agilen Projektmanagement, um Anforderungen an eine Software aus der Perspektive des Endbenutzers zu beschreiben. Eine User Story beschreibt eine Funktionalität oder ein Feature, die vom Benutzer benötigt wird, um einen bestimmten Wert zu erzielen. Eine typische User Story folgt einem einfachen Format:</p>
            <blockquote>
                Als [Rolle] möchte ich [Funktionalität], damit ich [Wert].
            </blockquote>
            <p>Beispiel einer User Story:</p>
            <blockquote>
                Als Kunde möchte ich mich in meinem Benutzerkonto anmelden können, damit ich meine Bestellhistorie einsehen kann.
            </blockquote>
            <p>Eine User Story ist normalerweise kurz und prägnant formuliert, um den Fokus auf das zu erreichende Ergebnis zu legen, nicht auf die technischen Details der Implementierung.</p>

            <h3>Story Board: Visualisierung der User Stories</h3>
            <p>Ein "Story Board" ist eine visuelle Darstellung der User Stories und ihrer Zustände während eines agilen Entwicklungsprozesses. Typischerweise werden auf einem Story Board Karten oder Kacheln für jede User Story angezeigt, die durch verschiedene Spalten bewegt werden können, um ihren Fortschritt zu verfolgen. Die Spalten repräsentieren typischerweise den Status der User Story, wie z.B. "To Do", "In Progress", "Testing" und "Done". Das Story Board dient als zentrales Instrument für das Team, um den Stand des Projekts zu visualisieren, Prioritäten festzulegen und den Fortschritt zu verfolgen.</p>
            <div class="quelle">
                <a class="btn" href="https://www.objectbay.com/blog/user-story-mapping#:~:text=Die%20User%20Story%20Map%20ist,Ihres%20Produktes%20auf%20einem%20Storyboard." target="_blank">Quelle</a>
            </div>
        </section>
        <section class="container" id="wasserfallmodell">
            <h2>13.12 Probleme, die beim Wasserfallmodell auftreten können</h2>
            <h3>Die Herausforderungen des Wasserfallmodells</h3>
            <p>Kunden wissen möglicherweise nicht genau, was ihre Anforderungen sind, bevor sie funktionierende Software sehen, und ändern daher ihre Anforderungen, was zu Umgestaltung, Neuentwicklung und erneutem Testen sowie zu erhöhten Kosten führt.</p>
            <p>Entwickler sind sich beim Entwerfen eines neuen Softwareprodukts oder einer neuen Funktion möglicherweise zukünftiger Schwierigkeiten nicht bewusst. In diesem Fall ist es besser, das Design zu überarbeiten, als an einem Design festzuhalten, das neu entdeckte Einschränkungen, Anforderungen oder Probleme nicht berücksichtigt.</p>
            <p>Daher gibt es keine Garantie dafür, dass die Anforderungen, die sich die Organisation ausgedacht hat, tatsächlich funktionieren würden. Von hier aus würden Sie erkennen, dass das Wasserfallmodell die folgenden Probleme hat:</p>
            <ul class="left">
                <li>Menschen folgen Plänen blind.</li>
                <li>Sequenzielle Prozesse und Änderungen werden kostspielig.</li>
                <li>Endbenutzer wissen nicht, was sie wollen.</li>
                <li>Qualitätsprüfungen können darunter leiden.</li>
                <li>Du wirst nie wissen, auf welcher Bühne du wirklich stehst.</li>
            </ul>
            <p>Am Ende kann die Wasserfallmethode zu riskant sein, da sie zu starr ist. Damit Sie ein Produkt herstellen können, das funktioniert und flexibel genug ist, um Ihnen dabei zu helfen, herauszufinden, was funktioniert oder nicht.</p>

            <div class="quelle">
                <a class="btn" href="https://www.cybermedian.com/de/what-is-the-problems-of-waterfall-model/" target="_blank">Quelle</a>
            </div>
        </section>
        <section class="container" id="vModells">
            <h2>13.13 Kenntnisse über den Aufbau des V-Modells</h2>

            <div class="quelle">
                <a class="btn" href="https://www.youtube.com/watch?v=FxS9LFzpM-o " target="_blank">Quelle</a>
                <a class="btn" href="https://www.ionos.at/digitalguide/websites/web-entwicklung/v-modell/ v" target="_blank">Quelle</a>
            </div>
        </section>
        <section class="container" id="vModell">
            <h2>13.14 Kenntnisse über Vor- und Nachteile des V-Modells</h2>
            <h3>Das V-Modell in der Softwareentwicklung</h3>
            <p>Das V-Modell ist ein Softwareentwicklungsmodell, das besonders in Deutschland für die Entwicklung von Systemen verwendet wird, die hohe Anforderungen an die Dokumentation und Qualitätssicherung stellen. Es ist eine Weiterentwicklung des Wasserfallmodells und betont die Bedeutung von Tests in jeder Phase der Entwicklung.</p>

            <h4>Vorteile des V-Modells:</h4>
            <ul class="left">
                <li>Klare Struktur und definierte Prozessschritte erleichtern die Kontrolle und das Management.</li>
                <li>Frühe Testplanung erhöht die Qualität des Endprodukts.</li>
                <li>Hohe Dokumentation unterstützt die Wartung und Fehleranalyse.</li>
            </ul>

            <h4>Nachteile des V-Modells:</h4>
            <ul class="left">
                <li>Wenig Flexibilität gegenüber Änderungen im Entwicklungsprozess.</li>
                <li>Lange Entwicklungszeiten, da jede Phase abgeschlossen sein muss, bevor die nächste beginnt.</li>
                <li>Hoher Dokumentationsaufwand kann zu Bürokratie führen.</li>
            </ul>
            <p>In dynamischen Projekten, wo Anforderungen schnell ändern können, sind agilere Modelle oft geeigneter.</p>
            <div class="quelle">
                <a class="btn" href="https://www.ionos.at/digitalguide/websites/web-entwicklung/v-modell/" target="_blank">Quelle</a>
            </div>
        </section>
        <section class="container" id="softwareentwurf">
            <h2>13.15 Fachbegriff Softwareentwurf</h2>
            <h3>Softwareentwurf – Der Bauplan zur Entwicklung einer Software </h3>
            <p>Die erfolgreiche Entwicklung von Software erfordert ein ineinandergreifendes Vorgehen, das verschiedene Phasen, Informationen und Entscheidungen miteinander verbindet. Der Softwareentwurf beschreibt dabei einen Bauplan, der sich mit der Realisierung von definierten Anforderungen durch die Definition </p>
            <ul class="left">
                <li>der Infrastruktur als technische Basis, </li>
                <li>der Softwarearchitektur und </li>
                <li>dem Entwurf von Teilsystemen, Komponenten, Modulen und Klassen beschäftigt. </li>
            </ul>
            <h3>Inhalte im Softwareentwurf </h3>
            <p>
                Der Softwareentwurf ist ein Hilfsmittel und Bauplan für Programmierer. Er umfasst häufig Informationen über </p>
            <ul class="left">
                <li>die Infrastruktur mit Hardware, Tools und Services (bspw. Entwicklungsumgebungen, Software Development Kits, Programmiersprachen, Bibliotheken), die von den Anwendern benutzt werden, um die Software zu entwickeln, </li>
                <li>die Softwarearchitektur (bspw. Client-Server-Architektur, Web-Architektur oder service-orientierte Architektur) und zu verwendende Betriebssysteme, Netzwerkprotokolle, Datenbanksysteme, etc. </li>
                <li>Teilsysteme sowie die Spezifikation der Schnittstellen, </li>
                <li>Komponenten, Module und Klassen und deren Beziehungen untereinander. </li>
            </ul>
            <p>Beim Softwareentwurf geht es also darum, eine gemeinsame Basis für die Softwareentwicklung und wichtige technische Zusammenhänge zu identifizieren und festzulegen. Ziel ist es, eine Grundlage zu definieren, die leicht zu verstehen, zu ändern, zu erweitern und zu warten ist. Die Kunst der Entwicklung liegt nachfolgend darin, eine stabile Lösung zu etablieren, die dennoch so flexibel ist, dass sie spätere Variabilität erlaubt.</p>
            <blockquote>In einem Softwareentwurf werden in der Regel die geplante Architektur, Komponenten, Schnittstellen und andere Merkmale der Software definiert. </blockquote>
            <div class="quelle">
                <a class="btn" href="https://t2informatik.de/wissen-kompakt/softwareentwurf/ " target="_blank">Quelle</a>
            </div>
        </section>
        <section class="container" id="prototyp">
            <h2>13.16 Fachbegriff Prototyp</h2>
            <p>Der Fachbegriff "Prototyp" bezieht sich auf ein frühes, oft vorläufiges Modell oder Beispiel eines Produkts, einer Anwendung oder eines Systems. Ein Prototyp wird in der Regel erstellt, um bestimmte Aspekte oder Funktionen zu demonstrieren, bevor das endgültige Produkt oder System entwickelt wird. </p>
            <div class="quelle">
                <a class="btn" href="https://it-service.network/it-lexikon/prototyping" target="_blank">Quelle</a>
            </div>
        </section>
        <section class="container" id="analyse">
            <h2>13.17 Fachbegriff Soll - Ist - Analyse</h2>
            <p>
                Die Soll-Ist-Analyse ist eine Methode, um die tatsächlichen Ergebnisse eines Prozesses, Projekts oder einer Leistung mit den zuvor festgelegten Zielen oder Standards zu vergleichen. Ziel ist es, Abweichungen zwischen dem geplanten Soll-Zustand und dem tatsächlichen Ist-Zustand zu identifizieren, um auf dieser Basis Korrekturmaßnahmen einleiten zu können. Sie dient somit der Kontrolle und der kontinuierlichen Verbesserung von Prozessen.</p>
            <div class="quelle">
                <a class="btn" href="https://www.inloox.de/projektmanagement-glossar/soll-ist-vergleich/#:~:text=Der%20Soll%2DIst%20Vergleich%20wird,ist%20auch%20als%20Abweichungsanalyse%20bekannt. " target="_blank">Quelle</a>
            </div>
        </section>
        <section class="container" id="versionsverwaltung">
            <h2>13.18 Fachbegriff Versions&shy;verwaltung</h2>
            <p>Eine Versionsverwaltung ist ein System, das zur Erfassung von Änderungen an Dokumenten oder Dateien verwendet wird. Alle Versionen werden in einem Archiv mit Zeitstempel und Benutzerkennung gesichert und können später wiederhergestellt werden. Versionsverwaltungssysteme werden typischerweise in der Softwareentwicklung eingesetzt, um Quelltexte zu verwalten, kommen aber auch bei Büroanwendungen oder Content-Management-Systemen zum Einsatz.</p>

            <h4>Hauptaufgaben von Versionsverwaltung:</h4>
            <ul class="left">
                <li><strong>Protokollierungen der Änderungen:</strong> Es kann jederzeit nachvollzogen werden, wer wann was geändert hat.</li>
                <li><strong>Wiederherstellung von alten Ständen einzelner Dateien:</strong> Somit können versehentliche Änderungen jederzeit wieder rückgängig gemacht werden.</li>
                <li><strong>Archivierung der einzelnen Stände eines Projektes:</strong> Dadurch ist es jederzeit möglich, auf alle Versionen zuzugreifen.</li>
                <li>Koordinierung des gemeinsamen Zugriffs von mehreren Entwicklern auf die Dateien.</li>
                <li>Gleichzeitige Entwicklung mehrerer Entwicklungszweige (engl. Branch) eines Projektes, was nicht mit der Abspaltung eines anderen Projekts (engl. Fork) verwechselt werden darf.</li>
            </ul>
            <div class="quelle">
                <a class="btn" href="https://de.wikipedia.org/wiki/Versionsverwaltung" target="_blank">Quelle</a>
            </div>
        </section>
        <div class="center">
            <a class="btn" href="Projektmanagement.php">Zurück zu Projektmanagement</a>
            <a class="btn" href="qualitätssicherung.php">Weiter zu Qualitätssicherung</a>
        </div>
    </article>
    <div class="center">
        <a class="btn" href="ProjektmethodenTools.php">Zurück zu Projektmethoden, Tools</a>
        <a class="btn" href="grundkenntnisseDesProgrammierens.php">Weiter zu Grund&shy;kenntnisse des Programmierens</a>
    </div>
</main>
<?php include'include/footer.php' ?>