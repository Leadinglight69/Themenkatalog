<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, maximum-scale=5, initial-scale=1, user-scalable=1">
    <title><?php echo $title; ?></title>
    <meta name="description" content="<?php echo $description; ?>">
    <meta name="keywords" content="<?php echo $keywords; ?>">
    <link rel="canonical" href="<?php echo $canonical; ?>">
    <link rel="stylesheet" href="styles.css">
    <!-- Prism.js CSS -->
    <link href="prism.css" rel="stylesheet" />
</head>
<body>
<header>
    <nav>
        <div class="hamburger">
            <span class="line1"></span>
            <span class="line2"></span>
            <span class="line3"></span>
        </div>
        <div>
            <ul class="nav-links">
                <li><a href="index.php" id="activeSide">Themenkatalog</a></li>
                <li><a href="kontakt.php">Kontakt</a></li>
            </ul>
        </div>
    </nav>
</header>