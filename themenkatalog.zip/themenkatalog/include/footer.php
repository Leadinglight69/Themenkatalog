<footer>
    <div class="footerTop">
        <a href="/datenschutz.php" class="datenschutz">Datenschutz</a>
        <a href="/impressum.php" class="impressum">Impressum</a>
    </div>
    <div class="footerBottom">
        <div class="copyright">
        </div>
    </div>
</footer>
<script src="script.js" ></script>
<!-- Prism.js Library -->
<script src="prism.js"></script>

</body>
</html>
