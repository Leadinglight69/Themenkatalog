<?php
$title = 'Themenkatalog | Codeabschlussguide zur Lehrabschlussprüfung in Applikationsentwicklung - Coding';
$description = 'Entdecken Sie unseren umfassenden Themenkatalog zur Vorbereitung auf die Lehrabschlussprüfung in Applikationsentwicklung - Coding. Dieser Leitfaden ist speziell nach den Richtlinien der Wirtschaftskammer Österreich gestaltet, um Ihnen eine zielgerichtete und effiziente Vorbereitung zu ermöglichen. Finden Sie alles von IT-Sicherheit über Netzwerkdienste bis hin zu Softwareentwicklung und mehr.';
$keywords = 'Lehrabschlussprüfung, Applikationsentwicklung, Coding, Themenkatalog, IT-Sicherheit, Netzwerkdienste, Softwareentwicklung';
$canonical = 'https://www.codeabschlussguide.at/themenkatalog-applikationsentwicklung-coding';
include 'include/header.php' ?>
<main class="responsive">

    <section class="container" id="service">
        <h1>THEMENKATALOG</h1>
        <p>Dieser Themenkatalog dient der Vorbereitung auf die Lehrabschlussprüfung in Applikationsentwicklung - Coding und basiert auf den offiziellen Vorgaben der Wirtschaftskammer Österreich.</p>
        <p>Die vollständigen Informationen und Details können im <a href="https://www.wko.at/ooe/bildung-lehre/themenkatalog-applikationsentwicklung-coding-v1-2020.pdf" style="text-decoration: underline; font-size: 100%; color: var(--primaryColorlight);" target="_blank" title="Link zuum WKO Themenkatalog">offiziellen Themenkatalog</a> eingesehen werden.</p>
        <h2>für die Vorbereitung auf die Lehrabschlussprüfung Applikationsentwicklung - Coding</h2>
        <div class="serviceGrid">
            <a href="grundlagenInformationstechnologie.php">
                <div class="serviceCard">
                    <span>? !</span>
                    <h4>1) Grundlagen in der Informationstechnik</h4>
                </div>
            </a>
            <a href="betriebssystemeUndSoftware.php">
                <div class="serviceCard">
                    <span>? !</span>
                    <h4>2) Betriebssysteme und Software</h4>
                </div>
            </a>
            <a href="betreuungVonMobilerHardware.php">
                <div class="serviceCard">
                    <span>? !</span>
                    <h4>3) Betreuung von mobiler Hardware</h4>
                </div>
            </a>
            <a href="technischeDokumentationenProjektarbeitSchulungen.php">
                <div class="serviceCard">
                    <span>? !</span>
                    <h4>4) Technische Dokumentationen / Projektarbeit / Schulungen</h4>
                </div>
            </a>
            <a href="gesetzlicheBestimmungenimZusammenhangMitApplikationsentwicklung.php">
                <div class="serviceCard">
                    <span>? !</span>
                    <h4>5) Gesetzliche Bestimmungen im Zusammenhang mit
                        Applikations&shy;entwicklung – Coding</h4>
                </div>
            </a>
            <a href="netzwerkdienste.php">
                <div class="serviceCard">
                    <span>? !</span>
                    <h4>6) Netzwerkdienste</h4>
                </div>
            </a>
            <a href="itSecurityundBetriebssicherheit.php">
                <div class="serviceCard">
                    <span>? !</span>
                    <h4>7) IT-Security und Betriebssicherheit</h4>
                </div>
            </a>
            <a href="informatikUndGesellschaft.php">
                <div class="serviceCard">
                    <span>? !</span>
                    <h4>8) Informatik und Gesellschaft</h4>
                </div>
            </a>
            <a href="ergonomischeGestaltungEinesArbeitsplatzes.php">
                <div class="serviceCard">
                    <span>? !</span>
                    <h4>9) Ergonomische Gestaltung eines Arbeitsplatzes</h4>
                </div>
            </a>
            <a href="fachberatungPlanung.php">
                <div class="serviceCard">
                    <span>? !</span>
                    <h4>10) Fachberatung, Planung</h4>
                </div>
            </a>
            <a href="InformatikTeil1.php">
                <div class="serviceCard">
                    <span>? !</span>
                    <h4>11) Informatik Teil 1</h4>
                </div>
            </a>
            <a href="InformatikTeil2.php">
                <div class="serviceCard">
                    <span>? !</span>
                    <h4>11) Informatik Teil 2</h4>
                </div>
            </a>
            <a href="Projektmanagement.php">
                <div class="serviceCard">
                    <span>? !</span>
                    <h4>12) Projektmanagement</h4>
                </div>
            </a>
            <a href="ProjektmethodenTools.php">
                <div class="serviceCard">
                    <span>? !</span>
                    <h4>13) Projektmethoden, Tools</h4>
                </div>
            </a>
            <a href="qualitätssicherung.php">
                <div class="serviceCard">
                    <span>? !</span>
                    <h4>14) Qualitätssicherung</h4>
                </div>
            </a>
            <a href="grundkenntnisseDesProgrammierens.php">
                <div class="serviceCard">
                    <span>? !</span>
                    <h4>15) Grundkenntnisse des Programmierens</h4>
                </div>
            </a>
            <a href="kenntnisundVerwendungvonDatenbankenDatenmodellenUndDatenstrukturen.php">
                <div class="serviceCard">
                    <span>? !</span>
                    <h4>16) Kenntnis und Verwendung von Datenbanken, Datenmodellen und
                        Datenstrukturen</h4>

                </div>
            </a>
            <a href="systementwicklungTestkonzepte.php">
                <div class="serviceCard">
                    <span>? !</span>
                    <h4>17) Systementwicklung / Testkonzepte</h4>

                </div>
            </a>
        </div>
    </section>
</main>
<?php include 'include/footer.php' ?>
