<?php
$title = 'Informatik Fortgeschrittene: Mobile Entwicklung und Software-Prinzipien';
$description = 'Vertiefen Sie Ihr Verständnis für Informatik mit Themen wie JSON, Agile und Reaktive Programmierung, Frameworks, mobile Webseitenoptimierung und Programmiersprachen für mobile Anwendungen. Entdecken Sie die Welt der Softwareentwicklung, von aktuellen Programmiersprachen über Continuous Integration und Deployment bis hin zu Responsive Design und Cross-Plattform-Entwicklung.';
$keywords = 'Informatik, Mobile Entwicklung, Software-Prinzipien, JSON, Agile, Reaktive Programmierung, Frameworks, Programmiersprachen, Continuous Integration, Responsive Design, Cross-Plattform, JAVA, .NET, Corporate Identity';
$canonical = 'https://www.codeabschlussguide.de/informatik-teil-2';
include 'include/header.php'
?>

<body>
<main class="responsive">
  <section>
    <h1>11) Informatik Teil 2</h1>
    <ul class="listLegend"  style="list-style: none">
      <li><a href="#json">11.21 Fachbegriff JSON</a></li>
      <li><a href="#softwareentwicklung">11.22 Fachbegriff Agile Softwareentwicklung</a></li>
      <li><a href="#programmierung">11.23 Fachbegriff Reaktive Programmierung</a></li>
      <li><a href="#frameworks">11.24 Kenntnisse über Frameworks</a></li>
      <li><a href="#angularJS">11.25 Einsatzgebiete Angular JS</a></li>
      <li><a href="#bootstrap">11.26 Einsatzgebiete Bootstrap</a></li>
      <li><a href="#jQuery">11.27 Einsatzgebiet jQuery</a></li>
      <li><a href="#mySQL">11.28 Kenntnisse über den Zugriff PHP auf mySQL-Datenbank (Dienste Server/Client)</a></li>
      <li><a href="#multitasking">11.29 Fachbegriff Multitasking</a></li>
      <li><a href="#smartphones">11.30 Kenntnisse über mobile Webseiten/Optimierung für Smartphones</a></li>
      <li><a href="#webdesign">11.31 Fachbegriff Responsive Webdesign, Umsetzung</a></li>
      <li><a href="#mobileFirst">11.32 Kenntnisse über Konzept Mobile First</a></li>
      <li><a href="#programmiersprachen">11.33 Kenntnisse über aktuelle Programmiersprachen</a></li>
      <li><a href="#anwendungen">11.34 Kenntnisse über Programmiersprachen für mobile Anwendungen/Internet</a></li>
      <li><a href="#java">11.35 Kenntnisse über die Anwendung von JAVA-Technologien im Web (Servlets, Java-Server-Pages)</a></li>
      <li><a href="#net">11.36 Grundkenntnisse über die Anwendung der .NET-Technologien im Web (ASP.NET)</a></li>
      <li><a href="#metadaten">11.37 Fachbegriff Metadaten</a></li>
      <li><a href="#dry">11.38 Prinzipien der Softwareentwicklung: KISS, DRY</a></li>
      <li><a href="#coding">11.39 Kenntnisse über Coding-Standards/Code-Konventionen</a></li>
      <li><a href="#plattform">11.40 Fachbegriff Cross Plattform Entwicklung</a></li>
      <li><a href="#identity">11.41 Fachbegriff Corporate Identity (CI)</a></li>
      <li><a href="#corporate">11.42 Fachbegriff Corporate Design (CD)</a></li>
      <li><a href="#applikationsentwicklung">11.43 CI/CD Vorgaben bei der Applikationsentwicklung</a></li>
    </ul>
    <aside class="floatingNav">
      <div class="floatingDot" data-section="#json"><span class="floatingText">11.21 </span></div>
      <div class="floatingDot" data-section="#softwareentwicklung"><span class="floatingText">11.22 </span></div>
      <div class="floatingDot" data-section="#programmierung"><span class="floatingText">11.23 </span></div>
      <div class="floatingDot" data-section="#frameworks"><span class="floatingText">11.24 </span></div>
      <div class="floatingDot" data-section="#angularJS"><span class="floatingText">11.25 </span></div>
      <div class="floatingDot" data-section="#bootstrap"><span class="floatingText">11.26 </span></div>
      <div class="floatingDot" data-section="#jQuery"><span class="floatingText">11.27 </span></div>
      <div class="floatingDot" data-section="#mySQL"><span class="floatingText">11.28 </span></div>
      <div class="floatingDot" data-section="#multitasking"><span class="floatingText">11.29 </span></div>
      <div class="floatingDot" data-section="#smartphones"><span class="floatingText">11.30 </span></div>
      <div class="floatingDot" data-section="#webdesign"><span class="floatingText">11.31 </span></div>
      <div class="floatingDot" data-section="#mobileFirst"><span class="floatingText">11.32 </span></div>
      <div class="floatingDot" data-section="#programmiersprachen"><span class="floatingText">11.33 </span></div>
      <div class="floatingDot" data-section="#anwendungen"><span class="floatingText">11.34 </span></div>
      <div class="floatingDot" data-section="#java"><span class="floatingText">11.35 </span></div>
      <div class="floatingDot" data-section="#net"><span class="floatingText">11.36 </span></div>
      <div class="floatingDot" data-section="#metadaten"><span class="floatingText">11.37 </span></div>
      <div class="floatingDot" data-section="#dry"><span class="floatingText">11.38 </span></div>
      <div class="floatingDot" data-section="#coding"><span class="floatingText">11.39 </span></div>
      <div class="floatingDot" data-section="#plattform"><span class="floatingText">11.40 </span></div>
      <div class="floatingDot" data-section="#identity"><span class="floatingText">11.41 </span></div>
      <div class="floatingDot" data-section="#corporate"><span class="floatingText">11.42 </span></div>
      <div class="floatingDot" data-section="#applikationsentwicklung"><span class="floatingText">11.43 </span></div>
    </aside>
  </section>

  <article>
    <section class="container" id="json">
      <h2>11.21 Fachbegriff JSON</h2>
      <p>Die JavaScript Object Notation (JSON) ist ein kompaktes Datenformat in einer einfach lesbaren Textform für den Datenaustausch zwischen Anwendungen. JSON ist von Programmiersprachen unabhängig. Parser und Generatoren existieren in allen verbreiteten Sprachen.
        Insbesondere bei Webanwendungen und mobilen Apps wird es in Verbindung mit JavaScript, Ajax oder Websockets zum Übertragen von Daten zwischen dem Client und dem Server häufig genutzt.
        Die Daten können beliebig verschachtelt werden, beispielsweise ist eine indizierte Liste von Objekten möglich, welche wiederum Arrays oder Objekte enthalten.
        Nullwert, Boolescher Wert, Zahlen, Zeichenketten, Arrays und Objekte sind Typen von Elementen, die JSON kennt.
      </p>
      <div class="quelle">
        <a class="btn" href="https://de.wikipedia.org/wiki/JavaScript_Object_Notation" target="_blank">Quelle</a>
      </div>
    </section>
    <section class="container" id="softwareentwicklung">
      <h2>11.22 Fachbegriff Agile Softwareentwicklung</h2>
      <p>Agile Softwareentwicklung bezeichnet Ansätze im Softwareentwicklungsprozess, die die Transparenz und Veränderungsgeschwindigkeit erhöhen und zu einem schnelleren Einsatz des entwickelten Systems führen sollen, um so Risiken und Fehlentwicklungen im Entwicklungsprozess zu minimieren. Dazu wird versucht, die Entwurfsphase auf ein Mindestmaß zu reduzieren und im Entwicklungsprozess so früh wie möglich zu ausführbarer Software zu gelangen. Diese wird in regelmäßigen, kurzen Abständen mit dem Kunden abgestimmt. So soll es möglich sein, flexibel auf Kundenwünsche einzugehen, um so die Kundenzufriedenheit insgesamt zu erhöhen. </p>
      <p>Agile Softwareentwicklung zeichnet sich durch selbstorganisierende Teams sowie eine iterative Vorgehensweise aus. </p>
      <p>Agile Ansätze können sich auf Teile der Softwareentwicklung beziehen (oder auf den gesamten Softwareentwicklungsprozess. Das Ziel dabei ist, den Entwicklungsprozess flexibler und schlanker zu machen, als das bei den klassischen, plangetriebenen Vorgehensmodellen der Fall ist. </p>
      <p>Klassische Ansätze gelten oft als schwergewichtig und bürokratisch.  </p>
      <p>Ein Vorwurf ihnen gegenüber lautet: Je mehr nach Plan gearbeitet wird, desto mehr bekommt man das, was geplant wurde, aber nicht das, was gebraucht wird. </p>
      <p>Vier Leitsätze wurden im Februar 2001 als Agiles Manifest (englisch Manifesto for Agile Software Development oder kurz Agile Manifesto) formuliert: </p>
      <ul class="left">
        <li>Individuen und Interaktionen sind wichtiger als Prozesse und Werkzeuge </li>
        <li>Funktionierende Software ist wichtiger als umfassende Dokumentationen </li>
        <li>Zusammenarbeit mit dem Kunden ist wichtiger als Vertragsverhandlungen </li>
        <li>Reagieren auf Veränderung ist wichtiger als das Befolgen eines Plans</li>
      </ul>
      <div class="quelle">
        <a class="btn" href="https://de.wikipedia.org/wiki/Agile_Softwareentwicklung" target="_blank">Quelle</a>
      </div>
    </section>
    <section class="container" id="programmierung">
      <h2>11.23 Fachbegriff Reaktive Programmierung</h2>
      <p>Reaktive Programmierung benutzt Datenflüsse (Streams) um automatisch und in Echtzeit auf Änderung zu reagieren, anstatt die Änderungen manuell von einem User ausführen zu lassen.
        Beispiel: In Excel wird reaktive Programmierung durch automatische Aktualisierungen von Zellen ermöglicht. Wenn sich der Wert in einer Zelle ändert, werden automatisch alle abhängigen Zellen aktualisiert. Zum Beispiel, wenn in Zelle C1 die Formel = A1+B1 ist, wird C1 automatisch neu berechnet, wenn die Werte in A1 oder B1 geändert werden. </p>
      <div class="quelle">
        <a class="btn" href="https://www.computerweekly.com/de/definition/Reaktive-Programmierung#:~:text=Bei%20der%20reaktiven%20Programmierung%20wird,Signal%2C%20dass%20etwas%20passiert%20ist. " target="_blank">Quelle</a>
        <a href="https://de.wikipedia.org/wiki/Reaktive_Programmierung " class="btn"></a>
      </div>
    </section>
    <section class="container" id="frameworks">
      <h2>11.24 Kenntnisse über Frameworks</h2>
      <h3>Arten von Frameworks: </h3>
      <ul class="left">
        <li><strong>Web-Frameworks: </strong>Zum Erstellen von Webanwendungen und Websites. Beispiele sind React.js, Angular, Vue.js für Frontend-Entwicklung und Django, Flask für Backend-Entwicklung. </li>
        <li><strong>App-Frameworks: </strong>Zur Entwicklung von mobilen Anwendungen. Beispiele sind Flutter, React Native für plattformübergreifende Entwicklung und iOS SDK, Android SDK für native Entwicklung. </li>
        <li><strong>Test-Frameworks: </strong>Zum Automatisieren von Tests und Qualitätssicherung. Beispiele sind Selenium für Webanwendungen und XCTest für iOS-Anwendungen. </li>
        <li><strong>UI-Frameworks: </strong>Zur Gestaltung von Benutzeroberflächen. Beispiele sind Bootstrap, Material-UI für Webdesign und UIKit für iOS-Design. </li>
        <li><strong>Backend-Frameworks: </strong>Zur Entwicklung von Backend-Services und APIs. Beispiele sind Spring Boot für Java, Express.js für Node.js und Flask für Python. </li>
        <li><strong>Data Science Frameworks: </strong>Zur Analyse und Verarbeitung von Daten. Beispiele sind TensorFlow, PyTorch für maschinelles Lernen und Pandas, NumPy für Datenanalyse. </li>
      </ul>
      <h3>Vorteile von Frameworks:</h3>
      <ul class="left">
        <li><strong>Beschleunigte Entwicklung: </strong>Vordefinierte Funktionen und Strukturen erleichtern und beschleunigen die Entwicklung. </li>
        <li><strong>Konsistenz: </strong>Frameworks fördern eine konsistente Codebasis und eine einheitliche Architektur. </li>
        <li><strong>Wiederverwendbarkeit: </strong>Entwickler können auf bewährte Lösungen und Bibliotheken zugreifen, um Zeit und Ressourcen zu sparen. </li>
        <li><strong>Skalierbarkeit: </strong>Frameworks bieten oft Unterstützung für Skalierung und Wachstum von Anwendungen. </li>
      </ul>
      <h3></h3>
      <ul class="left">
        <li><strong>Web-Frameworks: </strong>React.js, Angular, Django, Express.js. </li>
        <li><strong>App-Frameworks: </strong>Flutter, React Native, iOS SDK, Android SDK. </li>
        <li><strong>Test-Frameworks: </strong>Selenium, XCTest, JUnit. </li>
        <li><strong>UI-Frameworks: </strong>Bootstrap, Material-UI, UIKit.</li>
        <li><strong>Backend-Frameworks: </strong>Spring Boot, Express.js, Flask. </li>
        <li><strong>Data Science Frameworks: </strong>TensorFlow, PyTorch, Pandas. </li>
      </ul>
      <p>Frameworks sind ein wichtiges Werkzeug für Entwickler, um effiziente, skalierbare und wartbare Softwarelösungen zu entwickeln, unabhängig von der Art der Anwendung oder des Systems. </p>
      <div class="quelle">
        <a class="btn" href="" target="_blank">Quelle</a>
      </div>
    </section>
    <section class="container" id="angularJS">
      <h2>11.25 Einsatzgebiete Angular JS</h2>
      <h3>Haupteinsatzgebiet: Website </h3>
      <p>Angular ist ein clientseitiges Framework, mit dem es möglich ist, Webapplikationen zu erstellen
        <br>
        Durch die Flexibilität, die View als HTML separat zu entwickeln, können beispielsweise verschiedene Teams an Logik bzw. Architektur und Design arbeiten.
        <br>
        Angular wird vor allem bei CRUD-Projekten (Create Read Update Delete) eingesetzt, bei denen Daten über eine Eingabemaske validiert, über Services Berechnungen gemacht und die Daten anschliessend persistiert werden müssen. Angular kann grosse Projekte bewerkstelligen, die über die simple Anzeige von Daten hinausgehen, wobei es natürlich auch dafür eine Lösung gibt mit Angular </p>

      <div class="quelle">
        <a class="btn" href="https://www.digicomp.ch/blog/2017/01/16/angular-ein-uberblick " target="_blank">Quelle</a>
      </div>
    </section>
    <section class="container" id="bootstrap">
      <h2>11.26 Einsatzgebiete Bootstrap</h2>
      <p>Bootstrap ist ein äußerst vielseitiges Frontend-Framework, das in einer Vielzahl von Einsatzgebieten verwendet werden kann. Hier sind einige der Hauptanwendungsgebiete von Bootstrap: </p>
      <ul class="left" style="list-style: decimal">
        <li><strong>Webseitenentwicklung: </strong>Bootstrap wird häufig zur Erstellung von responsiven und benutzerfreundlichen Webseiten verwendet. Es bietet eine Reihe von vorgefertigten Komponenten und Layout-Optionen, die Entwicklern helfen, schnell attraktive und konsistente Designs zu erstellen. </li>
        <li><strong>Webanwendungen: </strong>Bootstrap ist auch für die Entwicklung von interaktiven Webanwendungen geeignet. Es bietet eine umfangreiche Sammlung von UI-Komponenten wie Formulare, Buttons, Navigationsleisten, Modals und mehr, die die Entwicklung von benutzerfreundlichen Benutzeroberflächen erleichtern</li>
        <li><strong>Responsive Design: </strong>Bootstrap ist bekannt für seine Fähigkeit, responsives Design zu unterstützen, was bedeutet, dass die erstellten Webseiten und Anwendungen sich automatisch an verschiedene Bildschirmgrößen und Geräte anpassen. Dies ist besonders wichtig in einer zunehmend mobilen Welt, in der Benutzer auf einer Vielzahl von Geräten auf Webinhalte zugreifen. </li>
        <li><strong>Prototyping: </strong>Aufgrund seiner einfachen Verwendung und der großen Auswahl an vorgefertigten Komponenten eignet sich Bootstrap auch gut für das Prototyping von Webprojekten. Entwickler können schnell Prototypen erstellen und Feedback von Stakeholdern einholen, bevor sie mit der eigentlichen Entwicklung beginnen. </li>
        <li><strong>Content Management Systeme (CMS): </strong>Viele Content Management Systeme wie WordPress, Joomla und Drupal bieten Bootstrap-Integrationen oder -Themes an, die es Benutzern ermöglichen, Bootstrap-basierte Designs einfach zu implementieren und anzupassen. </li>
        <li><strong>Cross-Browser-Kompatibilität: </strong>Bootstrap hilft dabei, die Herausforderungen der Browserkompatibilität zu überwinden, indem es eine konsistente Darstellung und Funktionalität auf verschiedenen Browsern sicherstellt. </li>
      </ul>
      <div class="quelle">
        <a class="btn" href="https://de.ryte.com/wiki/Bootstrap#:~:text=was%20Bootstrap%20ist.-,Einsatz%20von%20Bootstrap,und%20um%20Webapplikationen%20zu%20erstellen." target="_blank">Quelle</a>
      </div>
    </section>
    <section class="container" id="jQuery">
      <h2>11.27 Einsatzgebiet jQuery</h2>
      <p>jQuery ist eine schnelle, kleine und feature-reiche JavaScript-Bibliothek. Sie vereinfacht Dinge wie HTML-Dokumententraversierung und -manipulation, Ereignisbehandlung, Animation und Ajax mit einer einfach zu benutzenden API, die in einer Vielzahl von Browsern funktioniert. Ihr Einsatzgebiet umfasst: </p>
      <p><strong>DOM-Manipulation: </strong>Einfaches Ändern von Elementen auf einer Webseite. </p>
      <p><strong>Ereignisbehandlung: </strong>Vereinfachtes Anhängen von Event-Handlern an Elemente. </p>
      <p><strong>Animation: </strong>Schnelles Hinzufügen von Animationseffekten zu Elementen. </p>
      <p><strong>Ajax: </strong>Vereinfachte Erstellung von asynchronen HTTP-Anfragen an den Server.
        jQuery wird oft verwendet, um die JavaScript-Programmierung zu vereinfachen und den Code kompatibel über verschiedene Browser zu halten. </p>
      <div class="quelle">
        <a class="btn" href="https://de.wikipedia.org/wiki/JQuery " target="_blank">Quelle</a>
      </div>
    </section>
    <section class="container" id="mySQL">
      <h2>11.28 Kenntnisse über den Zugriff PHP auf mySQL-Datenbank (Dienste Server/Client)</h2>
      <p>
        Um mit PHP auf die Daten in einer Datenbank zugreifen zu können, müssen wir zunächst eine Verbindung herstellen. Dies erfolgt über den Befehl mysqli_connect oder objectorientiert mit new MYSQLi ….. und noch vor allen anderen Inhalten des Dokumentes. Der Befehl benötigt den Servernamen, den Benutzernamen, Kennwort und die gewünschte Datenbank. Zusätzlich ist es möglich Port und Socket anzugeben.
      </p>
        <div class="codeContainer">
        <pre class="codeBlock">
            <code class="language-php">
&lt;?php
define("DB",[
    "host" => "localhost",
    "user" => "root",
    "pwd" => "",
    "name" => "db_3443_security"
]);
?&gt;
            conn.inc.php

&lt;?php
$conn = new MySQLi(DB["host"],DB["user"],DB["pwd"],DB["name"]);
if($conn->connect_errno>0) {
    die("Fehler im Verbindungsaufbau: " . $conn->connect_error);
}
$conn->set_charset("utf8mb4");
?&gt;

Datei

// Schritt 2: SQL-Statement in Textform formulieren --> Textvariable!
$sql = "
    SELECT * FROM tbl_user";

// Schritte 3 und 4: SQL-Statement an den DB-Server schicken und Antwort entgegennehmen
$ergebnis = $conn->query($sql);

// Schritt 5: entgegengenommene Daten verarbeiten (je nach SQL-Statement unterschiedlich)

if($ergebnis!==false) {
//sofern die zurückgelieferten Daten nicht false waren (dh. der DB-Server keinen Fehler geliefert hat),
  wird der nachfolgende Code ausgeführt

 $daten = $ergebnis->fetch_object();
echo('&lt;p&gt;IDUser=' . $daten->IDUser . ', Emailadresse=' . $daten->Emailadresse . '&lt;/p&gt;');

            </code>
        </pre>
        <button class="copyBtn">Kopieren</button>
      </div>

      <div class="quelle">
        <a class="btn" href="" target="_blank">Quelle</a>
      </div>
    </section>
    <section class="container" id="multitasking">
      <h2>11.29 Fachbegriff Multitasking</h2>
      <p>Multitasking ist ein Fachbegriff, der in der Informatik und Computertechnologie verwendet wird. Er bezieht sich auf die Fähigkeit eines Betriebssystems oder einer Software, mehrere Aufgaben oder Prozesse gleichzeitig auszuführen. Multitasking ermöglicht es einem Computer, scheinbar gleichzeitig mehrere Programme oder Anwendungen zu verarbeiten, selbst wenn die CPU (Central Processing Unit) des Computers tatsächlich nur eine Aufgabe zu einem bestimmten Zeitpunkt ausführt. </p>
      <h3>Es gibt zwei grundlegende Arten des Multitaskings: </h3>
      <p><strong>Präemptives Multitasking: </strong>Das Betriebssystem weist Prioritäten zu den laufenden Prozessen zu und kann bei Bedarf die Ausführung eines Prozesses unterbrechen, um einen anderen mit höherer Priorität auszuführen. Dies geschieht auf systemischer Ebene, und der Prozess wird durch das Betriebssystem gesteuert. </p>
      <p><strong>Kooperatives Multitasking: </strong>Die laufenden Prozesse müssen aktiv die Kontrolle an das Betriebssystem abgeben, um die Ausführung anderer Prozesse zu ermöglichen. Diese Form des Multitaskings erfordert eine engere Zusammenarbeit zwischen den laufenden Anwendungen und wird von modernen Betriebssystemen seltener verwendet. </p>
      <div class="quelle">
        <a class="btn" href="https://de.wikipedia.org/wiki/Multitasking " target="_blank">Quelle</a>
      </div>
    </section>
    <section class="container" id="smartphones">
      <h2>11.30 Kenntnisse über mobile Webseiten/Optimierung für Smartphones</h2>
      <p>Optimierung mobiler Webseiten umfasst responsives Webdesign, das automatisch an verschiedene Bildschirmgrößen anpasst, von Smartphones bis Tablets.
        <br>Wichtig sind zudem schnelle Ladezeiten, Touchscreen-Freundlichkeit und mobiles SEO, um die Auffindbarkeit auf mobilen Geräten zu verbessern.
        <br>Eine einfache, intuitive Navigation und die Minimierung von Pop-ups erhöhen die Benutzerfreundlichkeit.
        <br>Lokale Optimierung ist entscheidend, um Nutzer in der Nähe anzusprechen und relevante lokale Suchergebnisse zu liefern.</p>

      <div class="quelle">
        <a class="btn" href="https://www.seobility.net/de/wiki/Mobile_Optimierung " target="_blank">Quelle</a>
      </div>
    </section>
    <section class="container" id="webdesign">
      <h2>11.31 Fachbegriff Responsive Webdesign, Umsetzung</h2>
      <p>Das Responsive Webdesign ist ein gestalterisches und technisches Paradigma zur Erstellung von Webseiten, so dass diese auf Eigenschaften des jeweils benutzten Endgeräts, vor allem Smartphones und Tabletcomputer, reagieren können.
        Der grafische Aufbau einer „responsiven“ Website erfolgt anhand der Anforderungen des jeweiligen Gerätes, mit dem die Website betrachtet wird. Dies betrifft insbesondere die Anordnung und Darstellung einzelner Elemente, wie Navigationen, Seitenspalten und Texte, aber auch die Nutzung unterschiedlicher Eingabemethoden von Maus (klicken, überfahren) oder Touchscreen (tippen, wischen). Technische Basis hierfür sind die neueren Webstandards HTML5, CSS3 und JavaScript.
        <br>Websites, die mit einem reaktionsfähigen Design ausgestattet sind, berücksichtigen die unterschiedlichen Anforderungen der Endgeräte. Ziel dieser Praxis ist es, Websites ihre Darstellung so anpassen zu lassen, dass sie sich jedem Betrachter so übersichtlich und benutzerfreundlich wie möglich präsentieren. </p>
      <div class="quelle">
        <a class="btn" href="https://de.wikipedia.org/wiki/Responsive_Webdesign " target="_blank">Quelle</a>
      </div>
    </section>
    <section class="container" id="mobileFirst">
      <h2>11.32 Kenntnisse über Konzept Mobile First</h2>
      <h3>Neuer Ansatz im Webdesign: Mobile First statt Desktop First</h3>
      <p>Mobile First ist ein Konzept für mobil optimiertes Webdesign. Dabei entsteht zuerst die für mobile Endgeräte optimierte Seite und später folgen dann sukzessive Erweiterungen für den Desktop-Browser. Bislang war es üblich, dass sich Webdesigner und Programmierer zunächst um die Umsetzung der Website für den Desktop kümmerten. Dabei wurde mit der vollen Palette an Funktionen, Grafiken und gestalterischen Möglichkeiten eine Seite konzipiert, die auf große Bildschirme und schnelle Datenverbindung ausgelegt war. Erst im zweiten Schritt folgte die Planung der mobilen Seite, die oft nur als eine Art Anhang gesehen wurde. Die Mobile First Strategie kehrt diesen Workflow um und setzt die Prioritäten anders. Das wirkt sich auch auf die Gestaltung der technischen Infrastruktur hinter der Website aus.
      </p>
      <h3>Das Mobile First Prinzip </h3>
      <p>Bei der Konzeptionierung einer Mobile First Strategie werden zunächst die ganz zentralen Aspekte des Angebots und der Seite definiert. Dabei geht es nicht nur um Inhalte und Bilder, sondern vor allem um die wichtigsten Funktionen und Module, die als Element unbedingt auf der Website integriert werden müssen. Der Grundgedanke dieser Strategie lautet, sich nur auf das Wesentliche zu konzentrieren und nicht mehr Programmieraufwand als nötig zu investieren. </p>
      <p>Der Mobile First Ansatz im Überblick </p>
      <ul class="left">
        <li>Beschränkung auf das Wesentliche </li>
        <li>Nicht mehr Programmieraufwand als nötig </li>
        <li>Maximale Performance auf allen Endgeräten </li>
        <li>Schneller Informationszugriff </li>
        <li>Design-Entwürfe aufs Smartphone Display angepasst </li>
        <li>Keine großen Bilder und unnötigen Funktionen </li>
        <li>Kürzungen im Quellcode </li>
        <li>Verzicht auf JavaScript, Seite wird direkt in HTML5 programmiert </li>
      </ul>
      <p>Im Zentrum steht die Entwicklung einer optimalen Lösung für mobile Endgeräte. Erst im Anschluss werden nach dem Prinzip der progressiven Verbesserung (Progressive Enhancement) Desktop- und Laptop-Darstellungen optimiert. Oft werden bei Umsetzung der Strategie sogenannte Grids, also Raster, im Smartphone-Format erstellt. Im nächsten Schritt wird die Seite so skalierbar für die größere Darstellung. Die optimale Inhaltsdarstellung auf allen Geräten folgt natürlich den Grundsätzen des Responsive Webdesigns. </p>
      <div class="quelle">
        <a class="btn" href="https://www.ionos.at/digitalguide/websites/webdesign/mobile-first-neuer-ansatz-im-webdesign/" target="_blank">Quelle</a>
      </div>
    </section>
    <section class="container" id="programmiersprachen">
      <h2>11.33 Kenntnisse über aktuelle Programmiersprachen</h2>
      <p><strong>JavaScript: </strong>Eine der am häufigsten verwendeten Sprachen für die Entwicklung von Webanwendungen und Frontend-Entwicklung. </p>
      <p><strong>Python: </strong>Vielseitige Sprache, die in den Bereichen Webentwicklung, Datenanalyse, künstliche Intelligenz und mehr weit verbreitet ist. </p>
      <p><strong>Java: </strong>Eine plattformunabhängige Sprache, die in Unternehmensanwendungen, mobilen Anwendungen (Android), und anderen Bereichen verwendet wird. </p>
      <p><strong>C#: </strong>Häufig für die Entwicklung von Windows-Anwendungen, Webanwendungen (mit ASP.NET) und Spieleentwicklung verwendet. </p>
      <div class="quelle">
        <a class="btn" href="https://mindsquare.de/karriere-news/programmiersprachen-ranking-2023/" target="_blank">Quelle</a>
      </div>
    </section>
    <section class="container" id="anwendungen">
      <h2>11.34 Kenntnisse über Programmiersprachen für mobile Anwendungen/Internet </h2>
      <p>Es gibt mehrere Programmiersprachen, die für die Entwicklung von mobilen Anwendungen und Webanwendungen im Internet verwendet werden. Hier sind einige der wichtigsten: </p>
      <h3>Mobile Anwendungen: </h3>
      <h3>Java: </h3>
      <ul class="left">
        <li>Verwendung: Android-Entwicklung mit dem Android SDK. </li>
        <li>Beschreibung: Java ist eine der am häufigsten verwendeten Programmiersprachen für die Entwicklung von Android-Apps. Es ist eine objektorientierte Sprache, die eine breite Palette von Bibliotheken und Frameworks bietet. </li>
      </ul>
      <h3>Swift:  </h3>
      <ul class="left">
        <li>Verwendung: iOS- und macOS-Entwicklung mit dem Apple SDK (Xcode). </li>
        <li>Beschreibung: Swift ist eine von Apple entwickelte moderne Programmiersprache für die Entwicklung von iOS- und macOS-Apps. Sie zeichnet sich durch eine klare Syntax, Sicherheit und Leistung aus. </li>
      </ul>
      <h3>Kotlin: </h3>
      <ul class="left">
        <li>Verwendung: Android-Entwicklung mit dem Android SDK. </li>
        <li>Beschreibung: Kotlin ist eine moderne Programmiersprache, die von JetBrains entwickelt wurde und von Google als offizielle Sprache für die Android-Entwicklung unterstützt wird. Sie bietet eine verbesserte Syntax im Vergleich zu Java und erhöhte Produktivität. </li>
      </ul>
      <h3>Webanwendungen: </h3>
      <h3>HTML/CSS/JavaScript: </h3>
      <ul class="left">
        <li>Verwendung: Webentwicklung für Frontend (HTML, CSS) und Backend (JavaScript). </li>
        <li>Beschreibung: Diese Technologien bilden das Grundgerüst für die Entwicklung von Webanwendungen. HTML wird für die Strukturierung des Inhalts verwendet, CSS für das Styling und JavaScript für die Interaktivität und Logik. </li>
      </ul>
      <h3>PHP:</h3>
      <ul class="left">
        <li>Verwendung: Backend-Entwicklung für dynamische Webseiten und Webanwendungen. </li>
        <li>Beschreibung: PHP ist eine serverseitige Skriptsprache, die für die Erstellung dynamischer Webseiten und Webanwendungen verwendet wird. Sie wird oft in Kombination mit einem Web-Framework wie Laravel, Symfony oder CodeIgniter eingesetzt. </li>
      </ul>
      <p>Die Wahl der Programmiersprache hängt von den Anforderungen des Projekts, den vorhandenen Kenntnissen des Entwicklers und den Zielplattformen ab. Jede Sprache hat ihre eigenen Vor- und Nachteile und ist für bestimmte Anwendungen besser geeignet. </p>
      <div class="quelle">
        <a class="btn" href="https://applaunch.io/blog/app-programmiersprache/" target="_blank">Quelle</a>
      </div>
    </section>
    <section class="container" id="java">
      <h2>11.35 Kenntnisse über die Anwendung von JAVA-Technologien im Web (Servlets, Java-Server-Pages) </h2>
      <p>Wenn ein Ziel die Trennung von HTML und Java-Code ist, dann ist weder ein reiner Servlet- noch ein reiner JSP-Ansatz richtig. Obwohl der Hybrid-Ansatz eine saubere Trennung ermöglicht, müssen Sie eventuell benutzerdefinierte JSP-Tags erzeugen, um alle Vorteile dieser Fähigkeit auszunutzen. Diese Methode unterstützt keine WML-Ausgabe, solange sie nicht den kompletten Code zur HTML-Erzeugung duplizieren. Obwohl die benutzerdefinierten JSP-Tags den Java-Code vor dem Autor der Seite verbergen, kann immer der Moment kommen, wo Sie HTML mittels Java-Code erzeugen müssen.  </p>
      <p>Web-Frameworks bauen gewöhnlich auf dem Hybrid-Ansatz auf und beinhalten Mehrwertfunktionen und andere Annehmlichkeiten. Frameworks haben den Vorteil, daß Sie einen konsistenten Weg definieren, die komplette Anwendung zu strukturieren, was im Hinblick auf Software-Wartung und -Pflege wahrscheinlich wichtiger ist, als irgendwelche Mehrwertfunktionalitäten. Der primäre Nachteil von Frameworks ist die potentielle Abhängigkeit von einem bestimmten Vorgehen und Anbieter. </p>
      <p>Der XSLT-Ansatz erreicht die maximal mögliche Trennung von Darstellung und zugrundeliegenden Daten. Er unterstützt auch mehrere Browser und sogar WML-Zielsysteme. Die XSLT-Transformation verursacht zusätzliche Verarbeitungslast in der Webschicht. Das muß vorsichtig gegen die Vorteile des von XSLT gebotenen, modularen, klaren Designs abgewogen werden. </p>
      <div class="quelle">
        <a class="btn" href="https://www.data2type.de/xml-xslt-xslfo/xslt/java-und-xslt/java-basierte-webtechnologien/zusammenfassung-der-wichtigste" target="_blank">Quelle</a>
      </div>
    </section>
    <section class="container" id="net">
      <h2>11.36 Grundkenntnisse über die Anwendung der .NET-Technologien im Web (ASP.NET)</h2>
      <h3>ASP.NET Web Forms:</h3>
      <ul class="left">
        <li>ASP.NET Web Forms ist ein Modell zur Erstellung von Webanwendungen, das auf Ereignisgesteuertem Programmiermodell basiert. </li>
        <li>Es ermöglicht die Entwicklung von Webanwendungen mit einem ähnlichen Entwicklungsansatz wie bei der Desktop-Entwicklung, bei dem Serversteuerelemente verwendet werden, um eine interaktive Benutzeroberfläche zu erstellen. </li>
        <li>Web Forms bietet umfangreiche Bibliotheken für Benutzeroberflächenelemente, Datenbindung, Authentifizierung, Sicherheit und vieles mehr. </li>
      </ul>
      <h3>ASP.NET MVC (Model-View-Controller): </h3>
      <ul class="left">
        <li>ASP.NET MVC ist ein leistungsfähiges Framework für die Entwicklung von Webanwendungen, das auf dem MVC-Muster basiert. </li>
        <li>Es trennt die Anwendungslogik in drei Hauptkomponenten: Model (Daten), View (Darstellung) und Controller (Steuerung), was die Trennung von Anliegen und die Wiederverwendbarkeit des Codes fördert. </li>
        <li>MVC bietet eine klare Trennung von Präsentationslogik und Geschäftslogik, was die Wartung und Skalierbarkeit von Webanwendungen erleichtert. </li>
      </ul>
      <h3>ASP.NET Core: </h3>
      <ul class="left">
        <li>ASP.NET Core ist die Weiterentwicklung von ASP.NET und wurde für die plattformübergreifende Entwicklung von Webanwendungen und -diensten entwickelt. </li>
        <li>Es ist Open Source und unterstützt die Entwicklung von Webanwendungen für verschiedene Plattformen wie Windows, macOS und Linux. </li>
        <li>ASP.NET Core bietet eine verbesserte Leistung, Modularität, Flexibilität und Unterstützung für moderne Webentwicklungstechniken wie Dependency Injection und Middleware-Pipeline. </li>
      </ul>
      <h3>ASP.NET Web API: </h3>
      <ul class="left">
        <li>ASP.NET Web API ist ein Framework für die Entwicklung von HTTP-basierten RESTful-Webdiensten. </li>
        <li>Es ermöglicht die Erstellung von Web-APIs zur Bereitstellung von Daten und Diensten für verschiedene Anwendungen und Plattformen, einschließlich Webanwendungen, mobilen Apps und IoT-Geräten. </li>
        <li>Web API bietet Unterstützung für Content Negotiation, Routing, Authentication und Authorization, Versionierung und mehr. </li>
      </ul>
      <div class="quelle">
        <a class="btn" href="" target="_blank">Quelle</a>
      </div>
    </section>
    <section class="container" id="metadaten">
      <h2>11.37 Fachbegriff Metadaten</h2>
      <p>
        Metadaten sind strukturierte Informationen, die die Eigenschaften, den Ursprung, die Nutzung und die Verarbeitung von Daten beschreiben. Sie spielen eine entscheidende Rolle, indem sie Kontext, Bedeutung und Management von Daten ermöglichen. In der digitalen Fotografie enthalten Metadaten zum Beispiel Informationen über Kameratyp, Einstellungen, Datum und Uhrzeit der Aufnahme. In Bibliotheken klassifizieren Metadaten Bücher und Materialien nach Autor, Titel, Veröffentlichungsdatum und anderen bibliographischen Details. In der Datenverarbeitung beschreiben sie Struktur und Zugriffsrechte von Dateien, während sie im Webkontext häufig für SEO verwendet werden, um Suchmaschinen relevante Informationen über den Inhalt von Webseiten zu liefern. Metadaten verbessern somit die Interoperabilität zwischen verschiedenen Systemen und erleichtern die Datenverwaltung, -suche und -wiederherstellung.
      </p>
      <div class="quelle">
        <a class="btn" href="https://de.wikipedia.org/wiki/Metadaten#:~:text=Metadaten%20oder%20Metainformationen%20sind%20strukturierte,%C3%BCber%20Merkmale%20anderer%20Daten%20enthalten" target="_blank">Quelle</a>
      </div>
    </section>
    <section class="container" id="dry">
      <h2>11.38 Prinzipien der Softwareentwicklung: KISS, DRY</h2>
      <h3>KISS</h3>
      <p>Das KISS-Prinzip (englisch: Keep it simple, stupid!) fordert, zu einem Problem die möglichst einfachste Lösung anzustreben, statt unnötige Komplexität zu erzeugen. </p>
      <h3>DRY</h3>
      <p>Don’t repeat yourself (deutsch: „wiederhole dich nicht“) ist ein Prinzip, das besagt, Redundanz zu vermeiden oder zumindest zu reduzieren. Es handelt sich hierbei auch um ein Prinzip von Clean Code. </p>
      <div class="quelle">
        <a class="btn" href="https://de.wikipedia.org/wiki/Don%E2%80%99t_repeat_yourself" target="_blank">Quelle</a>
      </div>
    </section>
    <section class="container" id="coding">
      <h2>11.39 Kenntnisse über Coding-Standards/Code-Konventionen</h2>
      <p>Coding-Standards oder Code-Konventionen sind gemeinsame Richtlinien und Vereinbarungen, die von Entwicklern und Entwicklungsteams befolgt werden, um den Code konsistent, lesbar und wartbar zu gestalten. </p>
      <h3>Einrückung und Formatierung: </h3>
      <p>Konsistente Einrückung verbessert die Lesbarkeit des Codes. Typischerweise werden vier Leerzeichen oder ein Tabulator für jede Einrückungsstufe verwendet. </p>
      <h3>Namensgebung: </h3>
      <p>Klare und aussagekräftige Namen für Variablen, Funktionen und Klassen erleichtern das Verständnis des Codes. Zum Beispiel sollten aussagekräftige Variablennamen verwendet werden, um den Zweck der Variable zu erklären. </p>
      <h3>Kommentare: </h3>
      <p>Kommentare sollten dort platziert werden, wo der Code nicht selbst erklärend ist. Sie sollten klar und prägnant sein. Jedoch sollte der Code so geschrieben sein, dass er weitgehend für sich selbst spricht. </p>
      <h3>Sprachspezifische Konventionen: </h3>
      <p>Verschiedene Programmiersprachen haben unterschiedliche Konventionen. Zum Beispiel folgt Python anderen Konventionen als JavaScript oder Java. Es ist wichtig, die Konventionen der spezifisch verwendeten Sprache zu verstehen. </p>
      <h3>Dateiorganisation: </h3>
      <p>Eine klare Strukturierung des Codes und der Dateien erleichtert die Wartung. Dies kann beinhalten, dass ähnliche Funktionen oder Klassen in separaten Dateien gruppiert werden. </p>
      <h3>Vermeidung von Magischen Zahlen und harten Codierungen: </h3>
      <p>Vermeiden Sie harte Codierungen von Zahlen oder anderen Werten direkt im Code. Stattdessen sollten Konstanten oder Konfigurationsdateien verwendet werden. </p>
      <h3>Testbarkeit und Modularität: </h3>
      <p>Code sollte so geschrieben sein, dass er leicht testbar ist. Funktionen sollten klar definierte Aufgaben haben und sollten nicht zu lang sein. </p>
      <h3>Dokumentation: </h3>
      <p>Neben Kommentaren im Code sollte es auch eine externe Dokumentation geben, die die Architektur, API und andere wichtige Aspekte des Systems beschreibt. </p>
      <h3>Version Control Konventionen: </h3>
      <p>Klare und konsistente Commit-Nachrichten und Branching-Konventionen sind wichtig, um die Zusammenarbeit in einem Versionskontrollsystem wie Git zu erleichtern. </p>
      <div class="quelle">
        <a class="btn" href="https://de.wikipedia.org/wiki/Programmierstil " target="_blank">Quelle</a>
      </div>
    </section>
    <section class="container" id="plattform">
      <h2>11.40 Fachbegriff Cross Plattform Entwicklung</h2>
      <p>
        Als Cross-Plattform-Entwicklung bezeichnet man die Entwicklung einer Anwendung für mehrere verschiedene Betriebssysteme. Auch der Webbrowser wird dabei als eine Plattform aufgefasst.
        <br>
        Wichtig in den Mobilen Anwendungen wo unterschiedliche Betriebssysteme vorhanden sind.
        <br>
        Um die Reichweite einer Anwendung zu maximieren und die Entwicklung und Wartung kosten zu senken.
      </p>
      <div class="quelle">
        <a class="btn" href="https://de.wikipedia.org/wiki/Plattformunabh%C3%A4ngigkeit#:~:text=Die%20Plattformunabh%C3%A4ngigkeit%20%E2%80%93%20genauer%20als%20plattform%C3%BCbergreifend,auf%20verschiedenen%20Computerplattformen%20ausf%C3%BChrbar%20macht. " target="_blank">Quelle</a>
      </div>
    </section>
    <section class="container" id="identity">
      <h2>11.41 Fachbegriff Corporate Identity (CI)</h2>
      <p>Der Begriff Corporate Identity (kurz: CI) bezeichnet die Identität eines Unternehmens. Sie steht für einen einheitlichen Unternehmensauftritt nach innen und außen. Ziel einer Corporate-Identity-Strategie ist es, eine eigenständige und unverwechselbare Unternehmenspersönlichkeit mit hohem Wiedererkennungswert zu schaffen. </p>
      <div class="quelle">
        <a class="btn" href="https://www.textbroker.de/corporate-identity " target="_blank">Quelle</a>
      </div>
    </section>
    <section class="container" id="corporate">
      <h2>11.42 Fachbegriff Corporate Design (CD)</h2>
      <p>Der Begriff Corporate Design bzw. Unternehmens-Erscheinungsbild bezeichnet einen Teilbereich der Unternehmens-Identität (corporate identity) und beinhaltet das gesamte, einheitliche Erscheinungsbild eines Unternehmens oder einer Organisation. Dazu gehören vorrangig die Gestaltung der Kommunikationsmittel:  </p>
      <ul class="left">
        <li>Firmenschriftzug  </li>
        <li>Firmensignet  </li>
        <li>Gestaltung	 </li>
        <li>Geschäftspapiere  </li>
        <li>Internetauftritte </li>
        <li>Verpackungen </li>
      </ul>
      <p>aber auch Werbemittel und die Produktgestaltung. Ebenso kann das gemeinsame Design für die Berufskleidung in das voll integrierte Erscheinungsbild einbezogen werden. Der oft fälschlich synonym verwandte Begriff Logo bezeichnet jedoch nur ein Element des Corporate Design und ist daher ungeeignet, um das „Konzept eines einheitlichen und umfassenden Firmen-Erscheinungsbilds“ zu beschreiben. Mit Corporate Design ist für ein Unternehmen ein geeignetes Zeichensystem festgelegt, das eingesetzt werden kann, um ein einheitliches und positives Bild des Unternehmens in der Öffentlichkeit sowie eine große Bekanntheit desselben zu erreichen (Wiedererkennungswert, Markenbekanntheit). </p>
      <div class="quelle">
        <a class="btn" href="https://de.wikipedia.org/wiki/Corporate_Design " target="_blank">Quelle</a>
      </div>
    </section>
    <section class="container" id="applikationsentwicklung">
      <h2>11.43 CI/CD Vorgaben bei der Applikationsentwicklung</h2>
      <h3>Continuous Integration (CI): </h3>
      <p>Versionskontrolle </p>
      <ul class="left">
        <li>Verwende Git. </li>
        <li>Nutze Feature Branching und Pull Requests. </li>
      </ul>
      <p>Automatisierte Builds </p>
      <ul class="left">
        <li>Automatisiere den Build-Prozess. </li>
        <li>Integriere Build-Skripte in die Versionskontrolle z.B. Jenkins. </li>
      </ul>
      <p>Automatisierte Tests </p>
      <ul class="left">
        <li>Führe automatisierte Tests durch (Unit, Integration, Akzeptanz). </li>
        <li>Nutze Tools wie JUnit, NUnit, Selenium. </li>
      </ul>
      <h3>Continuous Delivery/Continuous Deployment (CD): </h3>
      <p>Umgebungsmanagement </p>
      <ul class="left">
        <li>Verwende verschiedene Umgebungen (Entwicklung, Test, Produktion).</li>
      </ul>
      <p>Automatisierte Tests in verschiedenen Umgebungen </p>
      <ul class="left">
        <li>Führe automatisierte Tests in produktionsähnlichen Umgebungen durch. </li>
      </ul>
      <p>Logging </p>
      <ul class="left">
        <li>Nutze Tools für Leistungsüberwachung und Fehlerverfolgung.</li>
      </ul>
      <p>Sicherheit </p>
      <ul class="left">
        <li>Integriere Sicherheitsprüfungen und Schwachstellenanalysen. </li>
        <li>Setze Sicherheitsrichtlinien für die gesamte Pipeline um. </li>
      </ul>
      <p>Dokumentation </p>
      <ul class="left">
        <li>Pflege klare Dokumentation für den CI/CD-Prozess. </li>
        <li>Dokumentiere Setup-Schritte für Umgebungen.</li>
      </ul>

      <div class="quelle">
        <a class="btn" href="https://www.outsystems.com/de-de/glossary/what-is-ci-cd/ " target="_blank">Quelle</a>
        <a class="btn" href="https://www.redhat.com/en/topics/devops/what-is-ci-cd" target="_blank">Quelle</a>
      </div>
    </section>
      <div class="center">
          <a class="btn" href="InformatikTeil1.php">Zurück zu Informatik Teil 1</a>
          <a class="btn" href="Projektmanagement.php">Weiter zu Projektmanagement</a>
      </div>
  </article>
</main>
<?php include'include/footer.php' ?>