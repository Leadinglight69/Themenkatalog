<?php
$title = 'IT-Sicherheit und Betriebssicherheit: Schutz vor Cyberbedrohungen';
$description = 'Vertiefen Sie Ihr Wissen über IT-Sicherheit und Betriebssicherheit, einschließlich Schutz vor Viren, Würmern, Trojanern, Spyware, Hackern, Phishing, Zero-Day-Exploits und mehr. Entdecken Sie effektive Strategien zur Einschränkung von Benutzerkonten, die Bedeutung einer Software-Firewall, Methoden zum Schutz von Client-PCs vor Missbrauch, die sichere Planung von Backups sowie verschiedene Backup-Prinzipien und die richtige Lagerung von Backup-Medien. Sichern Sie Ihre IT-Infrastruktur und Daten vor den neuesten Cyberbedrohungen.';
$keywords = 'IT-Sicherheit, Betriebssicherheit, Viren, Würmer, Trojaner, Spyware, Hacker, Phishing, Zero-Day-Exploit, Benutzerkonten, Software-Firewall, Datenschutz, Backup-Planung, Backup-Prinzipien, Backup-Medien, Cyberbedrohungen';
$canonical = 'https://www.codeabschlussguide.de/it-sicherheit-und-betriebssicherheit';
include 'include/header.php'
?>
<body>
<main class="responsive">
  <section>
    <h1>7) IT-Security und Betriebssicherheit</h1>
    <ul class="listLegend"  style="list-style: none">
      <li><a href="#phishing">7.1 Kenntnisse über Gefahren von Viren, Würmern, Trojanern, Spyware, Hackern und Phishing</a></li>
      <li><a href="#exploit">7.2 Fachbegriff Zero - Day - Exploit</a></li>
      <li><a href="#benutzerkonten">7.3 Kenntnisse über Einschränkungs&shy;möglichkeiten bei Benutzerkonten</a></li>
      <li><a href="#firewall">7.4 Funktion einer Software-Firewall</a></li>
      <li><a href="#missbrauch">7.5 Kenntnisse über Möglichkeiten Client-PCs vor Missbrauch zu schützen</a></li>
      <li><a href="#backups">7.6 Kenntnisse über sichere Planung von Backups</a></li>
      <li><a href="#prinzipien">7.7 Kenntnisse über verschiedene Backup - Prinzipien</a></li>
      <li><a href="#lagerung">7.8 Kenntnisse über Backup-Medien und deren richtiger Lagerung</a></li>
    </ul>
    <aside class="floatingNav">
      <div class="floatingDot" data-section="#phishing"><span class="floatingText">7.1 </span></div>
      <div class="floatingDot" data-section="#exploit"><span class="floatingText">7.2 </span></div>
      <div class="floatingDot" data-section="#benutzerkonten"><span class="floatingText">7.3 </span></div>
      <div class="floatingDot" data-section="#firewall"><span class="floatingText">7.4 </span></div>
      <div class="floatingDot" data-section="#missbrauch"><span class="floatingText">7.5 </span></div>
      <div class="floatingDot" data-section="#backups"><span class="floatingText">7.6 </span></div>
      <div class="floatingDot" data-section="#prinzipien"><span class="floatingText">7.7 </span></div>
      <div class="floatingDot" data-section="#lagerung"><span class="floatingText">7.8 </span></div>
    </aside>
  </section>

  <article>
    <section class="container" id="phishing">
      <h2>7.1 Kenntnisse über Gefahren von Viren, Würmern, Trojanern, Spyware, Hackern und Phishing</h2>
      <h3>Computerviren</h3>
      <p>Computerviren haben ihren Namen durch die Fähigkeit erhalten, mehrere Dateien auf einem Computer zu „infizieren“. Sie verbreiten sich auf andere Geräte, wenn diese infizierten Dateien per E-Mail versendet oder über einen Wechseldatenträger, wie z. B. einen USB-Stick oder (damals noch) eine Diskette, übertragen werden. Laut National Institute of Standards and Technology (NIST) wurde der erste Computervirus namens „Brain“ 1986 entwickelt. Zwei Brüder waren es leid, dass Kunden die Software aus ihrem Geschäft illegal kopierten, und entwickelten so den Virus, der den Boot-Sektor der Disketten von Softwaredieben infizieren sollte. So wurde der Virus beim Kopieren der Disketten weitergegeben. </p>
      <h3>Würmer</h3>
      <p>Im Gegensatz zu Viren sind Würmer nicht auf menschliche Hilfe angewiesen, um sich zu verbreiten: Sie infizieren ein Gerät und nutzen dann Computernetzwerke, um sich auf andere Computer zu verbreiten – ohne Zutun der Benutzer. Indem sie Schwachstellen in den entsprechenden Netzwerken, wie z. B. Sicherheitslücken in E-Mail-Programmen, ausnutzen, können Würmer Tausende Kopien von sich versenden, um so neue Systeme zu infizieren und den Prozess erneut durchzuführen. Während viele Würmer früher lediglich Systemressourcen verbrauchten und so die Leistung reduzierten, enthalten die meisten neuen Würmer sogenannte „Payloads“, die dazu dienen, Dateien zu stehlen oder zu löschen. </p>
      <h3>Trojanische Pferde</h3>
      <p>Diese Programme werden im Allgemeinen nur als „Trojaner“ bezeichnet und tarnen sich als legitime Datei oder Software. Einmal heruntergeladen und installiert, nehmen Trojaner Änderungen am Computer vor und führen ohne Wissen oder Zustimmung des Opfers schädliche Aktivitäten durch. </p>
      <h3>Spyware</h3>
      <p>Spyware (kurz für „Spionagesoftware“) tut genau das, was ihr Name vermuten lässt: Sie spioniert Ihren Computer aus. Sie erfasst Daten, wie z. B. Ihre Tastenanschläge, Surfgewohnheiten und sogar Anmeldedaten, die dann an Dritte gesendet werden – für gewöhnlich Cyberkriminelle. Sie kann auch bestimmte Sicherheitseinstellungen auf Ihrem Computer ändern oder Ihre Netzwerkverbindungen beeinträchtigen. Laut TechEye bieten neue Arten von Spyware Unternehmen sogar die Möglichkeit, das Verhalten ihrer Benutzer über verschiedene Geräte hinweg nachzuverfolgen – und das ohne ihre Zustimmung.</p>
      <h3>Phishing</h3>
      <p>Phishing gilt als eine der ältesten Betrugsmethoden, seit es das Internet gibt. Cyberkriminelle versuchen hierbei durch Social Engineering, Phishing-E-Mails oder Malware sensible Kennwörter, Bank- und Bezahldaten abzufangen. Während klassisches Phishing Links und Anhänge mit bösartigen Weiterleitungen oder Malware-Downloads nutzte, sind moderne Phishing-Methoden nicht mehr zwingend auf die unfreiwillige Herausgabe wichtiger Daten angewiesen.
      </p>
      <h3>Hacker</h3>
      <p>Unter einem Hacker versteht man eine IT-technisch sehr versierte Person oder Personengruppen, die unautorisiert in fremde IT-Systeme eindringen. Dazu versuchen sie die Schwachstellen von IT-Systemen zu finden, um entweder auf sie aufmerksam zu machen oder sie für bestimmte Zwecke wie unbefugtes Eindringen oder zur Veränderung von Funktionen zu nutzen.</p>

      <div class="quelle">
        <a class="btn" href="" target="_blank">Quelle</a>
      </div>
    </section>

    <section class="container" id="exploit">
      <h2>7.2 Fachbegriff Zero - Day - Exploit</h2>
      <p>Ein Zero-Day-Exploit bezeichnet eine Angriffsmethode, die eine bisher unbekannte Schwachstelle in einer Software ausnutzt. Der Begriff „Zero-Day“ bezieht sich darauf, dass den Entwicklern der Software oder der Öffentlichkeit keine Zeit („Zero Days“) gegeben wurde, um auf die Entdeckung der Schwachstelle zu reagieren und eine Abwehrmaßnahme oder einen Patch zu entwickeln, bevor der Exploit erfolgt. Zero-Day-Exploits sind besonders gefährlich, weil sie unerwartet sind und es bis zu ihrer Entdeckung und Behebung keine direkte Verteidigung gegen sie gibt. Cyberkriminelle nutzen solche Exploits, um unautorisierten Zugriff zu erlangen, Daten zu stehlen oder Systeme zu beschädigen.</p>
      <div class="quelle">
        <a class="btn" href="https://www.ibm.com/topics/zero-day" target="_blank">Quelle</a>
      </div>
    </section>
    <section class="container" id="benutzerkonten">
      <h2>7.3 Kenntnisse über Einschränkungs&shy;möglichkeiten bei Benutzerkonten</h2>
      <p>Die Einschränkung von Benutzerkonten ist eine wichtige Maßnahme zur Gewährleistung der Sicherheit und des ordnungsgemäßen Betriebs von Computersystemen. Administratoren können Rechte und Zugriffe für verschiedene Benutzerkonten anpassen, um sicherzustellen, dass Nutzer nur auf die für ihre Rolle oder Aufgaben erforderlichen Ressourcen zugreifen können. Zu den Einschränkungsmöglichkeiten gehören das Festlegen von Passwortrichtlinien, die Beschränkung der Zugriffe auf bestimmte Dateien und Anwendungen, die Definition von Benutzerrollen und -gruppen mit spezifischen Rechten sowie die Implementierung von Zugriffsprotokollen und Überwachungsverfahren. Diese Maßnahmen tragen dazu bei, unbefugten Zugriff zu verhindern und die Integrität und Vertraulichkeit der Systeme und Daten zu schützen.</p>
      <div class="quelle">
        <a class="btn" href="https://www.bsi.bund.de/DE/Themen/Verbraucherinnen-und-Verbraucher/Informationen-und-Empfehlungen/Cyber-Sicherheitsempfehlungen/Basisschutz-fuer-Computer-Mobilgeraete/Basisschutz-fuer-Computer/Benutzerkonten/benutzerkonten_node.html" target="_blank">Quelle</a>
      </div>
    </section>
    <section class="container" id="firewall">
      <h2>7.4 Funktion einer Software - Firewall</h2>
      <p>
        Eine Firewall ist also per Definition dafür da, Angriffe auf Ihren Rechner abzuwehren. Doch wie wird das praktisch umgesetzt? Woher weiß die Software, welches Programm schädlich ist und welches nicht? Und wie lernt sie dazu, wenn neu programmierte Malware im Umlauf ist?
        <br>
        Zunächst ist es wichtig, zu wissen, dass die Firewall gar nicht erkennt, ob ein Zugriff feindlich oder harmlos ist. Sie überwacht lediglich die Zugriffe von Ihrem PC auf ein Netzwerk und umgekehrt. Ob einer dieser Zugriffe Gefahren birgt, entscheidet die Firewall auf der Basis von zuvor festgelegten Regeln.
      </p>
      <div class="quelle">
        <a class="btn" href="https://www.ionos.at/digitalguide/server/sicherheit/was-ist-eine-firewall/ " target="_blank">Quelle</a>
      </div>
    </section>
    <section class="container" id="missbrauch">
      <h2>7.5 Kenntnisse über Möglichkeiten Client - PCs vor Missbrauch zu schützen</h2>
      <p>Viele Benutzer sind der Meinung, Ihr PC sei zu wenig "interessant", um Sicherheitszwischenfällen zum Opfer zu fallen. Die Vielzahl an Schadsoftware in letzter Zeit sollte Sie eines besseren belehren. Und selbst Angreifer ("Cracker" oder "Hacker") missbrauchen PCs aus einem einfachen Grund: weil sie sich eben missbrauchen lassen. Ihr PC ist also schon alleine deshalb interessant genug, weil er Sicherheitsprobleme aufweist. </p>
      <h3>Administrative Rechte </h3>
      <p>Auf jedem Computer gibt es zumindest einen Benutzer - "Administrator" unter Windows, "root" unter Linux. Unter Windows neigen viele Benutzer auch dazu, ihrer persönlichen Benutzerkennung administrative Rechte zu geben.
        Sie sollten das auf jeden Fall vermeiden. Arbeiten Sie nur mit administrativen Rechten, wenn das unbedingt notwendig ist. Damit reduzieren Sie den Schaden, den ein Schadprogramm oder aber auch Sie selbst anrichten können. </p>
      <h3>Passwörter</h3>
      <p>Wählen Sie für den Zugang auf Ihrem PC (inklusive dem Benutzer "Administrator" unter Windows oder "root" unter Linux) ein geeignetes Passwort.
        Eine Beschreibung finden Sie unter Sicherer Umgang mit Passwörtern </p>
      <h3>Weitergabe von Passwörtern </h3>
      <p>Betrachten Sie Ihre Passwörter als genauso wichtig wie den Code Ihrer Bankomatkarte. Abgesehen davon, dass die Benutzungsordnung die Weitergabe verbietet, entstehen dadurch Sicherheitsprobleme. Jeder Missbrauch unter Ihrer Benutzerkennung wird mit Ihnen in Verbindung gebracht. </p>
      <h3>Phising Emails </h3>
      <p>Leider kommt es immer häufiger vor das Sie per Email aufgefordert werden Accountinformationen weiterzugeben. Bitte niemals auf solche Emails antworten oder die Weblinks in solchen Emails zu öffnen.
        Sie können solche Emails daran erkennen, dass sie in "holprigen" Deutsch oder Englisch verfasst sind. Sie können außerdem die Email-Absendeadresse genauer analysieren. Bitte gehen Sie vorsichtig und ruhig mit dem Medium Email um!</p>
      <h3>Rechner ausschalten </h3>
      <p>Schalten Sie Ihren Rechner ab, wenn Sie Ihn länger nicht benötigen (besonders am Abend und am Wochenende). Sie sparen nicht nur Strom sondern viele Angreifer versuchen, an den Randzeiten in PCs einzudringen.
        Erstens weil sie hier weniger Gefahr laufen, Verdacht zu erwecken und zweitens weil ein Rechner, der zu diesen Zeiten läuft, meist fast nie abgeschaltet wird und dadurch von den Angreifern jederzeit missbraucht werden kann.
        Rechner, die nur wenige Stunden pro Tag laufen, sind für Angreifer weit weniger attraktiv. </p>
      <h3>Updates </h3>
      <p>Einer der wichtigsten Punkte zur Sicherheit Ihres Systems ist, dass alle verfügbaren Sicherheitsupdates immer zeitgerecht eingespielt sind. Jede Verwundbarkeit, die von einem anderen Systemen aus ausnutzbar ist, wird auch aktiv von einem Schadsoftware oder Angreifer ausgenützt </p>
      <div class="quelle">
        <a class="btn" href="https://www.uibk.ac.at/zid/security/pc-basics.html" target="_blank">Quelle</a>
      </div>
    </section>
    <section class="container" id="backups">
      <h2>7.6 Kenntnisse über sichere Planung von Backups</h2>
      <h3>Die sichere Planung von Backups umfasst mehrere Schritte: </h3>
      <p><strong>Bewertung der Daten: </strong>Identifiziere, welche Daten wichtig sind und gesichert werden müssen. </p>
      <p><strong>Auswahl der Backup-Methode: </strong>Es gibt verschiedene Methoden wie Vollständige Backups, Differenzielle Backups und Inkrementelle Backups. </p>
      <p><strong>Regelmäßige Backup-Routine: </strong>Plane regelmäßige Backups, um sicherzustellen, dass deine Daten immer aktuell sind. </p>
      <p><strong>Verschlüsselung und Sicherheit: </strong>Stelle sicher, dass deine Backups sicher und verschlüsselt sind, um Datenverlust oder -Diebstahl zu verhindern. </p>
      <p><strong>Aufbewahrung an einem sicheren Ort: </strong>Bewahre deine Backups an einem sicheren Ort auf, der von deinen ursprünglichen Daten getrennt ist. </p>
      <div class="quelle">
        <a class="btn" href="https://www.computerweekly.com/de/feature/Die-besten-Tipps-fuer-einen-sinnvollen-Backup-Plan " target="_blank">Quelle</a>
      </div>
    </section>
    <section class="container" id="prinzipien">
      <h2>7.7 Kenntnisse über verschiedene Backup - Prinzipien</h2>
      <h3>Komplett-/Vollsicherung </h3>
      <p>Die Komplett- oder Vollsicherung wird in Programmen auch als „Normale Sicherung“ bezeichnet. Hierbei werden die jeweils zu sichernden Daten (ein komplettes Laufwerk, eine Partition, bestimmte Verzeichnisse und/oder bestimmte Dateien, bestimmte Dateiformate) vollständig auf das Sicherungsmedium übertragen und als gesichert markiert.
        <br>
        Die Vollsicherung ist technisch sehr einfach, da Daten lediglich kopiert werden. Durch die vollständige Kopie der Daten hat die Vollsicherung einen sehr hohen Speicherbedarf und die Sicherung selbst ist bei großen Datenmengen sehr zeitintensiv. Oft wird die Sicherung deshalb parallelisiert, wodurch allerdings die Arbeitsgeschwindigkeit reduziert wird.[3]
        <br>
        Für manche Dateisystemen kann ein lesbarer Snapshot der zu sichernden Daten erstellt werden. Während die Sicherung des Snapshots im Hintergrund durchgeführt wird, können bereits Änderungen an den Daten vorgenommen werden, welche dann über Copy-On-Write gespeichert werden.[4] Das Dateisystem kann auch während der Dauer des Backups genutzt werden und die Sicherung ist konsistent. </p>
      <h3>Differenzielle Sicherung </h3>
      <p>Bei der sogenannten differenziellen Sicherung werden alle Dateien gespeichert, die seit der letzten Komplettsicherung geändert wurden oder neu hinzugekommen sind. Es wird auf der letzten Komplettsicherung aufgesetzt, wobei gegenüber einer neuen Vollsicherung Speicherplatz und Zeit gespart werden kann. Differenzielle Sicherungsstände hängen lediglich von der letzten Komplettsicherung ab und sind unabhängig von anderen differenziellen Sicherungsständen. Nicht mehr benötigte Sicherungsstände können unabhängig voneinander gelöscht werden.
        <br>
        Bei sehr großen Dateien, die sich häufig ändern (virtuelle Maschinen, Datenbanken, Postfach-Dateien mancher E-Mail-Programme) ist die differenzielle Sicherung nachteilig, da bei kleinsten Änderungen jedes Mal die gesamte Datei gesichert wird. </p>
      <h3>Inkrementelle Sicherung </h3>
      <p>Bei der inkrementellen Sicherung werden die Dateien oder Teile von Dateien gespeichert, die seit der letzten inkrementellen Sicherung oder (im Falle der ersten inkrementellen Sicherung) seit der letzten Komplettsicherung geändert oder hinzugefügt wurden. Es wird immer auf der letzten inkrementellen Sicherung aufgesetzt. Bei einer Wiederherstellung müssen die Daten aus mehreren Sicherungen zusammengetragen werden. Dafür muss gewährleistet sein, dass die vollständige Kette aller Sicherungen bis zur letzten Vollsicherung in der korrekten Abfolge fehlerfrei nachvollziehbar ist. Dies wird z. B. durch Datumsstempel oder Prüfsummen erreicht.
        <br>
        Die inkrementelle Sicherung hat einen sehr geringen Speicherbedarf, das Verfahren eignet sich daher für die Datensicherung in Netzwerken oder in der Cloud. Andererseits sind prinzipbedingt alle Inkremente miteinander verkettet, weshalb es nur mit großem Rechenaufwand möglich ist, ein Inkrement zwischen zwei anderen Inkrementen zu entfernen, etwa um Speicherplatz zu sparen oder private Daten zu löschen. </p>
      <div class="quelle">
        <a class="btn" href="https://de.wikipedia.org/wiki/Datensicherung" target="_blank">Quelle</a>
      </div>
    </section>
    <section class="container" id="lagerung">
      <h2>7.8 Kenntnisse über Backup - Medien und deren richtiger Lagerung</h2>
      <p><strong>Backup-Medienarten: </strong>Es gibt verschiedene Arten von Backup-Medien, darunter magnetische Bänder, Festplatten, optische Medien wie CDs oder DVDs, Solid-State-Laufwerke (SSDs) und Cloud-Backups. </p>
      <ul class="left">
        <li><strong>Zuverlässigkeit der Medien: </strong>Die Zuverlässigkeit der Backup-Medien variiert je nach Typ. Magnetbänder können eine lange Lebensdauer haben, aber sie sind anfällig für Magnetfelder und mechanische Beschädigungen. Festplatten sind schnell und einfach zu verwenden, aber sie können ausfallen und erfordern regelmäßige Aktualisierungen. Optische Medien haben eine begrenzte Haltbarkeit und sind empfindlich gegenüber Kratzern und Sonnenlicht. </li>
        <li><strong>Lagerungsumgebung: </strong>Backup-Medien sollten in einer geeigneten Umgebung gelagert werden, die vor extremen Temperaturen, Feuchtigkeit, Staub und Sonnenlicht geschützt ist. Ideal ist ein kühler, trockener und dunkler Ort. </li>
        <li><strong>Sicherheitsaspekte: </strong>Backup-Medien sollten vor unbefugtem Zugriff geschützt werden. Sie können in einem feuerfesten Safe oder einem verschlossenen Schrank aufbewahrt werden, um die Sicherheit zu erhöhen. </li>
        <li><strong>Regelmäßige Überprüfung: </strong>Es ist wichtig, regelmäßig zu überprüfen, ob die Backup-Medien noch lesbar sind und ob die gespeicherten Daten intakt sind. Dies kann durch periodische Tests und Wartungsarbeiten erfolgen. </li>
        <li><strong>Geografische Trennung: </strong>Zur Sicherung gegen Katastrophen wie Brände oder Überschwemmungen sollten Backups an einem anderen Ort als dem primären Standort aufbewahrt werden. Dies kann bedeuten, dass sie in einem anderen Gebäude oder an einem entfernten Standort aufbewahrt werden. </li>
        <li><strong>Verschlüsselung: </strong>Sensible Daten sollten vor der Sicherung verschlüsselt werden, um sicherzustellen, dass sie auch bei einem Diebstahl der Backup-Medien geschützt sind. </li>
      </ul>
      <div class="quelle">
        <a class="btn" href="https://www.ionos.at/digitalguide/server/sicherheit/daten-sichern/" target="_blank">Quelle</a>
        <a class="btn" href="https://www.ionos.at/digitalguide/server/sicherheit/was-ist-ein-backup/" target="_blank">Quelle</a>
      </div>
    </section>
      <div class="center">
          <a class="btn" href="netzwerkdienste.php">Zurück zu Netzwerkdienste</a>
          <a class="btn" href="informatikUndGesellschaft.php">Weiter zu Informatik und Gesellschaft</a>
      </div>
  </article>
</main>
<?php include'include/footer.php' ?>