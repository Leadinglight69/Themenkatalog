<?php
$title = 'Grundlagen der Netzwerkdienste: Domain-Management, Web-Protokolle und Cloud-Computing';
$description = 'Entdecken Sie die essenziellen Aspekte der Netzwerkdienste, einschließlich Domain-Strukturierung, Sicherheitsprotokollen wie HTTP und HTTPS, dem Funktionsprinzip von Mail-Servern, gängigen Mail-Protokollen wie POP3/IMAP/SMTP, FTP/FTPS-Verbindungen, SSL-Verschlüsselung, sowie umfassenden Einblicken in Cloud-Computing, einschließlich Private, Public und Hybrid Clouds, IaaS, PaaS, SaaS und der Auswahl von Cloud-Diensten basierend auf spezifischen Geschäftsanforderungen.';
$keywords = 'Netzwerkdienste, Domain, Sub-Domain, Top-Level-Domain, HTTP, HTTPS, Mail-Server, POP3, IMAP, SMTP, FTP, FTPS, SSL, Cloud-Computing, Private Cloud, Public Cloud, Hybrid Cloud, IaaS, PaaS, SaaS, Cloud-Dienste';
$canonical = 'https://www.codeabschlussguide.de/netzwerkdienste';
include 'include/header.php'
?>
<main class="responsive">
  <section>
    <h1>6) Netzwerkdienste</h1>
    <ul class="listLegend"  style="list-style: none">
      <li><a href="#top-Level-Domain">6.1 Fachbegriffe Domain, Sub-Domain und Top - Level - Domain</a></li>
      <li><a href="#httpundhttps">6.2 Kenntnis der Web-Protokolle HTTP und HTTPS</a></li>
      <li><a href="#eMail-Servers">6.3 Funktionsprinzip eines Mail-Servers</a></li>
      <li><a href="#pOP3S">6.4 Kenntnis des Mail-Protokolls POP3/POP3S</a></li>
      <li><a href="#iMAPS">6.5 Kenntnis des Mail-Protokolls IMAP/IMAPS</a></li>
      <li><a href="#sMTPS">6.6 Kenntnis des Mail-Protokolls SMTP/SMTPS</a></li>
      <li><a href="#ftp">6.7 Kenntnisse über FTP/FTPS</a></li>
      <li><a href="#ssl">6.8 Kenntnisse über SSL</a></li>
      <li><a href="#cloud-Computing">6.9 Fachbegriff Cloud - Computing</a></li>
      <li><a href="#hybridCloud">6.10 Kenntnisse über Private / Public / Hybrid Cloud</a></li>
      <li><a href="#saas">6.11 Fachbegriffe IaaS, PaaS, SaaS</a></li>
      <li><a href="#cloud-Dienste">6.12 Beispiele für marktbekannte Cloud - Dienste</a></li>
      <li><a href="#Kriterien">6.13 Kriterien und Voraussetzungen für den Einsatz von Cloud - Diensten</a></li>
    </ul>
    <aside class="floatingNav">
      <div class="floatingDot" data-section="#top-Level-Domain"><span class="floatingText">6.1 top-Level-Domain</span></div>
      <div class="floatingDot" data-section="#httpundhttps"><span class="floatingText">6.2 </span></div>
      <div class="floatingDot" data-section="#eMail-Servers"><span class="floatingText">6.3 </span></div>
      <div class="floatingDot" data-section="#pOP3S"><span class="floatingText">6.4 </span></div>
      <div class="floatingDot" data-section="#iMAPS"><span class="floatingText">6.5 </span></div>
      <div class="floatingDot" data-section="#sMTPS"><span class="floatingText">6.6 </span></div>
      <div class="floatingDot" data-section="#ftp"><span class="floatingText">6.7 </span></div>
      <div class="floatingDot" data-section="#ssl"><span class="floatingText">6.8 </span></div>
      <div class="floatingDot" data-section="#cloud-Computing"><span class="floatingText">6.9 </span></div>
      <div class="floatingDot" data-section="#hybridCloud"><span class="floatingText">6.10 </span></div>
      <div class="floatingDot" data-section="#saas"><span class="floatingText">6.11 </span></div>
      <div class="floatingDot" data-section="#cloud-Dienste"><span class="floatingText">6.12 </span></div>
      <div class="floatingDot" data-section="#Kriterien"><span class="floatingText">6.13 </span></div>
    </aside>
  </section>

  <article>
    <section class="container" id="top-Level-Domain">
      <h2>6.1 Fachbegriffe Domain, Sub-Domain und Top-Level - Domain</h2>
      <p><strong>Domain: </strong>Eine Domain ist der eindeutige Name, der einem von einem DNS (Domain Name System) verwalteten Bereich im Internet zugewiesen wird. Sie ist Teil der URL, die benutzt wird, um verschiedene Webseiten aufzurufen. Zum Beispiel in der URL "http://www.example.com", ist example.com die Domain, die auf den spezifischen Host im Internet hinweist. </p>
      <p><strong>Sub-Domain: </strong>Eine Sub-Domain bildet eine Unterteilung der Hauptdomain und dient dazu, verschiedene Bereiche oder Funktionen einer Website zu strukturieren. Eine Sub-Domain steht typischerweise vor der Hauptdomain. Zum Beispiel wäre blog.example.com eine Sub-Domain der Hauptdomain example.com, die speziell für den Blog-Bereich der Website verwendet werden könnte. </p>
      <p><strong>Top-Level-Domain (TLD): </strong>Die TLD ist der Teil einer Domain, der sich ganz rechts in der Domain-Struktur befindet. Es gibt zwei Arten von TLDs: generische TLDs (gTLDs), wie .com, .org, .net, die nicht spezifisch für ein Land sind, und country-code TLDs (ccTLDs), die aus zwei Buchstaben bestehen und für ein bestimmtes Land oder eine bestimmte Region stehen, wie .de für Deutschland und .uk für das Vereinigte Königreich. TLDs sind die höchste Ebene in der Hierarchie des Domain-Namenssystems. </p>
      <div class="quelle">
        <a class="btn" href="https://de.wikipedia.org/wiki/Domain_(Internet) " target="_blank">Quelle</a>
        <a class="btn" href="https://www.ionos.at/digitalguide/domains/domainendungen/domaintypen/ " target="_blank">Quelle</a>
      </div>
    </section>
    <section class="container" id="httpundhttps">
      <h2>6.2 Kenntnis der Web - Protokolle HTTP und HTTPS</h2>
      <h3>HTTPS: eine Definition </h3>
      <p>Das Hypertext Transfer Protocol Secure (HTTPS) ist ein Kommunikationsprotokoll im World Wide Web, mit dem sich im Gegensatz zu HTTP (Hypertext Transfer Protocol) Daten verschlüsselt und somit möglichst abhör- sowie fälschungssicher übertragen lassen. Anfangs setzten Webmaster die HTTPS-Technologie ausschließlich auf Websites ein, auf denen auch sensible Inhalte verarbeitet wurden – etwa beim Online-Banking oder im E-Commerce. Mittlerweile hat sich das verschlüsselte Übertragungsprotokoll allerdings als Standard im Internet durchgesetzt. Die meisten Seitenbetreiber sichern ihren Online-Auftritt mit HTTPS ab – allein schon, um in Suchmaschinen besser zu ranken. In den meisten Browsern weist ein Vorhängeschlosssymbol auf HTTPS-verschlüsselte Inhalte hin, während ungeschützte Seiten als potenziell unsicher gekennzeichnet werden.
      </p>
      <h3>Wie funktioniert HTTPS? </h3>
      <p>HTTP und HTTPS funktionieren beide nach dem Client-Server-Prinzip. Als Client fungiert in der Regel der Webbrowser und als HTTP-Server der Webserver. Um eine Webseite aufzurufen, sendet der Webbrowser eine Anfrage an den Webserver, der diese bearbeitet, eine Antwort zurückschickt und die Verbindung schließt. Anfrage und Antwort bestehen aus einem Header mit Steuerinformationen und den eigentlichen Daten. Die Kommunikation selbst basiert auf dem Textformat und erfolgt über TCP (Transmission Control Protocol) auf Port 80. </p>
      <p>In der Anfrage adressiert der Browser eine Datei auf dem Server, die dieser ihm schicken soll. Dazu übermittelt er im Header eine URL, die aus der Angabe des Transportprotokolls (http://), dem Servernamen (optional), dem Domainnamen und der abschließenden Top-Level-Domain (z.B. .de oder .com) besteht. Bei HTTPS authentifiziert sich der Server zusätzlich mittels eines SSL/TLS-Zertifikats (Secure Sockets Layer / Transport Layer Security) gegenüber dem Client. Letzterer schickt dem Server im Anschluss eine zufällige Zahl, die mit dem Zertifikat des Servers verschlüsselt wurde. In weiterer Folge errechnen Client und Server einen Schlüssel, mit dem die weitere Kommunikation codiert wird. </p>
      <div class="quelle">
        <a class="btn" href="https://www.myrasecurity.com/de/knowledge-hub/https/#:~:text=Das%20Hypertext%20Transfer%20Protocol%20Secure,abh%C3%B6r%2D%20sowie%20f%C3%A4lschungssicher%20%C3%BCbertragen%20lassen" target="_blank">Quelle</a>
      </div>
    </section>
    <section class="container" id="eMail-Servers">
      <h2>6.3 Funktionsprinzip eines Mail - Servers</h2>
      <h3>Empfang (Reception): </h3>
      <p>Der Mail-Server empfängt E-Mails von anderen Mail-Servern oder von E-Mail-Clients (wie Outlook, Thunderbird) über das Internet oder ein anderes Netzwerkprotokoll wie SMTP (Simple Mail Transfer Protocol) für ausgehende E-Mails.
      </p>
      <h3>Zustellung (Delivery): </h3>
      <p>Nachdem eine E-Mail empfangen wurde, wird sie im Posteingang des Empfängers gespeichert. Der Mail-Server überprüft die Adresse der E-Mail und leitet sie an das entsprechende Postfach (Mailbox) des Empfängers weiter. </p>
      <h3>Speicherung (Storage): </h3>
      <p>Der Mail-Server speichert die empfangenen E-Mails, sodass der Empfänger später darauf zugreifen kann. Die Speicherung kann auf dem Server selbst oder auf einem externen Speicherort erfolgen. </p>
      <h3>Weiterleitung (Forwarding): </h3>
      <p>Der Mail-Server leitet E-Mails an andere Server oder Postfächer weiter, wenn dies erforderlich ist. Dies kann aufgrund von Weiterleitungsregeln, Aliasen oder anderen Konfigurationseinstellungen geschehen. </p>
      <h3>Versand (Transmission): </h3>
      <p>Wenn ein Benutzer eine E-Mail sendet, wird sie vom Mail-Client des Benutzers an den Mail-Server gesendet. Der Mail-Server verwendet das SMTP-Protokoll, um die E-Mail an den Server des Empfängers zu übertragen.
      </p>
      <h3>Authentifizierung und Autorisierung: </h3>
      <p>Mail-Server verwenden Authentifizierungsmechanismen, um sicherzustellen, dass nur autorisierte Benutzer E-Mails senden oder empfangen können. Dies kann die Verwendung von Benutzernamen und Passwörtern oder anderen Sicherheitsmechanismen einschließen.
      </p>
      <h3>Sicherheit und Spam-Filterung: </h3>
      <p>Mail-Server implementieren oft Sicherheitsmaßnahmen wie Verschlüsselung (z. B. SSL/TLS) und Spam-Filter, um unerwünschte E-Mails herauszufiltern und die Sicherheit der Kommunikation zu gewährleisten. </p>
      <h3>Protokollierung und Überwachung: </h3>
      <p>
        Mail-Server protokollieren oft alle eingehenden und ausgehenden E-Mails sowie andere relevante Ereignisse. Dies dient der Überwachung, Fehlerbehebung und Sicherheitsanalyse.
        <br>
        Insgesamt arbeitet ein Mail-Server daran, die E-Mail-Kommunikation zwischen verschiedenen Benutzern und Organisationen zu ermöglichen, indem er E-Mails sendet, empfängt, speichert und weiterleitet. Der Einsatz von Standards wie SMTP, POP3 (Post Office Protocol) und IMAP (Internet Message Access Protocol) ermöglicht die Interoperabilität zwischen verschiedenen Mail-Servern
      </p>
      <div class="quelle">
        <a class="btn" href="https://www.mailjet.com/de/blog/email/smtp-server/ " target="_blank">Quelle</a>
      </div>
    </section>
    <section class="container" id="pOP3S">
      <h2>6.4 Kenntnis des Mail - Protokolls POP3/POP3S</h2>
      <p>POP ist ein Kommunikationsprotokoll, um E-Mails von einem Posteingangsserver (POP-Server) abzuholen.
        Die Kommunikation erfolgt zwischen einem E-Mail-Client und einem E-Mail-Server (Posteingangsserver).
        Das Protokoll, das diesen Zugriff regelt, nennt sich POP (aus dem Jahr 1984), das in der aktuellen Version 3 vorliegt, und deshalb auch als POP3 bezeichnet wird.
        Per Fernzugriff werden die gespeicherten E-Mails abgerufen und auf dem lokalen Computer gespeichert. </p>
      <p>POP sieht das Prinzip der Offline-Verarbeitung von E-Mails vor.
        Online werden die E-Mails vom Posteingangsserver vom E-Mail-Client heruntergeladen.
        Erst nach erfolgreichem und vollständigem Zugriff werden die E-Mails auf dem Server gelöscht.
        Die Bearbeitung der eingegangenen E-Mails erfolgt anschließend auf dem lokalen Computer des Benutzers ohne Verbindung (offline) POP-Server.
        Die Verbindung zwischen POP-Server und E-Mail-Client erfolgt über TCP auf Port 110.
        Eine POP-Verbindung umfasst mehrere Sitzungsstufen.
        Nach dem der POP-Server die Verbindung mit einer positiven Meldung bestätigt hat, beginnt der „Authorization State“, die Sitzung zur Benutzeranmeldung.
        Hier muss sich der E-Mail-Client gegenüber dem Server mit Benutzername und Passwort identifizieren. </p>
      <p>Nach erfolgreicher Identifizierung erfolgt der „Transaction State“, die Sitzung zur Anforderung und Übermittlung der E-Mails.
        Hier werden alle Befehle zur Bearbeitung von E-Mails ausgeführt.
        Sendet der E-Mail-Client den Befehl QUIT, beginnt der „Update State“, in dem alle vom E-Mail-
        Client angegebenen Änderungen ausgeführt werden.
        Die Verbindung über TCP ist zu diesem Zeitpunkt schon beendet.
        Der letzte Vorgang, der „Update State“ stellt sicher, dass E-Mails nur dann auf dem Server gelöscht werden, wenn die Verbindung vom E-Mail-Client ordnungsgemäß beendet wurde. </p>
      <div class="quelle">
        <a class="btn" href="https://wiki.pc-pannendienst.de/kenntnis-des-mail-protokolls-pop3s-post-office-protokoll/ " target="_blank">Quelle</a>
      </div>
    </section>
    <section class="container" id="iMAPS">
      <h2>6.5 Kenntnis des Mail-Protokolls IMAP/IMAPS</h2>
      <p>Das Internet Message Access Protocol (IMAP), ursprünglich Interactive Mail Access Protocol, ist ein Netzwerkprotokoll, das ein Netzwerkdateisystem für E-Mails bereitstellt.
        <br>
        IMAP wurde in den 1980er Jahren mit dem Aufkommen von Personal Computer entworfen, um bei der Mail-Kommunikation Abhängigkeiten von einzelnen Client-Rechnern aufzulösen. Zu diesem Zweck erweitert IMAP die Funktionen und Verfahren des Post Office Protocol (POP) so, dass Benutzer ihre Mails, Ordnerstrukturen und Einstellungen auf den Mail-Servern speichern und belassen können. Während bei der Verwendung von POP die Nachrichten entweder nach dem Abruf gelöscht oder beim nächsten Abruf erneut empfangen werden, ermöglicht IMAP eine zentrale Verwaltung mit Suchfunktion und serverseitiger „Gelesen“ - Markierung.
        <br>
        Bei der Verwendung von IMAPS wird die Verbindung zum Server bereits während des Verbindungsaufbaus durch SSL verschlüsselt. Damit der Server das erkennt, muss ein anderer Port verwendet werden. Dafür wurde der Port 993 reserviert. </p>
      <div class="quelle">
        <a class="btn" href="https://de.wikipedia.org/wiki/Internet_Message_Access_Protocol" target="_blank">Quelle</a>
      </div>
    </section>
    <section class="container" id="sMTPS">
      <h2>6.6 Kenntnis des Mail - Protokolls SMTP/SMTPS</h2>
      <h3>SMTP - Simple Mail Transfer Protocol </h3>
      <p>SMTP ist ein Kommunikations&shy;protokoll für die Übertragung von E-Mails. Die Kommunikation erfolgt zwischen einem E-Mail-Client und einem SMTP-Server (Postausgangsserver) oder zwischen zwei SMTP-Server.
        <br>
        Für den Austausch der E-Mails sind die Mail Transfer Agents (MTAs) zuständig. Untereinander verständigen sich die MTAs mit dem SMTP-Protokoll. </p>
      <h3>Nachteile von SMTP (Sendet Mails) </h3>
      <p>SMTP hat mehrere große Nachteile. Zum einen wird für versendete E-Mails keine Versandbestätigung zurückgeliefert. Geht eine E-Mail verloren, werden weder Sender noch Empfänger darüber informiert.</p>
      <p>Kann eine E-Mail nicht zugestellt werden, sieht die SMTP-Spezifikation die Benachrichtigung des Senders vor. Es gibt zwar eine SMTP-Erweiterung für standardisierte Fehlermeldungen, allerdings unterstützen nicht alle SMTP-Server diese Erweiterung. Die meisten unzustellbaren E-Mails enthalten nur eine mehr oder weniger verständliche Fehlermeldung in englischer Sprache und den Header der gesendeten E-Mail.</p>
      <p>
        Ein weiteres Problem von SMTP ist die nicht vorhandene Authentisierung des Benutzers beim Verbindungsaufbau zwischen SMTP-Client und SMTP-Server. Das führt dazu, dass eine beliebige Absenderadresse beim Versand einer E-Mail angegeben werden kann. In der Praxis sieht das dann so aus, dass über offene SMTP-Server massenhaft Werbe-E-Mails, der sogenannte Spam, versendet wird. Aufgrund der gefälschten Absender-Adressen kann der eigentliche Urheber nur mit viel Mühe ermittelt werden.
      </p>
      <div class="quelle">
        <a class="btn" href="https://www.elektronik-kompendium.de/sites/net/0903081.html " target="_blank">Quelle</a>
      </div>
    </section>
    <section class="container" id="ftp">
      <h2>6.7 Kenntnisse über FTP/FTPS </h2>
      <p>FTP steht für File Transfer Protocol und ist ein Netzwerkprotokoll, dass Daten über ein IP-Netzwerk überträgt. Es wird zum Datentransfer zwischen Clients und Servern oder mehreren Servern, gesteuert von Clients, verwendet. Mögliche Anwendungen sind das Anlegen, Auslesen, Umbenennen oder Löschen von Verzeichnissen und Dateien.
        <br>
        FTPS sendet Daten mit TLS (Transport Layer Security) Verschlüsselung. </p>
      <div class="quelle">
        <a class="btn" href="https://ecosio.com/de/blog/unterschiede-zwischen-sftp-und-ftps-im-rahmen-von-edi-und-welche-einsatzmoeglichkeiten-gibt-es/#:~:text=Technisch%20gesehen%20hat%20SFTP%20mit,Transport%20Layer%20Security)%20gesetzt%20wird. " target="_blank">Quelle</a>
        <a class="btn" href="https://it-service.network/it-lexikon/ftp#:~:text=Die%20Abk%C3%BCrzung%20FTP%20steht%20f%C3%BCr,Datei%C3%BCbertragung%20%C3%BCber%20ein%20IP%2DNetzwerk" target="_blank">Quelle</a>
      </div>
    </section>
    <section class="container" id="ssl">
      <h2>6.8 Kenntnisse über SSL </h2>
      <p>SSL (Secure Sockets Layer) ist ein Verschlüsselungs&shy;protokoll, das entwickelt wurde, um die Sicherheit der Datenübertragung über das Internet zu gewährleisten. Es stellt eine sichere Verbindung zwischen einem Webbrowser und einem Webserver her, indem es die übertragenen Daten verschlüsselt. Hier sind einige grundlegende Kenntnisse über SSL: </p>
      <ul class="left">
        <li><strong>Verschlüsselung: </strong>SSL verwendet asymmetrische und symmetrische Verschlüsselungstechniken, um die Daten während der Übertragung zu schützen. Asymmetrische Verschlüsselung wird für den Austausch von Schlüsseln verwendet, während symmetrische Verschlüsselung für die eigentliche Datenübertragung verwendet wird. </li>
        <li><strong>Authentifizierung: </strong>SSL ermöglicht auch die Authentifizierung des Servers durch den Client. Dies geschieht durch den Einsatz von digitalen Zertifikaten, die vom Server signiert und von vertrauenswürdigen Zertifizierungsstellen ausgestellt werden. Der Client kann das Zertifikat überprüfen, um sicherzustellen, dass er mit dem richtigen Server verbunden ist. </li>
        <li><strong>Vertraulichkeit: </strong>SSL gewährleistet die Vertraulichkeit der übertragenen Daten, indem sie verschlüsselt werden. Dies bedeutet, dass selbst wenn die Daten abgefangen werden, sie ohne den richtigen Entschlüsselungsschlüssel nicht gelesen werden können. </li>
        <li><strong>Integrität: </strong>SSL bietet auch Integritätsschutz für die übertragenen Daten. Durch den Einsatz von Hash-Funktionen werden die Daten während der Übertragung vor Manipulation geschützt. Der Empfänger kann überprüfen, ob die Daten während der Übertragung unverändert geblieben sind. </li>
        <li><strong>HTTPS: </strong>SSL wird häufig in Verbindung mit dem Hypertext Transfer Protocol Secure (HTTPS) verwendet, das die sichere Übertragung von Daten zwischen einem Webbrowser und einem Webserver ermöglicht. Wenn eine Website HTTPS verwendet, wird dies normalerweise durch ein Schlosssymbol in der Adressleiste des Browsers angezeigt. </li>
        <li><strong>SSL-Zertifikate: </strong> Um SSL zu verwenden, benötigt der Server ein SSL-Zertifikat, das von einer Zertifizierungsstelle (Certificate Authority, CA) ausgestellt wird. Das Zertifikat enthält Informationen über den Server sowie einen öffentlichen Schlüssel, der zur Verschlüsselung der Daten verwendet wird. </li>
      </ul>
      <p>In den letzten Jahren hat SSL weiterentwickelt, und die Nachfolgeprotokolle, insbesondere TLS (Transport Layer Security), werden heutzutage häufiger verwendet. TLS ist im Wesentlichen die Weiterentwicklung von SSL und bietet verbesserte Sicherheit und Leistung. Dennoch wird der Begriff "SSL" oft noch allgemein verwendet, um auf das allgemeine Konzept der sicheren Datenübertragung über das Internet hinzuweisen.</p>
      <div class="quelle">
        <a class="btn" href="https://www.ionos.at/digitalguide/websites/webseiten-erstellen/ssl-zertifikat/" target="_blank">Quelle</a>
      </div>
    </section>
    <section class="container" id="cloud-Computing">
      <h2>6.9 Fachbegriff Cloud - Computing</h2>
      <p>Cloud-Computing meint die Bereitstellung von IT-Ressourcen über das Internet. Nutzer greifen darauf geräteunabhängig zu, aber bezahlen die Leistung verbrauchsabhängig. Typische IT-Ressourcen, die als Cloud-Computing angeboten werden, sind Server, Workstations, Speicher, Software, Datenbanken und KI-Algorithmen. Das Angebot an Cloud-Services wächst beständig. </p>
      <h3>Die 3 essenziellen Servicemodelle </h3>
      <p><strong>IaaS:</strong> Infrastructure as a Service
        <br>
        Der provider stellt eine Infrastruktur inkl. Speicher, Servern und weiteren IT-Ressourcen in der Cloud zur Verfügung, die für das Bereitstellen und Betreiben von Anwendungen vonnöten ist. </p>
      <p><strong>PaaS: </strong>Platform as a Service
        <br>
        Der Anbieter stellt Entwicklungsumgebung und Tools für die Entwicklung von Anwendungen  </p>
      <p><strong>SaaS: </strong>Software as a Service
        <br>
        Stellt Software und Anwendungen über das Internet bereit. Installation nicht nötig. </p>
      <div class="quelle">
        <a class="btn" href="https://www.ahd.de/was-ist-cloud-computing-definition-und-vorteile/ " target="_blank">Quelle</a>
      </div>
    </section>
    <section class="container" id="hybridCloud">
      <h2>6.10 Kenntnisse über Private / Public / Hybrid Cloud</h2>
      <p>Private, Public und Hybrid Cloud sind verschiedene Bereitstellungsmodelle für Cloud-Computing-Dienste, die Unternehmen je nach ihren Anforderungen und Präferenzen nutzen können. </p>
      <h2>Private Cloud:</h2>
      <ul class="left">
        <li>Eine Private Cloud ist eine Cloud-Infrastruktur, die ausschließlich für eine einzelne Organisation oder ein Unternehmen betrieben wird. </li>
        <li>Die gesamte Infrastruktur, einschließlich Hardware, Software und Netzwerke, wird entweder intern in den eigenen Rechenzentren des Unternehmens oder extern bei einem Cloud-Dienstleister betrieben, der dedizierte Ressourcen für das Unternehmen bereitstellt. </li>
        <li>Eine Private Cloud bietet eine höhere Kontrolle, Sicherheit und Anpassungsfähigkeit im Vergleich zu anderen Bereitstellungsmodellen, da sie allein von der Organisation genutzt wird. </li>
      </ul>
      <h3>Public Cloud:</h3>
      <ul class="left">
        <li>Eine Public Cloud ist eine Cloud-Infrastruktur, die von einem Cloud-Dienstleister betrieben wird und für die Öffentlichkeit zugänglich ist. </li>
        <li>Die Ressourcen, wie Rechenleistung, Speicher und Anwendungen, werden über das Internet bereitgestellt und von mehreren Kunden gemeinsam genutzt. </li>
        <li>Die öffentliche Cloud bietet den Vorteil der Skalierbarkeit, Flexibilität und Kosteneffizienz, da Kunden nur für die tatsächlich genutzten Ressourcen bezahlen und keine Investitionen in eigene Hardware tätigen müssen. </li>
      </ul>
      <h3>Hybrid Cloud:</h3>
      <ul class="li">
        <li>Eine Hybrid Cloud ist eine Kombination aus einer Private und einer Public Cloud, die miteinander verbunden sind und Daten und Anwendungen zwischen ihnen nahtlos verschieben können. </li>
        <li>Organisationen nutzen eine Hybrid Cloud, um die Vorteile beider Bereitstellungsmodelle zu nutzen: die Kontrolle und Sicherheit einer Private Cloud für sensible Daten und kritische Workloads sowie die Skalierbarkeit und Flexibilität einer Public Cloud für weniger sensitive Workloads oder Spitzenlasten. </li>
        <li>Die Integration und Verwaltung von Ressourcen in einer Hybrid Cloud erfordert spezielle Technologien und Lösungen für die Orchestrierung, Automatisierung und Datenmigration. </li>
      </ul>
      <div class="quelle">
        <a class="btn" href="https://www.cloud.fraunhofer.de/de/faq/publicprivatehybrid.html" target="_blank">Quelle</a>
      </div>
    </section>
    <section class="container" id="saas">
      <h2>6.11 Fachbegriffe IaaS, PaaS, SaaS</h2>
      <p><strong>IaaS (Infrastructure as a Service): </strong>Bei IaaS wird die gesamte Computerinfrastruktur über das Internet als Service bereitgestellt. Nutzer können Arbeitsspeicher, Speicherplatz, Netzwerkkapazitäten und virtuelle Maschinen je nach Bedarf mieten und elastisch skalieren. Dieses Modell ermöglicht es Unternehmen, große Investitionen in Hardware zu vermeiden und die Verantwortung für Wartung und Aktualisierung der Infrastruktur an den Cloud-Anbieter zu übergeben. </p>
      <p><strong>PaaS (Platform as a Service): </strong>PaaS stellt Entwicklern eine Plattform zur Verfügung, auf der sie Software entwickeln und bereitstellen können, ohne sich um den Aufbau und die Instandhaltung der zugrunde liegenden Infrastruktur wie Server, Netzwerke, Betriebssysteme oder Datenbanksysteme kümmern zu müssen. Dieser Service bietet auch Entwicklungswerkzeuge, Bibliotheken und Codeverwaltung, um den Entwicklungsprozess zu beschleunigen und zu vereinfachen. </p>
      <p><strong>SaaS (Software as a Service): </strong>SaaS ermöglicht es Benutzern, auf Anwendungssoftware und Datenbanken über das Internet zuzugreifen. Die Software wird von Drittanbietern gehostet und gewartet. Kunden können die Software in der Regel über einen Webbrowser nutzen, was die Notwendigkeit der Installation und Wartung auf Kundenseite eliminiert. SaaS-Anwendungen sind oft abonnementbasiert, und Nutzer können je nach Bedarf skalieren, indem sie mehr oder weniger Abonnements oder Nutzerlizenzen hinzufügen.</p>

      <div class="quelle">
        <a class="btn" href="https://cloud.google.com/learn/paas-vs-iaas-vs-saas?hl=de#:~:text=Cloud%2DComputing%20umfasst%20drei%20Hauptmodelle,oder%20Cloud%2DComputing%2DKategorien. " target="_blank">Quelle</a>
        <a class="btn" href="https://www.redhat.com/de/topics/cloud-computing/iaas-vs-paas-vs-saas " target="_blank">Quelle</a>
      </div>
    </section>
    <section class="container" id="cloud-Dienste">
      <h2>6.12 Beispiele für marktbekannte Cloud - Dienste</h2>
      <p>Marktbekannte Cloud-Dienste umfassen eine Vielzahl von Plattformen und Lösungen, die von führenden Technologieunternehmen angeboten werden. Zu den bekanntesten zählen:</p>
      <p><strong>Amazon Web Services (AWS):</strong> Bietet eine umfangreiche Palette an Cloud-Diensten, von Hosting und Rechenleistung bis hin zu KI und maschinellem Lernen.</p>
      <p><strong>Microsoft Azure: </strong>Eine Sammlung von Cloud-Diensten für das Bauen, Testen, Bereitstellen und Verwalten von Anwendungen über ein globales Netzwerk von Microsoft-Rechenzentren.</p>
      <p><strong>Google Cloud Platform (GCP): </strong>Bietet ähnlich wie AWS und Azure eine Reihe von Diensten, die Speicher, KI und maschinelles Lernen sowie Container-Orchestrierung umfassen.</p>
      <p><strong>IBM Cloud: </strong>Bietet Cloud-Infrastrukturdienste, KI und Datenanalyse sowie branchenspezifische Lösungen.</p>
      <p><strong>Salesforce Cloud: </strong>Bekannt für seine CRM-Lösungen, bietet Salesforce auch ein breites Spektrum an Cloud-Diensten für Unternehmensanwendungen.</p>
      <p><strong>Oracle Cloud: </strong>Liegt den Fokus auf Unternehmensanwendungen im Cloud-Bereich und bietet eine Reihe von SaaS-, PaaS- und IaaS-Produkten.</p>
      <p><strong>Adobe Creative Cloud: </strong>Umfasst eine Reihe von Anwendungen und Diensten von Adobe für Grafikdesign, Videoediting, Webentwicklung und Fotografie.</p>
      <p>Diese Dienste unterstützen Unternehmen und Einzelpersonen in verschiedenen Aspekten des digitalen Workflows, der Datenverwaltung und -speicherung sowie der Anwendungsentwicklung und -bereitstellung.</p>
      <div class="quelle">
        <a class="btn" href="https://kinsta.com/de/blog/cloud-marktanteil/" target="_blank">Quelle</a>
        <a class="btn" href="https://tridenstechnology.com/de/cloud-service-anbieter/" target="_blank">Quelle</a>
      </div>
    </section>
    <section class="container" id="Kriterien">
      <h2>6.13 Kriterien und Voraussetzungen für den Einsatz von Cloud - Diensten</h2>
      <p><strong>Skalierbarkeit: </strong>Anpassung der Ressourcen an Bedarfsschwankungen.</p>
      <p><strong>Verfügbarkeit und Sicherheit: </strong>Hohe Verfügbarkeit und Datensicherheit.</p>
      <p><strong>Datenschutz und Compliance: </strong>Erfüllung von Datenschutzstandards und gesetzlichen Anforderungen.</p>
      <p><strong>Leistung und Netzwerklatenz: </strong>Gute Leistung und niedrige Netzwerklatenzzeiten.</p>
      <p><strong>Kostenmanagement: </strong>Transparente Kostenstruktur und Budgetkontrolle.</p>
      <p><strong>Integration und Interoperabilität: </strong>Nahtlose Integration und Unterstützung von offenen Standards.</p>
      <p><strong>Support und SLAs: </strong>Zuverlässiger Kundensupport und klare Service-Level-Agreements.</p>
      <p><strong>Management und Überwachung: </strong>Effizientes Management und Überwachung von Cloud-Ressourcen.</p>
      <p><strong>Risikomanagement: </strong> Identifikation, Bewertung und Minimierung potenzieller Risiken.</p>
      <div class="quelle">
        <a class="btn" href="https://www.trojaner-info.de/business-security/sicher-in-der-cloud/articles/checkliste-zehn-kriterien-bei-der-auswahl-eines-cloud-dienstleisters.html " target="_blank">Quelle</a>
      </div>
    </section>
      <div class="center">
          <a class="btn" href="gesetzlicheBestimmungenimZusammenhangMitApplikationsentwicklung.php">Zurück zu Gesetzliche Bestimmungen im Zusammenhang mit Applikations&shyentwicklung – Coding</a>
          <a class="btn" href="itSecurityundBetriebssicherheit.php">Weiter zu IT-Security und Betriebs&shy;sicherheit</a>
      </div>
  </article>
</main>
<?php include'include/footer.php' ?>