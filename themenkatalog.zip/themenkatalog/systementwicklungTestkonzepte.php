<?php
$title = 'Systementwicklung und Testkonzepte: Eine Einführung';
$description = 'Entdecken Sie Schlüsselkonzepte der Systementwicklung und umfassende Testkonzepte, einschließlich Programmspezifikation, Datenmodellen, Datentypen und Strukturen, Funktionen, Vererbung und mehr. Erfahren Sie, wie Sie Ihre Software durch effektive Teststrategien und Automatisierung verbessern können.';
$keywords = 'Systementwicklung, Testkonzepte, Programmspezifikation, Datenmodelle, Datentypen, Softwaretests, Funktionen, Vererbung, Testautomatisierung';
$canonical = 'https://www.codeabschlussguide.de/systementwicklung-testkonzepte';

include 'include/header.php'
?>
<main class="responsive">
    <section>
        <h1>17) Systementwicklung / Testkonzepte</h1>
        <ul class="listLegend"  style="list-style: none">
            <li><a href="#programmspezifikation">17.1 Fachbegriff Programm&shy;spezifikation</a></li>
            <li><a href="#datenmodell">17.2 Fachbegriff Datenmodell</a></li>
            <li><a href="#wichtige">17.3 Kenntnisse über wichtige Datentypen und Datenstrukturen</a></li>
            <li><a href="#definition">17.4 Kenntnisse über Funktionen (Definition, Schnittstelle, Parameter, Rückgabewert, Aufruf)</a></li>
            <li><a href="#zwischen">17.5 Unterschiede zwischen Call - By - Value und Call - By - Reference</a></li>
            <li><a href="#datenelemente">17.6 Kenntnisse über Klassen (Datenelemente, Konstruktor, Destruktor, Methoden, Zugriffs&shy;modifikatoren)</a></li>
            <li><a href="#prinzip">17.7 Kenntnisse über das Prinzip der Vererbungv</a></li>
            <li><a href="#standardbibliothek">17.8 Fachbegriff Standard&shy;bibliothek</a></li>
            <li><a href="#testkonzepte">17.9 Kenntnisse über Testkonzepte</a></li>
            <li><a href="#softwaretests">17.10 Auswertung eines Softwaretests</a></li>
            <li><a href="#datenbankfeldern">17.11 Kriterien für den Test von Datenbankfeldern unterschiedlicher Typen (Mail, Datum, …)</a></li>
            <li><a href="#reproduzierbaren">17.12 Unterschiede zwischen einem reproduzierbaren / nicht - reproduzierbaren Fehler</a></li>
            <li><a href="#automatisierung">17.13 Kenntnisse über Möglichkeiten zur Automatisierung von Tests</a></li>
        </ul>
        <aside class="floatingNav">
            <div class="floatingDot" data-section="#programmspezifikation"><span class="floatingText">17.1 </span></div>
            <div class="floatingDot" data-section="#datenmodell"><span class="floatingText">17.2 </span></div>
            <div class="floatingDot" data-section="#wichtige"><span class="floatingText">17.3 </span></div>
            <div class="floatingDot" data-section="#definition"><span class="floatingText">17.4 </span></div>
            <div class="floatingDot" data-section="#zwischen"><span class="floatingText">17.5 </span></div>
            <div class="floatingDot" data-section="#datenelemente"><span class="floatingText">17.6 </span></div>
            <div class="floatingDot" data-section="#prinzip"><span class="floatingText">17.7 </span></div>
            <div class="floatingDot" data-section="#standardbibliothek"><span class="floatingText">17.8 </span></div>
            <div class="floatingDot" data-section="#testkonzepte"><span class="floatingText">17.9 </span></div>
            <div class="floatingDot" data-section="#softwaretests"><span class="floatingText">17.10 </span></div>
            <div class="floatingDot" data-section="#datenbankfeldern"><span class="floatingText">17.11 </span></div>
            <div class="floatingDot" data-section="#reproduzierbaren"><span class="floatingText">17.12 </span></div>
            <div class="floatingDot" data-section="#automatisierung"><span class="floatingText">17.13 </span></div>
        </aside>
    </section>

    <article>
        <section class="container" id="programmspezifikation">
            <h2>17.1 Fachbegriff Programmspezifikation</h2>
            <p>Die genaue Dokumentation der Anforderungen Verhalten eines Programmes. Beinhaltet Informationen wie Eingabedaten, Verarbeitungsschritte, Ausgabedaten und mögliche Fehlerbedingungen. Es ist die Grundlage für die Entwicklung und gibt ein klares Verständnis der Funktionalität.</p>
            <div class="quelle">
                <a class="btn" href="" target="_blank">Quelle</a>
            </div>
        </section>
        <section class="container" id="datenmodell">
            <h2>17.2 Fachbegriff Datenmodell</h2>
            <p>Ein Datenmodell ist eine abstrakte Darstellung der Datenstruktur, die verwendet wird, um die Beziehungen zwischen verschiedenen Datenobjekten und die Regeln für deren Speicherung, Organisation und Manipulation zu definieren. Datenmodelle dienen dazu, komplexe Datensätze in einer organisierten und strukturierten Form darzustellen, um eine effiziente Verwaltung, Abfrage und Analyse von Daten zu ermöglichen. Hier sind einige wichtige Aspekte und Fachbegriffe im Zusammenhang mit Datenmodellen: </p>
            <ul class="left">
                <li><strong></strong>Entitäten und Attribute: Entitäten repräsentieren reale oder abstrakte Objekte, wie z.B. Kunden, Produkte oder Bestellungen, während Attribute die Eigenschaften oder Merkmale dieser Entitäten beschreiben, wie z.B. Name, Alter, Preis usw. ****</li>
                <li><strong></strong>Relationale Datenmodelle: Relationale Datenmodelle sind die am weitesten verbreiteten Datenmodelle und basieren auf Tabellen, die aus Zeilen und Spalten bestehen. Entitäten werden als Tabellen dargestellt, während Attribute als Spalten repräsentiert werden. Beziehungen zwischen Entitäten werden durch Fremdschlüssel definiert. 000000</li>
                <li><strong></strong>Entity-Relationship-Modell (ERM): Das Entity-Relationship-Modell ist eine grafische Darstellung von Entitäten und deren Beziehungen in einem Datenmodell. Es umfasst Entitäten (Rechtecke), Attribute (Ovale) und Beziehungen (Diamanten). </li>
                <li><strong></strong>Objektrelationale Datenmodelle: Objektrelationale Datenmodelle erweitern das relationale Datenmodell, um Objektorientierung zu unterstützen. Sie ermöglichen die Speicherung von komplexen Datenstrukturen wie Objekten, Vererbung und Polymorphismus. </li>
                <li><strong></strong>Hierarchische Datenmodelle: Hierarchische Datenmodelle organisieren Daten in einer Baumstruktur, wobei jedes Element einen Eltern-Kind-Beziehungstyp hat. Diese Modelle werden oft in älteren Systemen und Datenbanken verwendet. </li>
                <li><strong></strong>Netzwerkdatenmodelle: Netzwerkdatenmodelle ermöglichen komplexe Beziehungen zwischen Entitäten, indem sie Netzwerkstrukturen verwenden, in denen jedes Element mit mehreren anderen Elementen verbunden sein kann. </li>
                <li><strong></strong>Semantisches Datenmodell: Semantische Datenmodelle fokussieren sich auf die Bedeutung und Beziehungen zwischen Daten und bieten eine höhere Abstraktionsebene als relationale Modelle. Sie werden oft in Wissensmanagement- und Ontologiesystemen verwendet. </li>
            </ul>
            <p>Ein angemessenes Datenmodell ist entscheidend für die Entwicklung und den Betrieb von Datenbanken und Informationssystemen, da es die Grundlage für die Organisation, Strukturierung und Abfrage von Daten bildet. Es ist wichtig, ein Datenmodell zu entwerfen, das den Anforderungen und Zielen des jeweiligen Projekts entspricht und gleichzeitig Flexibilität, Effizienz und Datenintegrität gewährleistet. </p>
            <div class="quelle">
                <a class="btn" href="https://de.wikipedia.org/wiki/Datenmodell" target="_blank">Quelle</a>
            </div>
        </section>
        <section class="container" id="wichtige">
            <h2>17.3 Kenntnisse über wichtige Datentypen und Datenstrukturen</h2>
            <h3>Datentypen:</h3>
            <ul>
                <li><strong>byte:</strong> Kleine ganze Zahl (1 Byte Wortbreite) zwischen -128 und +127</li>
                <li><strong>short:</strong> Kleine ganze Zahl (2 Byte) zwischen -32768 und +32767</li>
                <li><strong>int:</strong> Ganze Zahl mit einfacher Genauigkeit (4 Byte), z.B. 155</li>
                <li><strong>long:</strong> Ganze Zahl mit doppelter Genauigkeit (8 Byte), z.B. 1343234213645653423144</li>
                <li><strong>float:</strong> Reelle Zahl mit einfacher Genauigkeit (4 Byte), z.B. 2.71</li>
                <li><strong>double:</strong> Reelle Zahl mit doppelter Genauigkeit (8 Byte), z.B. 3.14159</li>
                <li><strong>char:</strong> Zeichen, Buchstabe, z.B. 'A' (1 Byte)</li>
                <li><strong>boolean:</strong> Wahrheitswert true oder false (1 Byte)</li>
                <li><strong>void:</strong> leerer Datentyp, wird für manipulierende Methoden benutzt, die keinen Wert zurückliefern.</li>
            </ul>
            <p>Technisch gesehen beschreibt ein primitiver Datentyp wie 'int' einen Bereich im Arbeitsspeicher des Rechners mit einer bestimmten Größe. In Java besteht eine Variable des Datentyps 'int' aus einem vier Byte großen zusammenhängenden Speicherbereich, was 32 Nullen und Einsen entspricht.</p>
            <h4>Datenstruktur:</h4>
            <p>Eine Datenstruktur fasst Datentypen zusammen und bietet Operationen an, wie z.B. Stack (Push, Pop). Sie basiert auf und benötigt Datentypen.</p>
            <div class="quelle">
                <a class="btn" href="https://u-helmich.de/inf/kursQ1/folge14/folge14-1.html " target="_blank">Quelle</a>
            </div>
        </section>
        <section class="container" id="definition">
            <h2>17.4 Kenntnisse über Funktionen (Definition, Schnittstelle, Parameter, Rückgabewert, Aufruf)</h2>
            <h3>Definition:</h3>
            <p>Eine Funktion ist eine benannte, abgeschlossene Einheit von Code in einem Programm, die eine spezifische Aufgabe ausführt. Funktionen dienen dazu, Code zu organisieren, wiederzuverwenden und zu strukturieren. </p>
            <h3>Schnittstelle: </h3>
            <p>Die Schnittstelle einer Funktion definiert, wie sie aufgerufen werden kann. Dies umfasst den Funktionsnamen, die Parameter, die sie akzeptiert, den Typ des Rückgabewerts und eventuelle Ausnahmen oder Fehler, die sie erzeugen kann. </p>
            <h3>Parameter: </h3>
            <p>Parameter sind Werte, die einer Funktion übergeben werden, wenn sie aufgerufen wird. Diese Werte dienen als Eingabe für die Funktion und ermöglichen es ihr, mit verschiedenen Daten zu arbeiten. Funktionen können null oder mehr Parameter haben. </p>
            <h3>Rückgabewert: </h3>
            <p>Der Rückgabewert ist der Wert, den eine Funktion zurückgibt, nachdem sie ihre Aufgabe erledigt hat. Nicht alle Funktionen müssen einen Rückgabewert haben. Wenn eine Funktion jedoch einen Wert zurückgibt, wird dieser oft in der aufrufenden Stelle verwendet. </p>
            <h3>Aufruf: </h3>
            <p>Eine Funktion wird aufgerufen, indem ihr Name gefolgt von Klammern geschrieben wird, die mögliche Parameter enthalten. Der Aufruf bewirkt, dass der Code innerhalb der Funktion ausgeführt wird. Nach Abschluss gibt die Funktion möglicherweise einen Rückgabewert zurück. </p>
            <div class="quelle">
                <a class="btn" href="https://www.cs.hs-rm.de/~panitz/c/skript.pdf" target="_blank">Quelle</a>
            </div>
        </section>
        <section class="container" id="zwischen">
            <h2>17.5 Unterschiede zwischen Call - By - Value und Call - By - Reference</h2>
            <p>Call-By-Value und Call-By-Reference sind zwei unterschiedliche Parameterübergabemechanismen in der Programmierung: </p>
            <p><strong>Call-By-Value: </strong>Hierbei wird eine Kopie des tatsächlichen Wertes der Argumente an die Funktion übergeben. Innerhalb der Funktion werden diese Werte in neuen Variablen gespeichert, die im lokalen Funktionskontext existieren. Änderungen an diesen Variablen haben keine Auswirkungen auf die ursprünglichen Variablen außerhalb der Funktion. Dieser Mechanismus wird häufig verwendet, um die Integrität der Originaldaten zu gewährleisten und unerwünschte Nebeneffekte zu vermeiden. </p>
            <p><strong>Call-By-Reference: </strong>Call-By-Reference: Im Gegensatz dazu wird bei Call-By-Reference die Adresse der Variablen übergeben, nicht der tatsächliche Wert. Das bedeutet, dass Änderungen an den Variablen innerhalb der Funktion sich direkt auf die Originalvariablen auswirken, da beide den gleichen Speicherort referenzieren. Call-By-Reference ist effizienter, wenn große Datenstrukturen übergeben werden müssen, da keine Kopie erstellt wird. Allerdings birgt es das Risiko von Nebeneffekten, da die Originaldaten verändert werden können. </p>
            <p>In der Praxis hängt die Wahl zwischen Call-By-Value und Call-By-Reference von der spezifischen Programmiersprache und der gewünschten Funktionalität ab. Manche Sprachen, wie Java, implementieren objektorientierte Call-By-Reference, indem sie die Referenz auf das Objekt übergeben, während primitive Typen weiterhin Call-By-Value verwenden. In C++ kann der Programmierer wählen, ob er Call-By-Value oder Call-By-Reference (mittels Zeiger oder Referenzen) verwenden möchte. </p>
            <div class="quelle">
                <a class="btn" href="https://www.geeksforgeeks.org/difference-between-call-by-value-and-call-by-reference/ " target="_blank">Quelle</a>
                <a class="btn" href="https://simpleclub.com/lessons/fachinformatikerin-call-by-value-call-by-reference " target="_blank">Quelle</a>
            </div>
        </section>
        <section class="container" id="datenelemente">
            <h2>17.6 Kenntnisse über Klassen (Datenelemente, Konstruktor, Destruktor, Methoden, Zugriffsmodifikatoren)</h2>
            <h3>Klassen in der objektorientierten Programmierung (OOP)</h3>
            <p>Klassen sind grundlegende Bausteine der OOP, die die Modellierung von Objekten und deren Verhalten ermöglichen. Hier sind einige Schlüsselelemente von Klassen:</p>
            <h4>Datenelemente (Attribute):</h4>
            <ul>
                <li>Repräsentieren die Eigenschaften oder Merkmale eines Objekts.</li>
                <li>Können verschiedene Datentypen haben, z.B. Ganzzahlen, Gleitkommazahlen, Zeichenketten usw.</li>
                <li>Sind häufig als Instanzvariablen bekannt.</li>
            </ul>
            <h4>Konstruktor:</h4>
            <ul>
                <li>Eine spezielle Methode, die bei der Instanziierung einer Klasse aufgerufen wird.</li>
                <li>Initialisiert die Datenelemente der Klasse und führt notwendige Setup-Aufgaben durch.</li>
            </ul>
            <h4>Destruktor:</h4>
            <ul>
                <li>Eine Methode, die aufgerufen wird, wenn ein Objekt außerhalb seines Gültigkeitsbereichs oder bei der expliziten Freigabe von Ressourcen zerstört wird.</li>
            </ul>
            <h4>Methoden:</h4>
            <ul>
                <li>Funktionen, die in einer Klasse definiert sind und auf die Daten der Klasse zugreifen können.</li>
                <li>Repräsentieren das Verhalten der Klasse.</li>
            </ul>
            <h4>Zugriffsmodifikatoren:</h4>
            <ul>
                <li>Keywords, welche bestimmen, von wo man Zugriff auf Objektelemente hat (private, public, protected, internal, …).</li>
            </ul>
            <p>Klassen sind die Grundlage von OOP und die Baupläne, nach denen Objekte (Instanzen von Klassen) modelliert werden.</p>
            <div class="quelle">
                <a class="btn" href="" target="_blank">Quelle</a>
            </div>
        </section>
        <section class="container" id="prinzip">
            <h2>17.7 Kenntnisse über das Prinzip der Vererbung</h2>
            <p>Vererbung in der Welt der Objektorientierung bedeutet, dass eine Klasse die Mitglieder (Attribute, Methoden, Ereignisse) einer anderen Klasse übernimmt. Ziel ist die Wiederverwendung: Wenn Klasse sich sehr ähnlich sind, dann soll man nicht alles das, was schon einmal in einer Klasse definiert wurde, erneut definieren müssen. Vererbung ermöglicht es, Attribute, Methoden und Ereignisse, die mehreren Klassen gemein sind, an einer zentralen Stelle zu definieren. </p>
            <div class="quelle">
                <a class="btn" href="https://www.it-visions.de/glossar/alle/5948/Vererbung.aspx " target="_blank">Quelle</a>
            </div>
        </section>
        <section class="container" id="standardbibliothek">
            <h2>17.8 Fachbegriff Standardbibliothek</h2>
            <p>Unter einer Standardbibliothek versteht man eine Programmbibliothek, die mit dem Compiler bzw. mit der Entwicklungsumgebung einer Programmiersprache mitgeliefert wird. </p>
            <p>Fast alle gängigen Programmiersprachen wie C, C++, C#, Java, Object Pascal und Python bieten eine umfassende Standardbibliothek. Soll also ein Compiler den Normen einer Programmiersprache entsprechen, muss er die Standardbibliotheken mitliefern. </p>
            <p>Hintergrund für das Konzept der Standardbibliothek sind die Abstraktion von Plattformdetails (z.B. Ein-/Ausgabe), das heißt Erhöhung der Portabilität, und die standardisierte Bereitstellung häufig genutzter Datenstrukturen, Algorithmen bzw. Funktionalität (z.B. Sortierung). </p>
            <p>Auch kann die Verwendung einer Standardbibliothek die eigentliche Sprachdefinition vereinfachen. Beispielsweise müssen Funktionen zur Bildschirmausgabe nicht als neue Schlüsselwörter definiert werden. Auch kann die Orthogonalität der Sprache erhöht werden, da beispielsweise Funktionen aus der Standardbibliothek normale Funktionen sind, also an allen Stellen verwendet werden dürfen, an denen normale Funktionen erlaubt sind (z.B. bei Funktionspointern). </p>
            <p>In manchen Programmiersprachen ermöglicht die Verwendung einer Standardbibliothek ihre einfache Austauschbarkeit, beispielsweise kann entweder eine auf gute Performance oder aber eine auf erleichtertes Debugging optimierte Version verwendet werden. </p>
            <div class="quelle">
                <a class="btn" href=" https://de.wikipedia.org/wiki/Standardbibliothek" target="_blank">Quelle</a>
            </div>
        </section>
        <section class="container" id="testkonzepte">
            <h2>17.9 Kenntnisse über Testkonzepte</h2>
            <h3>Übersicht des Testkonzepts</h3>
            <p>Das Testkonzept legt die Grundlage für die Durchführung von Testaktivitäten fest, indem es den Rahmen, die Vorgehensweise, die Mittel und den Zeitplan definiert. Es umfasst die Identifikation der zu testenden Elemente und Funktionen, die Testaufgaben, das verantwortliche Personal und die damit verbundenen Risiken.</p>
            <ol>
                <li><strong>Kontext erfassen:</strong> Verstehen des Produkts und der Zielsetzung des Unternehmens durch Zusammenarbeit mit dem Kunden und Anfordern relevanter Unterlagen. Dies bildet die Basis für die Testanforderungen und die Identifikation von Testobjekten. Der zeitliche Horizont, das Budget und sonstige Ressourcen sowie der Softwareentwicklungsplan und bevorzugte Kommunikationswege werden geklärt.</li>
                <li><strong>Zuständigkeiten klären:</strong> Schnelle Identifikation von Zuständigkeiten und Verantwortlichkeiten, um klare Ansprechpartner für alle relevanten Bereiche zu haben.</li>
                <li><strong>Risikoanalyse:</strong> Durchführung einer detaillierten Risikoanalyse, um mögliche Risiken zu erfassen, zu klassifizieren und die Ressourcen optimal einzusetzen.</li>
                <li><strong>Entwurf einer Teststrategie:</strong> Entwicklung einer Teststrategie zur Erreichung der Testziele unter Berücksichtigung von Zeit, Personal, Budget, Projektorganisation und Testinfrastruktur. Identifizierung und Festlegung von Testobjekten, Teststufen, Testarten und Testmethoden. Auswahl einer geeigneten ToolChain einschließlich Berichtswesen.</li>
                <li><strong>Abstimmung und Iteration:</strong> Anpassung der Teststrategie an neue Erkenntnisse während des Projektfortschritts und Kommunikation des geplanten Testumfangs sowie des geschätzten Ressourcenbedarfs an die Stakeholder.</li>
            </ol>
            <div class="quelle">
                <a class="btn" href="https://www.neofonie.de/news/testkonzepte-im-software-testing-einfach-erklaert/" target="_blank">Quelle</a>
            </div>
        </section>
        <section class="container" id="softwaretests">
            <h2>17.10 Auswertung eines Softwaretests</h2>
            <p>Wichtige Gründe für die Integration von Software-Testverfahren in die Anwendungsentwicklung sind die frühzeitige Fehleridentifizierung und -behebung, um die Produktqualität zu verbessern. Effektive Tests während des gesamten Entwicklungszyklus stärken das Vertrauen und die Zufriedenheit der Kunden, da das Produkt bereits gründlich geprüft wurde. Darüber hinaus sind Softwaretests unerlässlich für die Erkennung von Sicherheitslücken, den Schutz vor Cyberangriffen und die Skalierbarkeitsbewertung. Frühzeitige Tests sparen langfristig Geld, da Probleme später teurer zu beheben sind, und tragen dazu bei, potenzielle Probleme und Sicherheitsrisiken zu vermeiden.  </p>
            <div class="quelle">
                <a class="btn" href="https://www.computerweekly.com/de/definition/Softwaretest " target="_blank">Quelle</a>
            </div>
        </section>
        <section class="container" id="datenbankfeldern">
            <h2>17.11 Kriterien für den Test von Datenbank&shy;feldern unterschiedlicher Typen (Mail, Datum, …)</h2>
            <p>Beim Testen von Datenbankfeldern unterschiedlicher Typen, wie E-Mail-Adressen, Datumsangaben und anderen, gibt es verschiedene Kriterien, die berücksichtigt werden sollten, um sicherzustellen, dass die Daten korrekt gespeichert, validiert und verwendet werden können. Hier sind einige wichtige Kriterien für den Test von Datenbankfeldern unterschiedlicher Typen: </p>
            <ul class="left">
                <li><strong>Datentyp-Validierung: </strong>Überprüfen Sie, ob das Datenbankfeld den richtigen Datentyp verwendet. Stellen Sie sicher, dass der Datentyp den Anforderungen entspricht und korrekt implementiert ist, z. B. VARCHAR für Textfelder, DATE für Datumsfelder, INTEGER für Ganzzahlen usw. </li>
                <li><strong>Länge und Größe: </strong>Überprüfen Sie die maximale Länge oder Größe des Datenfelds gemäß den Anforderungen und Spezifikationen. Stellen Sie sicher, dass das Feld ausreichend dimensioniert ist, um alle erwarteten Daten zu speichern, ohne Datenbeschneidung oder Datenverlust zu verursachen. </li>
                <li><strong>Eindeutigkeit und Schlüsselkonflikte: </strong>Überprüfen Sie, ob Felder, die als eindeutig oder als Teil eines Primärschlüssels definiert sind, keine Duplikate enthalten und keine Schlüsselkonflikte verursachen. </li>
                <li><strong>Formatvalidierung: </strong>Überprüfen Sie, ob die Daten im richtigen Format vorliegen, z. B. ob Datumsfelder das richtige Datumsformat haben, ob E-Mail-Adressen gültig sind, ob Zahlenfelder numerisch sind usw. </li>
                <li><strong>Validierung von Bereichsgrenzen: </strong>Überprüfen Sie, ob die eingegebenen Daten innerhalb der akzeptablen Bereichsgrenzen liegen, z. B. ob Datumsangaben in einem gültigen Zeitraum liegen, ob numerische Werte innerhalb eines definierten Bereichs liegen usw. </li>
                <li><strong>Referenzielle Integrität: </strong>Überprüfen Sie, ob Felder, die auf andere Tabellen verweisen, die referenzielle Integrität aufrechterhalten und auf gültige Werte verweisen. Stellen Sie sicher, dass keine Fremdschlüsselkonflikte auftreten. </li>
                <li><strong>Verhalten bei Null-Werten: </strong>Überprüfen Sie, wie das Datenbankfeld Null-Werte behandelt. Stellen Sie sicher, dass Null-Werte ordnungsgemäß verarbeitet werden können und dass sie in den entsprechenden Situationen akzeptabel sind. </li>
                <li><strong>Performance-Tests: </strong>Führen Sie Leistungstests durch, um sicherzustellen, dass das Datenbankfeld effizient arbeitet und dass Abfragen, Einfügungen und Aktualisierungen schnell und reibungslos durchgeführt werden können. </li>
                <li><strong>Sicherheitstests: </strong>Überprüfen Sie, ob das Datenbankfeld gegen mögliche Sicherheitsbedrohungen wie SQL-Injektionen, Cross-Site-Scripting (XSS) und andere Angriffe geschützt ist. </li>
            </ul>
            <p>Durch gründliches Testen aller Datenbankfelder unterschiedlicher Typen können potenzielle Probleme identifiziert und behoben werden, um die Datenintegrität, -sicherheit und -qualität zu gewährleisten und eine reibungslose Funktionalität der Anwendung sicherzustellen. </p>
            <div class="quelle">
                <a class="btn" href="" target="_blank">Quelle</a>
            </div>
        </section>
        <section class="container" id="reproduzierbaren">
            <h2>17.12 Unterschiede zwischen einem reproduzierbaren / nicht - reproduzierbaren Fehler</h2>
            Die Reproduzierbarkeit eines Programmfehlers lässt sich anhand dessen Beobachtungsgüte in Kategorien wie A, B, C einteilen. Die Beobachtungsstufe eines Fehlers kann sich über die Nutzungszeit der Software verändern, so kann sich bspw. ein nicht reproduzierbarer Fehler zu einem eindeutig reproduzierbaren Fehler entwickeln. Bei nicht ohne weiteres reproduzierbaren Fehlern, welche aber wiederholt aufgetreten sind, können Experten zur Ursachensuche hinzugezogen werden.
            <ul class="left">
                <li>Eindeutig festgestellter Fehler, welcher mit Belegen jederzeit reproduziert werden kann. </li>
                <li>Nicht ohne weiteres reproduzierbarer Fehler, welcher aber nachweislich wiederholt aufgetreten ist. </li>
                <li>Nicht reproduzierbarer und nicht nachweislich wiederholt aufgetretener Fehler. </li>
            </ul>
            <div class="quelle">
                <a class="btn" href="https://de.wikipedia.org/wiki/Programmfehler#Reproduzierbarkeit_von_Programmfehlern " target="_blank">Quelle</a>
            </div>
        </section>
        <section class="container" id="automatisierung">
            <h2>17.13 Kenntnisse über Möglichkeiten zur Automatisierung von Tests</h2>
            <h3>Übersicht der Testarten in der Softwareentwicklung</h3>
            <h4>Unit-Tests:</h4>
            <p><strong>Beschreibung:</strong> Automatisierte Tests auf der kleinsten Einheitsebene, z. B. einer Funktion oder Methode.</p>
            <p><strong>Werkzeuge:</strong> JUnit (Java), NUnit (.NET), pytest (Python), etc.</p>
            <h4>Integrationstests:</h4>
            <p><strong>Beschreibung:</strong> Überprüft die Interaktion zwischen verschiedenen Komponenten oder Modulen.</p>
            <p><strong>Werkzeuge:</strong> TestNG, JUnit, NUnit, TestComplete, etc.</p>
            <h4>Funktionale Tests:</h4>
            <p><strong>Beschreibung:</strong> Überprüft die Softwarefunktionen, um sicherzustellen, dass sie den Anforderungen entsprechen.</p>
            <p><strong>Werkzeuge:</strong> Selenium, Appium, Cypress, Puppeteer, etc.</p>
            <h4>Last- und Performance-Tests:</h4>
            <p><strong>Beschreibung:</strong> Simuliert die Last auf eine Anwendung, um deren Leistung und Reaktionsfähigkeit zu bewerten.</p>
            <p><strong>Werkzeuge:</strong> Apache JMeter, Gatling, LoadRunner, etc.</p>
            <h4>API-Tests:</h4>
            <p><strong>Beschreibung:</strong> Überprüft die Schnittstellen zwischen Softwarekomponenten.</p>
            <p><strong>Werkzeuge:</strong> Postman, REST Assured, SoapUI, etc.</p>
            <div class="quelle">
                <a class="btn" href="https://www.techtarget.com/searchsoftwarequality/definition/automated-software-testing" target="_blank">Quelle</a>
            </div>
        </section>
        <div class="center">
            <a class="btn" href="kenntnisundVerwendungvonDatenbankenDatenmodellenUndDatenstrukturen.php">Zurück zu Kenntnis und Verwendung von Datenbanken, Datenmodellen und Datenstrukturen</a>
            <a class="btn" href="grundlagenInformationstechnologie.php">Zurück zum Start</a>
        </div>
    </article>
</main>
<?php include'include/footer.php' ?>