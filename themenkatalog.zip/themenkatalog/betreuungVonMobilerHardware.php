<?php
$title = 'Betreuung mobiler Hardware | Guide zur Applikationsentwicklung';
$description = 'Entdecken Sie essentielle Aspekte der Betreuung mobiler Hardware, einschließlich detaillierter Einblicke in technische Merkmale von Smartphones und Tablets, fundierte Kenntnisse über Android und iOS, sowie ein tiefgreifendes Verständnis für QR-Codes und die Vor- und Nachteile geschlossener Systeme. Ideal für Fachleute in der Applikationsentwicklung und IT-Support.';
$keywords = 'Mobile Hardware, Smartphones, Tablets, Android, iOS, QR-Code, App-Store, Betriebssysteme, Technische Merkmale, IT-Support, Applikationsentwicklung';
$canonical = 'https://www.codeabschlussguide.at/betreuung-mobiler-hardware';
include 'include/header.php'
?>
<main class="responsive">
  <section>
    <h1>3) Betreuung von mobiler Hardware</h1>
    <ul class="listLegend"  style="list-style: none">
      <li><a href="#smartphones">3.1 Technische Merkmale von Smartphones</a></li>
      <li><a href="#tablets">3.2 Technische Merkmale von Tablets</a></li>
      <li><a href="#android">3.3 Kenntnisse über Android</a></li>
      <li><a href="#ios">3.4 Kenntnisse über IOS</a></li>
      <li><a href="#qR-Code">3.5 Fachbegriff QR-Code</a></li>
      <li><a href="#app-Store">3.6 Vor- und Nachteile von geschlossenen Systemen mit Betriebssystem und App-Store</a></li>
    </ul>
    <aside class="floatingNav">
      <div class="floatingDot" data-section="#smartphones"><span class="floatingText">3.1 </span></div>
      <div class="floatingDot" data-section="#tablets"><span class="floatingText">3.2 </span></div>
      <div class="floatingDot" data-section="#android"><span class="floatingText">3.3 </span></div>
      <div class="floatingDot" data-section="#ios"><span class="floatingText">3.4 </span></div>
      <div class="floatingDot" data-section="#qR-Code"><span class="floatingText">3.5 </span></div>
      <div class="floatingDot" data-section="#app-Store"><span class="floatingText">3.6 </span></div>
    </aside>
  </section>

  <article>
    <section class="container" id="smartphones">
      <h2>3.1 Technische Merkmale von Smartphones</h2>
      <ul class="left" style="list-style: decimal">
        <li>Prozessor für die Leistung. </li>
        <li>Arbeitsspeicher (RAM) für Multitasking. </li>
        <li>Interner Speicher für Daten und Apps. </li>
        <li>Bildschirm mit Größe, Auflösung und Technologie </li>
        <li>Kameras für Fotos und Videos. </li>
        <li>Akku für die Laufzeit. </li>
        <li>Betriebssystem wie Android oder iOS. </li>
        <li>Konnektivitätsoptionen wie WLAN, Bluetooth und GPS. </li>
        <li>Design und Materialien. </li>
        <li>Sicherheitsfunktionen wie Fingerabdrucksensoren oder Gesichtserkennung. </li>
      </ul>
      <div class="quelle">
        <a class="btn" href="https://de.wikipedia.org/wiki/Smartphone " target="_blank">Quelle</a>
      </div>
    </section>
    <section class="container" id="tablets">
      <h2>3.2 Technische Merkmale von Tablets</h2>
      <h3>Allgemein </h3>
      <p>Ein Tablet ist ein kleiner, dünner, leichter Computer mit einem Touchscreen. Es verfügt über Kameras, Mikrofon und Lautsprecher sowie eine virtuelle oder mechanische (ergänzbare bzw. abnehmbare, selten auch fest verbaute) Tastatur. Über vorinstallierte Programme und heruntergeladene Apps werden Dienste und Funktionen zur Verfügung gestellt. </p>
      <h3>Merkmale und Funktionen </h3>
      <p>Tablets werden wie Smartphones, die geringere Abmessungen haben, zum Betrachten von Fotos und Videos, Informieren und Kommunizieren, Buchen von Hotelzimmern und Mietwagen, Einkaufen und Fotografieren sowie für das Steuern von Geräten eingesetzt. Dabei spielen auditive und visuelle Schnittstellen und spezialisierte Software eine wichtige Rolle. </p>
      <h3>Kritik und Ausblick </h3>
      <p>Als Arbeitsgeräte taugen Tablets nur bedingt, da das Schreiben wegen der Tastaturen, das Lesen wegen der Displays nicht einfach ist. Sie bewähren sich als Medien für den schnellen Konsum, für das Spielen und teils auch das Lernen. Im Haushalt ergänzen sie meist Notebook und Smartphone. Die Vielzahl der Computer ist, im Zusammenhang mit Produktion und Entsorgung, Gegenstand von Wirtschafts- und Umweltethik. </p>

      <div class="quelle">
        <a class="btn" href=" https://wirtschaftslexikon.gabler.de/definition/tablet-54082#:~:text=Ein%20Tablet%20ist%20ein%20kleiner,selten%20auch%20fest%20verbaute)%20Tastatur." target="_blank">Quelle</a>
      </div>
    </section>
    <section class="container" id="android">
      <h2>3.3 Kenntnisse über Android</h2>
      <p>Android ist ein mobiles Betriebssystem, das von Google entwickelt wurde. Es wird von mehreren Smartphones und Tablets verwendet. Beispiele dafür sind das Sony, Samsung  oder Google Smartphones. Das Android-Betriebssystem basiert auf dem Linux-Kernel. </p>
      <p>Android ist sowohl ein Betriebssystem als auch eine Softwareplattform für Geräte wie Smartphones, Tabletcomputer, Fernseher, Mediaplayer, Netbooks und Autos. Es wird von der von Google gegründeten und von ihr geleiteten Open Handset Alliance entwickelt. Android ist freie Software. </p>
      <div class="quelle">
        <a class="btn" href="https://techterms.com/definition/android" target="_blank">Quelle</a>
      </div>
    </section>
    <section class="container" id="ios">
      <h2>3.4 Kenntnisse über IOS</h2>
      <p>iOS ist ein von Apple entwickeltes mobiles Betriebssystem für das iPhone und den iPod touch. Im September 2019 wurde die Variante für das iPad als eigenständiges iPadOS wieder von iOS getrennt. </p>
      <p>Auf iOS basieren ebenfalls ab Version 4 die Apple-TV-Software, die auf der zweiten und dritten Generation des Apple TV läuft und mit der vierten Generation des Apple TV in tvOS umbenannt wurde, sowie watchOS für die Apple Watch. </p>
      <p>Im Gegensatz zu Apples Konkurrenten, die ihr eigenes mobiles Betriebssystem oft auch an andere Gerätehersteller lizenzieren, wird iOS nur auf eigenen Geräten von Apple eingesetzt. iOS ist ein macOS-Derivat und basiert auf Darwin, das wiederum auf das ab 1986 entwickelte NeXTStep zurückgeht, ein BSD-Unix mit Mach-Kernel und damals neuartiger grafischer Oberfläche. </p>


      <div class="quelle">
        <a class="btn" href="https://de.wikipedia.org/wiki/IOS_(Betriebssystem) " target="_blank">Quelle</a>
        <a class="btn" href="https://de.wikipedia.org/wiki/Apple" target="_blank">Quelle</a>
      </div>
    </section>
    <section class="container" id="qR-Code">
      <h2>3.5 Fachbegriff QR-Code</h2>
      <p>Ein QR-Code (kurz für „Quick Response Code“) ist eine Art von Barcode, der Informationen speichert, welche digital gelesen werden können. Er besteht aus einer Anordnung von schwarzen Quadraten auf einem weißen Hintergrund. QR-Codes werden oft verwendet, um URLs oder andere Informationen schnell mit einem Smartphone zu teilen. Man scannt den QR-Code einfach mit der Kamera des Smartphones oder einer speziellen App, um auf die gespeicherten Informationen zuzugreifen, wie beispielsweise eine Webseite zu öffnen, Kontaktdaten zu speichern oder eine WLAN-Verbindung herzustellen. </p>
      <div class="quelle">
        <a class="btn" href="https://de.wikipedia.org/wiki/QR-Code " target="_blank">Quelle</a>
      </div>
    </section>
    <section class="container" id="app-Store">
      <h2>3.6 Vor- und Nachteile von geschlossenen Systemen mit Betriebssystem und App-Store</h2>
      <h3>Vorteile: </h3>
      <p><strong>Sicherheit: </strong>Geschlossene Betriebssysteme sind oft sicherer, da der Quellcode nicht öffentlich zugänglich ist. Dies kann potenzielle Sicherheitslücken verringern, da nur autorisierte Entwickler Zugriff auf den Code haben und ihn überwachen können. </p>
      <p><strong>Konsistenz: </strong>Durch die Kontrolle über Hardware und Software können geschlossene Systeme eine konsistente Benutzererfahrung bieten. Diese Konsistenz kann dazu beitragen, dass Benutzer weniger Schwierigkeiten haben und die Systeme einfacher zu unterstützen sind. </p>
      <p><strong>Optimierung: </strong>Entwickler geschlossener Systeme können die Hardware und Software optimal aufeinander abstimmen, um eine bessere Leistung und Effizienz zu erzielen. </p>
      <p><strong>Kundensupport: </strong>Geschlossene Systeme ermöglichen es dem Hersteller, einen umfassenden Kundensupport anzubieten, da sie die Kontrolle über die gesamte Software und Hardware haben und daher besser in der Lage sind, Probleme zu diagnostizieren und Lösungen bereitzustellen. </p>
      <h3>Nachteile: </h3>
      <p><strong>Eingeschränkte Flexibilität: </strong>Geschlossene Systeme bieten oft weniger Flexibilität für Benutzer, da sie weniger Anpassungsmöglichkeiten und Kontrolle über ihre Geräte und Software haben. </p>
      <p><strong>Abhängigkeit vom Hersteller: </strong>Benutzer geschlossener Systeme sind oft stark von den Entscheidungen und dem Support des Herstellers abhängig. Wenn der Hersteller beschließt, ein bestimmtes Produkt nicht mehr zu unterstützen, können Benutzer Schwierigkeiten haben, ihre Systeme weiterhin effektiv zu nutzen. </p>
      <p><strong>Höhere Kosten: </strong>Geschlossene Systeme neigen dazu, höhere Kosten zu verursachen, da sie oft proprietäre Hardware und Software erfordern, die teurer sein können als alternative Lösungen.
      </p>
      <p><strong>Innovationsbeschränkungen: </strong>Die Geschlossenheit eines Systems kann die Innovation einschränken, da externe Entwickler möglicherweise keinen Zugriff auf die Plattform haben, um neue Ideen und Funktionen zu entwickeln. Insgesamt hängt die Wahl zwischen einem offenen und einem geschlossenen Betriebssystem von den spezifischen Anforderungen und Präferenzen eines Benutzers oder Unternehmens ab </p>

      <div class="quelle">
        <a class="btn" href="https://kinsta.com/de/wissensdatenbank/open-source-vs-closed-source/ " target="_blank">Quelle</a>
      </div>
    </section>
      <div class="center">
          <a class="btn" href="betriebssystemeUndSoftware.php">Zurück zu Betriebssysteme und Software</a>
          <a class="btn" href="technischeDokumentationenProjektarbeitSchulungen.php">Weiter zu Technische Dokumentationen / Projektarbeit / Schulungen</a>
      </div>
  </article>
</main>
<?php include'include/footer.php' ?>
