<?php
$title = 'Qualitätssicherung in der Softwareentwicklung: Methoden und Best Practices';
$description = 'Erfahren Sie mehr über Qualitätssicherungsmaßnahmen in der Softwareentwicklung, einschließlich Code-Reviews, Schreibtischtests, Black-Box- und White-Box-Tests sowie wichtige Qualitätsmerkmale der Softwarefunktionalität. Verstehen Sie die Bedeutung von Changemanagement, Versionierung und Problemmanagement für die Aufrechterhaltung und Verbesserung der Softwarequalität.';
$keywords = 'Qualitätssicherung, Softwareentwicklung, Code-Reviews, Schreibtischtest, Black-Box-Test, White-Box-Test, Softwarefunktionalität, Changemanagement, Versionierung, Problemmanagement';
$canonical = 'https://www.codeabschlussguide.de/qualitaetssicherung';
include 'include/header.php'
?>
<main class="responsive">
    <section>
        <h1>14) Qualitätssicherung</h1>
        <ul class="listLegend"  style="list-style: none">
            <li><a href="#code-Reviews">14.1 Kenntnisse über den Zweck von Code-Reviews</a></li>
            <li><a href="#schreibtischtest">14.2 Fachbegriff Schreibtischtest</a></li>
            <li><a href="#wesentliche">14.3 Kenntnisse über Black - Box - Test / White - Box - Test, wesentliche Unterschiede</a></li>
            <li><a href="#softwarefunktionalität">14.4 Kenntnisse über wichtige Qualitäts&shy;merkmale der Software&shy;funktionalität</a></li>
            <li><a href="#changemanagement">14.5 Kenntnisse über Changemanagement</a></li>
            <li><a href="#nutzern">14.6 Fachbegriff Versionierung und deren Nutzen</a></li>
            <li><a href="#problemmanagement">14.7 Kenntnisse über Problemmanagement</a></li>
        </ul>
        <aside class="floatingNav">
            <div class="floatingDot" data-section="#code-Reviews"><span class="floatingText">14.1 </span></div>
            <div class="floatingDot" data-section="#schreibtischtest"><span class="floatingText">14.2 </span></div>
            <div class="floatingDot" data-section="#wesentliche"><span class="floatingText">14.3 </span></div>
            <div class="floatingDot" data-section="#softwarefunktionalität"><span class="floatingText">14.4 </span></div>
            <div class="floatingDot" data-section="#changemanagement"><span class="floatingText">14.5 </span></div>
            <div class="floatingDot" data-section="#nutzern"><span class="floatingText">14.6 </span></div>
            <div class="floatingDot" data-section="#problemmanagement"><span class="floatingText">14.7 </span></div>
        </aside>
    </section>

    <article>
        <section class="container" id="code-Reviews">
            <h2>14.1 Kenntnisse über den Zweck von Code-Reviews</h2>
            <h3>Code Review: Qualitätssicherung in der Softwareentwicklung</h3>
            <p>Ein Code Review – auch als Codeüberprüfung bezeichnet – ist eine systematische Untersuchung von Quellcode und damit eine Maßnahme zur Qualitätssicherung der Softwareentwicklung.</p>
            <h4>Ansätze für ein Code Review:</h4>
            <ul class="left">
                <li><strong>Pair Programming:</strong> Zwei Entwickler arbeiten gemeinsam an demselben Code und überprüfen damit kontinuierlich die Arbeit des jeweils anderen. Nachteile können die möglicherweise fehlende Objektivität der Entwicklungspartner sein.</li>
                <li><strong>Über die Schulter gucken / Walkthrough:</strong> Ein Entwickler sucht sich nach der Fertigstellung seines Codes einen Kollegen, der die Implementierung überprüft. Dieser Ansatz ist informell und ermöglicht eine direkte Umsetzung der Erkenntnisse im Code.</li>
                <li><strong>Softwarebasierte Code Reviews:</strong> Sie erfolgen browserbasiert oder direkt in einer Entwicklungsumgebung und folgen einem formalen Ansatz, der Kommentare und Lösungsvorschläge dokumentiert für eine spätere Nachvollziehbarkeit.</li>
            </ul>
            <h4>Wichtige Aspekte eines Code Reviews:</h4>
            <p>Welche Inhalte in einem Code Review untersucht und verbessert werden, hängt vom jeweiligen Team ab. Es kann von der Überprüfung jeder Änderung bis hin zu definierten Schwellen reichen, unter denen eine Überprüfung nicht erforderlich ist. Neben der Funktionssicherheit und Fehlerfreiheit ist auch ein Abgleich mit der Spezifikation notwendig.</p>
            <p>Unabhängig von der Erfahrung und Reputation der Entwickler sind Codeüberprüfungen sinnvoll, da auch Codezeilen von erfahrenen Entwicklern optimiert und von Code-Smells befreit werden können. Ein Code Review bietet zudem eine gute Gelegenheit für Mentoring und die Verbesserung der Zusammenarbeit unter Kollegen.</p>
            <div class="quelle">
                <a class="btn" href="https://t2informatik.de/wissen-kompakt/code-review/#:~:text=Code%20Review%20%E2%80%93%20die%20Sicherstellung%20der%20Softwarequalit%C3%A4t&text=Ein%20Code%20Review%20%E2%80%93%20auch%20als,Ma%C3%9Fnahme%20zur%20Qualit%C3%A4tssicherung%20der%20Softwareentwicklung. " target="_blank">Quelle</a>
            </div>
        </section>
        <section class="container" id="schreibtischtest">
            <h2>14.2 Fachbegriff Schreibtischtest </h2>
            <p>Ein Schreibtischtest ist das Testen von Algorithmen in einer Simulierten Umgebung, oft in der Konzept- oder Prototypphase, um potenzielle Probleme zu identifizieren und zu beheben. In der Programmierung werden dabei oft die Funktionen mit Mock-Daten getestet. Es wird der Programmablauf geplant und mögliche Eingabe- und Rückgabewerte getestet, um einen effizienten Projektablauf zu garantieren. Die Ausgabeelemente müssen vor dem Test geplant sein, um die Richtigkeit des Algorithmus zu bestätigen.
            </p>
            <div class="quelle">
                <a class="btn" href="https://de.wikipedia.org/wiki/Schreibtischtest#:~:text=Der%20Schreibtischtest%20ist%20ein%20Verfahren,vielmehr%20im%20Kopf%20des%20Entwicklers. " target="_blank">Quelle</a>
            </div>
        </section>
        <section class="container" id="wesentliche">
            <h2>14.3 Kenntnisse über Black - Box - Test / White - Box - Test, wesentliche Unterschiede</h2>
            <p>Black-Box-Test und White-Box-Test sind zwei verschiedene Ansätze für das Testen von Software, die auf unterschiedlichen Strategien basieren: </p>
            <h3></h3>
            <ul class="left">
                <li>Bei einem Black-Box-Test wird die interne Funktionsweise der Software nicht betrachtet. Der Tester betrachtet die Software als eine "Black Box", bei der er nur die Eingaben und Ausgaben untersucht, ohne sich darum zu kümmern, wie die Software intern funktioniert. </li>
                <li>Der Fokus liegt auf der Überprüfung der funktionalen Anforderungen und Benutzererwartungen, um sicherzustellen, dass die Software wie erwartet funktioniert. </li>
                <li>Der Tester benötigt keine Kenntnisse über die interne Implementierung der Software, sondern konzentriert sich darauf, ob die Software die gewünschten Ergebnisse liefert. </li>
            </ul>
            <h3>White-Box-Test: </h3>
            <ul class="left">
                <li>Im Gegensatz dazu untersucht ein White-Box-Test die interne Struktur, Logik und den Code der Software. Der Tester hat Kenntnisse über die interne Implementierung und verwendet diese Kenntnisse, um die Tests zu entwerfen. </li>
                <li>Der Fokus liegt auf der Überprüfung der internen Logik und der Codeabdeckung, um sicherzustellen, dass alle Anweisungen korrekt ausgeführt werden und alle Pfade im Code durchlaufen werden. </li>
                <li>Der Tester benötigt Kenntnisse über die Programmiersprache, die Softwarearchitektur und den Code der zu testende Software, um effektive White-Box-Tests durchführen zu können. </li>
            </ul>
            <h3>Wesentliche Unterschiede: </h3>
            <ul class="left">
                <li>Black-Box-Tests basieren auf externen Anforderungen und Funktionen der Software, während White-Box-Tests auf internen Strukturen und Implementierungen basieren. </li>
                <li>Black-Box-Tests sind unabhängig von der internen Implementierung der Software, während White-Box-Tests diese internen Details genau betrachten. </li>
                <li>Black-Box-Tests sind besser geeignet, um die Benutzererfahrung und Funktionalität der Software zu überprüfen, während White-Box-Tests besser geeignet sind, um die interne Logik und Codequalität zu überprüfen. </li>
                <li>Black-Box-Tests sind weniger anfällig für Änderungen in der internen Implementierung, während White-Box-Tests anfälliger für Änderungen sind, da sie eng mit der internen Struktur verbunden sind. </li>
            </ul>
            <p>Insgesamt ergänzen sich Black-Box- und White-Box-Tests und werden oft zusammen verwendet, um eine umfassende Testabdeckung zu erreichen.
            </p>
            <div class="quelle">
                <a class="btn" href="https://de.wikipedia.org/wiki/Black-Box-Test" target="_blank">Quelle</a>
            </div>
        </section>
        <section class="container" id="softwarefunktionalität">
            <h2>14.4 Kenntnisse über wichtige Qualitätsmerkmale der Software&shy;funktionalität</h2>
            <h3>Interoperabilität, Angemessenheit, Richtigkeit, Ordnungsmäßigkeit, Sicherheit </h3>
            <p>Der Begriff Interoperabilität beschreibt die Interaktion zwischen verschiedenen Techniken und Systemen </p>
            <p>Die Merkmale Angemessenheit und Richtigkeit definieren, dass die Software den Zweck erfüllt, für den sie laut Konzept entwickelt wurde. Im Vordergrund steht weniger der allgemeine Funktionsumfang als die Frage, ob alle wichtigen Funktionen zur Zweckerfüllung enthalten sind und diese fehlerfrei anwendbar sind.</p>
            <p>Wichtig ist die Erfüllung dieser Qualitätsmerkmale im Bereich Individualsoftware, damit sichergestellt ist, dass die Stakeholder den in ihren Anforderungen definierten Nutzen aus der Software ziehen können. Im Bereich Standardsoftware wird durch Angemessenheit und Richtigkeit garantiert, dass der Gebrauch der Software für die Anwender einen praktikablen Nutzen hat </p>
            <p>Wirtschaftlich wichtig ist auch die Sicherheit. Können Unbefugte durch Sicherheitslücken in der Softwarezugang zu sensiblen Daten in Datenbanken erhalten, kann das zu finanziellen Schäden führen </p>
            <div class="quelle">
                <a class="btn" href="https://www.tenmedia.de/de/glossar/softwarequalitat " target="_blank">Quelle</a>
            </div>
        </section>
        <section class="container" id="changemanagement">
            <h2>14.5 Kenntnisse über Change&shy;management</h2>
            <h3>Changemanagement: Steuerung organisatorischer Veränderungen</h3>
            <p>Changemanagement bezieht sich auf den Prozess der Planung, Implementierung und Kontrolle von Veränderungen in einer Organisation, um sicherzustellen, dass sie effektiv verwaltet werden und die gewünschten Ergebnisse erzielt werden.</p>
            <h4>Wichtige Kenntnisse über Changemanagement:</h4>
            <ul class="left">
                <li><strong>Zielsetzung:</strong> Das Hauptziel des Changemanagements ist es, Veränderungen in einer Organisation zu steuern und sicherzustellen, dass sie reibungslos und effektiv umgesetzt werden, um die gewünschten Ergebnisse zu erzielen.</li>
                <li><strong>Planung von Veränderungen:</strong> Changemanagement beinhaltet die Planung von Veränderungen, einschließlich der Identifizierung von Veränderungsbedarf, der Festlegung von Zielen und Prioritäten sowie der Entwicklung von Strategien und Plänen zur Umsetzung der Veränderungen.</li>
                <li><strong>Kommunikation und Stakeholder-Management:</strong> Ein wesentlicher Bestandteil des Changemanagements ist die Kommunikation mit den betroffenen Stakeholdern, um sie über die geplanten Veränderungen zu informieren, ihr Engagement zu fördern und Bedenken oder Widerstände zu adressieren.</li>
                <li><strong>Risikomanagement:</strong> Changemanagement beinhaltet auch die Identifizierung und Bewertung von Risiken im Zusammenhang mit den geplanten Veränderungen sowie die Entwicklung von Strategien zur Risikominimierung und -bewältigung.</li>
                <li><strong>Implementierung von Veränderungen:</strong> Nachdem die Veränderungen geplant wurden, erfolgt die Implementierung gemäß dem festgelegten Plan. Dies kann schrittweise oder auf einmal erfolgen, abhängig von der Art der Veränderungen und den Bedürfnissen der Organisation.</li>
                <li><strong>Überwachung und Bewertung:</strong> Nach der Implementierung werden die Veränderungen überwacht und bewertet, um sicherzustellen, dass sie die gewünschten Ergebnisse erzielen. Anpassungen können vorgenommen werden, falls erforderlich, um sicherzustellen, dass die Veränderungen erfolgreich sind.</li>
                <li><strong>Kontinuierliche Verbesserung:</strong> Ein wichtiger Aspekt des Changemanagements ist die Förderung einer Kultur der kontinuierlichen Verbesserung, bei der Organisationen offen für Veränderungen sind und sich kontinuierlich anpassen, um mit sich ändernden Anforderungen und Umgebungen Schritt zu halten.</li>
            </ul>
            <p>Changemanagement ist ein wichtiger Bestandteil des organisatorischen Wandels und kann dazu beitragen, dass Veränderungen effektiv und reibungslos umgesetzt werden, um die Leistung und Wettbewerbsfähigkeit einer Organisation zu verbessern.</p>
            <div class="quelle">
                <a class="btn" href="https://www.lernen.net/artikel/change-management-22975/ " target="_blank">Quelle</a>
            </div>
        </section>
        <section class="container" id="nutzern">
            <h2>14.6 Fachbegriff Versionierung und deren Nutzen</h2>
            <p>Versionierung bezieht sich auf die Praxis, verschiedene Versionen oder Ausgaben eines Produkts oder Dokuments zu erstellen und zu verwalten. Im Kontext der Softwareentwicklung bedeutet dies die Verwaltung von Änderungen am Quellcode oder an Dokumentation über die Zeit hinweg. Dies ermöglicht es Entwicklern, Änderungen nachzuverfolgen, zu verschiedenen Zuständen des Codes zurückzukehren und parallele Entwicklungsstränge zu führen. Der Nutzen der Versionierung umfasst: </p>
            <ul class="left">
                <li><strong>Nachverfolgbarkeit: </strong>Änderungen am Code können genau zugeordnet werden. </li>
                <li><strong>Kollaboration: </strong>Mehrere Entwickler können gleichzeitig an einem Projekt arbeiten, ohne sich gegenseitig zu behindern. </li>
                <li><strong>Fehlerbehebung: </strong>Einfaches Zurücksetzen auf funktionierende Versionen, falls neue Änderungen Probleme verursachen. </li>
                <li><strong>Releasemanagement: </strong>Versionierung hilft dabei, Stabilität und Kontinuität bei der Veröffentlichung neuer Softwareversionen zu gewährleisten.</li>
            </ul>

            <div class="quelle">
                <a class="btn" href="https://de.wikipedia.org/wiki/Versionsverwaltung " target="_blank">Quelle</a>
                <a class="btn" href="https://www.computerweekly.com/de/definition/Versionierung-Versionsverwaltung " target="_blank">Quelle</a>
            </div>
        </section>
        <section class="container" id="problemmanagement">
            <h2>14.7 Kenntnisse über Problemmanagement</h2>
            <p>Über das Problem-Management werden unbekannte Ursachen für potenzielle Störungen (Incidents) innerhalb der ITServices untersucht und die Behebung gesteuert. Problem-Management analysiert mögliche oder bereits eingetretene Störungen und identifiziert daraus Probleme, die genauer untersucht werden sollen. </p>
            <div class="quelle">
                <a class="btn" href="https://de.wikipedia.org/wiki/Problem-Management " target="_blank">Quelle</a>
            </div>
        </section>
        <div class="center">
            <a class="btn" href="ProjektmethodenTools.php">Zurück zu Projektmethoden, Tools</a>
            <a class="btn" href="grundkenntnisseDesProgrammierens.php">Weiter zu Grundkenntnisse des Programmierens</a>
        </div>
    </article>
</main>
<?php include'include/footer.php' ?>