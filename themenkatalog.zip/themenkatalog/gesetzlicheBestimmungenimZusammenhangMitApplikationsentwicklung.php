<?php
$title = 'Gesetzliche Bestimmungen in der Applikationsentwicklung – Coding';
$description = 'Erfahren Sie alles über die wichtigen gesetzlichen Bestimmungen im Bereich der Applikationsentwicklung und Coding, einschließlich der Datenschutzgrundverordnung (DSGVO), Datenminimierung, Rechten betroffener Personen, dem Umgang mit personenbezogenen und sensiblen Daten, dem Kopplungsverbot, der Rolle des Datenschutzbeauftragten, Pflichten bei Datendiebstahl, Urheberrecht, Gewährleistungs- und Garantiebestimmungen, Entsorgung von Elektronikschrott, dem E-Commerce-Gesetz (ECG), Telekom-Gesetz (TKG), Pflichtangaben eines Homepage-Betreibers und vielem mehr. Bleiben Sie informiert und stellen Sie sicher, dass Ihre Entwicklungen den rechtlichen Anforderungen entsprechen.';
$keywords = 'DSGVO, Datenschutz, Applikationsentwicklung, Coding, Urheberrecht, E-Commerce-Gesetz, Telekom-Gesetz, Datenschutzbeauftragter, Datenminimierung, gesetzliche Bestimmungen, Elektronikschrott, Gewährleistung, Garantiebestimmungen, Impressumspflicht, E-Mail-Verkehr, Bildschirmpausen';
$canonical = 'https://www.codeabschlussguide.at/gesetzliche-bestimmungen-coding';
include 'include/header.php'
?>
<main class="responsive">
  <section>
    <h1>5) Gesetzliche Bestimmungen im Zusammenhang mit
      Applikations&shy;entwicklung – Coding</h1>
    <ul class="listLegend"  style="list-style: none">
      <li><a href="#DSGVO">5.1 Kenntnis über DSGVO (Datenschutzg&shy;rundverordnung)</a></li>
      <li><a href="#datenminimierung">5.2 Fachbetriff "Datenminimierung" im Zusammenhang der DSGVO</a></li>
      <li><a href="#betroffenePersonen">5.3 Fachbegriffe "betroffene Personen", Verantwortlicher, Auftragsverarbeiter</a></li>
      <li><a href="#rechte">5.4 Kenntnis über Rechte von "betroffene Personen" lt. DSGVO</a></li>
      <li><a href="#personenbezogeneUndSensibleDaten">5.5 Fachbegriff "personenbezogene und sensible Daten" lt. DSGVO</a></li>
      <li><a href="#kopplungsverbot">5.6 Bedeutung von Kopplungsverbot beim DSGVO</a></li>
      <li><a href="#datenschutzbeauftragter">5.7 Datenschutz&shy;beauftragter lt. DSGVO und dessen Funktion</a></li>
      <li><a href="#datendiebstahl">5.8 Pflichten für Unternehmen bei bekannt gewordenen Datendiebstahl lt. DSGVO</a></li>
      <li><a href="#gültigkeitsbereich">5.9 Kenntnisse über Grundbegriffe und Gültigkeits&shy;bereich des Urheberrechtes</a></li>
      <li><a href="#garantiebestimmungen">5.10 Kenntnis gesetzlicher Gewähr&shy;leistungs- und Garantie&shy;bestimmungen und deren
        unterschied&shy;licher Anwendung bei Hardware- und Softwareproblemen</a></li>
      <li><a href="#elektronikschrott">5.11 Kenntnisse über umweltgerechte Entsorgung von Elektronikschrott, Toner, Akkus oder Batterien</a></li>
      <li><a href="#eCommerceGesetz">5.12 Kenntnisse über das E-Commerce-Gesetz (ECG)</a></li>
      <li><a href="#telekomGesetz">5.13 Kenntnisse über das Telekom-Gesetz (TKG)</a></li>
      <li><a href="#pflichtangaben">5.14 Kenntnisse über Pflichtangaben eines Homepage - Betreibers (Impressum)</a></li>
      <li><a href="#eMailVerkehr">5.15 Kenntnisse über Pflichtangaben beim E-Mail-Verkehr von Unternehmen</a></li>
      <li><a href="#bildschirmpausen">5.16 Kenntnisse über die gesetzliche Einhaltung von Bildschirmpausen</a></li>
    </ul>
    <aside class="floatingNav">
      <div class="floatingDot" data-section="#DSGVO"><span class="floatingText">5.1 </span></div>
      <div class="floatingDot" data-section="#datenminimierung"><span class="floatingText">5.2 </span></div>
      <div class="floatingDot" data-section="#betroffenePersonen"><span class="floatingText">5.3 </span></div>
      <div class="floatingDot" data-section="#rechte"><span class="floatingText">5.4 </span></div>
      <div class="floatingDot" data-section="#personenbezogeneUndSensibleDaten"><span class="floatingText">5.5 </span></div>
      <div class="floatingDot" data-section="#kopplungsverbot"><span class="floatingText">5.6 </span></div>
      <div class="floatingDot" data-section="#datenschutzbeauftragter"><span class="floatingText">5.7 </span></div>
      <div class="floatingDot" data-section="#datendiebstahl"><span class="floatingText">5.8 </span></div>
      <div class="floatingDot" data-section="#gültigkeitsbereich"><span class="floatingText">5.9 </span></div>
      <div class="floatingDot" data-section="#garantiebestimmungen"><span class="floatingText">5.10 </span></div>
      <div class="floatingDot" data-section="#elektronikschrott"><span class="floatingText">5.11 </span></div>
      <div class="floatingDot" data-section="#eCommerceGesetz"><span class="floatingText">5.12 </span></div>
      <div class="floatingDot" data-section="#telekomGesetz"><span class="floatingText">5.13</span></div>
      <div class="floatingDot" data-section="#pflichtangaben"><span class="floatingText">5.14 </span></div>
      <div class="floatingDot" data-section="#eMailVerkehr"><span class="floatingText">5.15</span></div>
      <div class="floatingDot" data-section="#bildschirmpausen"><span class="floatingText">5.16 </span></div>
    </aside>
  </section>

  <article>
    <section class="container" id="DSGVO">
      <h2>5.1 Kenntnis über DSGVO (Datenschutz&shy;grundverordnung)</h2>
      <p>Die DSGVO enthält Bestimmungen zur Verarbeitung personenbezogener Daten durch private Unternehmen und öffentliche Stellen. Daneben enthält sie 173 Erwägungsgründe, welche die jeweiligen Artikel näher erläutern und bei der Auslegung helfen sollen. Die DSGVO dient der Vereinheitlichung des Datenschutzrechts. </p>
      <p>Nach Art.Abs.DSGVO schützt die DSGVO die Grundrechte und Grundfreiheiten natürlicher Personen und insbesondere deren Recht auf Schutz personenbezogener Daten. Dieser Schutz gilt jedoch nicht universell, denn der Anwendungsbereich der DSGVO ist sowohl sachlich als auch räumlich beschränkt. Die sachliche Beschränkung legt fest, bei welchen Tätigkeiten die DSGVO nicht zur Anwendung kommt. Der räumliche Anwendungsbereich bestimmt hingegen, in welchen geografischen Konstellationen die DSGVO zur Anwendung kommen kann. </p>
      <p>Die Ausnahmen vom Anwendungsbereich der DSGVO sind in der DSGVO abschließend aufgezählt. Eine Ausnahme gibt es für die Datenverarbeitung durch Privatpersonen ausschließlich für „persönliche oder familiäre Tätigkeiten“. Alle österreichischen Unternehmen jeder Branche sind von der DSGVO betroffen, auch ARGE, Vereine, Ärzte, KMU, EPU, Schulen etc.
      </p>

      <div class="quelle">
        <a class="btn" href="https://www.intersoft-consulting.de/infos/datenschutz-grundverordnung-dsgvo/#:~:text=Die%20DSGVO%20enth%C3%A4lt%20Bestimmungen%20zur,dient%20der%20Vereinheitlichung%20des%20Datenschutzrechts. " target="_blank">Quelle</a>
        <a class="btn" href="https://www.wko.at/unternehmensfuehrung-finanzierung-foerderungen/datenschutz-grundverordnung-fragen-und-antworten#heading_1__Bin_ich_von_der_DSGVO_betroffen_" target="_blank">Quelle</a>
      </div>
    </section>

    <section class="container" id="datenminimierung">
      <h2>5.2 Fachbetriff "Datenminimierung" im Zusammenhang der DSGVO</h2>
      <p>Der Artikel spricht davon, dass personenbezogene Daten sparsam erhoben werden müssen.
        Sie dürfen nur verarbeitet werden, wenn sie: </p>
      <ul class="left">
        <li>für den Zweck angemessen sind und </li>
        <li>für den Zweck erheblich und relevant sind. </li>
      </ul>
      <p>Für die ausgewählten Datenkategorien gilt:  </p>
      <ul class="left">
        <li>Die personenbezogenen Daten sind so erhoben und verarbeitet, dass sie für den angegebenen Zweck passen, aber nicht darüber hinaus.  </li>
        <li>Der Verantwortliche muss sich bei der Erhebung personenbezogener Daten auf die Informationen beschränken, die für den Zweck notwendig sind. </li>
      </ul>
      <p>Personenbezogene Daten müssen dem Zweck angemessen und erheblich sowie auf das für die Zwecke der Verarbeitung notwendige Maß beschränkt sein („Datenminimierung“). Siehe: Art.5/1c DSGVO </p>
      <div class="quelle">
        <a class="btn" href="https://eu-datenschutz-grundverordnung.net/grundsatz-der-datenminimierung/ " target="_blank">Quelle</a>
      </div>

    </section>
    <section class="container" id="betroffenePersonen">
      <h2>5.3 Fachbegriffe "betroffene Personen", Verant&shy;wortlicher, Auftrags&shy;verarbeiter </h2>
      <h3>Betroffene Personen (User):  </h3>
      <p>Definition: Betroffene Personen sind natürliche Personen, deren personenbezogene Daten von einer Organisation verarbeitet werden. Das können beispielsweise Kunden, Mitarbeiter oder Website-Besucher sein.</p>
      <p>Rechte: Die DSGVO räumt betroffenen Personen verschiedene Rechte ein, darunter das Recht auf Auskunft, Berichtigung, Löschung und Widerspruch gegen die Verarbeitung ihrer personenbezogenen Daten. </p>
      <h3>Verantwortlicher (Websiteinhaber): </h3>
      <p>Definition: Der Verantwortliche ist die natürliche oder juristische Person, Behörde, Einrichtung oder andere Stelle, die allein oder gemeinsam mit anderen über die Zwecke und Mittel der Verarbeitung von personenbezogenen Daten entscheidet. Der Verantwortliche trägt die Verantwortung für die Einhaltung der Datenschutzvorschriften. </p>
      <p>Aufgaben: Der Verantwortliche muss sicherstellen, dass die Verarbeitung im Einklang mit der DSGVO erfolgt, und er hat die Pflicht, den betroffenen Personen ihre Rechte zu gewährleisten. </p>
      <h3>Auftragsverarbeiter (Mitarbeiter): </h3>
      <p>Definition: Ein Auftragsverarbeiter ist eine natürliche oder juristische Person, Behörde, Einrichtung oder andere Stelle, die personenbezogene Daten im Auftrag des Verantwortlichen verarbeitet. Der Auftragsverarbeiter handelt dabei ausschließlich nach den Anweisungen des Verantwortlichen. </p>
      <p>Vertragliche Regelungen: Zwischen dem Verantwortlichen und dem Auftragsverarbeiter muss ein Vertrag abgeschlossen werden, der bestimmte datenschutzrechtliche Anforderungen gemäß Artikel 28 DSGVO regelt. Dieser Vertrag regelt insbesondere den Umgang mit den personenbezogenen Daten und stellt sicher, dass der Auftragsverarbeiter angemessene technische und organisatorische Maßnahmen zum Schutz der Daten ergreift.
      </p>
      <div class="quelle">
        <a class="btn" href="https://www.wko.at/datenschutz/eu-dsgvobetroffenenrechte#heading_Was_sind_Betroffenenrechte_" target="_blank">Quelle</a>
      </div>
    </section>
    <section class="container" id="rechte">
      <h2>5.4 Kenntnis über Rechte von "betroffene Personen" lt. DSGVO</h2>
      <h3>Die Rechte der betroffenen Personen sind:  </h3>
      <ul class="left">
        <li>Informationspflicht bei der Erhebung personenbezogenen Daten bei Betroffenen direkt oder bei Dritten </li>
        <li>Die Verantwortlichen müssen Informationen über die Datenanwendung zu Verfügung stellen. Üblicherweise wird dies mittels einer Datenschutzerklärung gemacht. </li>
        <li>Auskunftsrecht </li>
        <li>Die betroffene Person kann alle personenbezogenen Daten einsehen. Dies kann Formlos (z.B. Telefonisch) angefragt werden, doch die Identität der betroffenen Person muss nachgewiesen werden. </li>
        <li>Recht auf Berichtigung, Löschung, Widerspruch und Einschränkung </li>
        <li>Die betroffene Person kann personenbezogenen Daten vom Verantwortlichen ergänzen oder löschen lassen. Außerdem kann die betroffene Person einschränken welche Daten verarbeitet werden. Diese Anträge können mit nachgewiesener Identität auch formlos gestellt werden, falls die betroffene Person die Gültigkeit oder die Rechtmäßigkeit der Daten in Frage stellt. </li>
        <li>Recht auf Datenübertragbarkeit </li>
        <li>Dieses Recht ermöglicht der betroffenen Person die beim Verantwortlichen gespeicherten personenbezogenen Daten für ihre eigenen Zwecke wiederzuverwenden. </li>
      </ul>
      <div class="quelle">
        <a class="btn" href="https://www.wko.at/datenschutz/eu-dsgvo-betroffenenrechte " target="_blank">Quelle</a>
      </div>
    </section>
    <section class="container" id="personenbezogeneUndSensibleDaten">
      <h2>5.5 Fachbegriff "personen&shy;bezogene und sensible Daten" lt. DSGVO</h2>
      <p>Die DSGVO definiert "personenbezogene Daten" und "besondere Kategorien personenbezogener Daten", die häufig auch als sensible Daten bezeichnet werden, wie folgt:</p>
      <h3>Personenbezogene Daten</h3>
      <p>Laut Artikel 4 der DSGVO sind personenbezogene Daten alle Informationen, die sich auf eine identifizierte oder identifizierbare natürliche Person („betroffene Person“) beziehen. Eine Person gilt als identifizierbar, wenn sie direkt oder indirekt, insbesondere mittels Zuordnung zu einer Kennung wie einem Namen, zu einer Identifikationsnummer, zu Standortdaten, zu einer Online-Kennung oder zu einem oder mehreren besonderen Merkmalen, die Ausdruck der physischen, physiologischen, genetischen, psychischen, wirtschaftlichen, kulturellen oder sozialen Identität dieser natürlichen Person sind, identifiziert werden kann. Beispiele hierfür sind E-Mail-Adressen, Sozialversicherungsnummern, Postanschriften oder auch Online-Identifikatoren wie IP-Adressen.</p>
      <h3>Besondere Kategorien personenbezogener Daten (Sensible Daten)</h3>
      <p>Artikel 9 der DSGVO spricht von "besonderen Kategorien personenbezogener Daten", die besonders sensibel sind und daher ein höheres Risiko für die Grundrechte und Freiheiten der Personen darstellen. Die Verarbeitung dieser Daten ist grundsätzlich untersagt, es sei denn, es liegt eine der in Artikel 9 aufgeführten Ausnahmen vor. Zu diesen besonderen Kategorien gehören Daten, die Aufschluss geben über:</p>
      <ul class="left">
        <li>Rassische oder ethnische Herkunft</li>
        <li>Politische Meinungen</li>
        <li>Religiöse oder weltanschauliche Überzeugungen</li>
        <li>Gewerkschaftszugehörigkeit</li>
        <li>Genetische Daten</li>
        <li>Biometrische Daten zur eindeutigen Identifikation einer Person</li>
        <li>Gesundheitsdaten</li>
        <li>Daten zum Sexualleben oder der sexuellen Orientierung</li>
      </ul>
      <p>Die Verarbeitung dieser sensiblen Daten ist mit strengeren Anforderungen verbunden, da sie ein höheres Risiko für die Rechte und Freiheiten der betroffenen Personen bergen. In Fällen, in denen die Verarbeitung erlaubt ist, müssen Organisationen zusätzliche Schutzmaßnahmen ergreifen, um die Sicherheit und Vertraulichkeit dieser Daten zu gewährleisten.</p>
      <div class="quelle">
        <a class="btn" href="https://www.wko.at/unternehmensfuehrung-finanzierung-foerderungen/datenschutz-grundverordnung-fragen-und-antworten" target="_blank">Quelle</a>
        <a class="btn" href="https://www.dsb.gv.at/download-links/fragen-und-antworten.html" target="_blank">Quelle</a>
      </div>
    </section>
    <section class="container" id="kopplungsverbot">
      <h2>5.6 Bedeutung von Kopplungs&shy;verbot beim DSGVO</h2>
      <p>„Eine vertragliche Leistung darf nicht davon abhängig sein, dass der Kunde in eine Datenverwendung für andere Zwecke einwilligt.“ </p>
      <p>Nach der EU-Datenschutz-Grundverordnung (DSGVO) ist immer eine Rechtsgrundlage für die Verarbeitung von Kundendaten notwendig. Häufig wird diese Grundlage darin bestehen, dass die Daten für die Erfüllung eines Vertrages benötigt werden. Eine Bestellung im Webshop kann etwa nur dann bearbeitet werden, wenn Name und Adresse des Kunden gespeichert werden. </p>
      <p>Oft besteht aber der Wunsch, die Daten der Kunden nicht nur zur Abwicklung des Vertrages, sondern darüber hinaus beispielsweise für Werbezwecke zu verwenden. Es wäre nun verlockend, die Zustimmung dafür untrennbar mit der Bestellung zu verknüpfen, etwa: </p>
      <p>Ja, ich möchte die Ware XYZ zum Preis von AB kaufen und stimme zu, den wöchentlichen E-Mail-Newsletter des Unternehmens XY an folgende E-Mail-Adresse …… zugestellt zu erhalten und nehme zur Kenntnis, dass ich diese Einwilligung jederzeit, auch bei jedem Erhalt des Newsletters, widerrufen kann.  </p>
      <p>Das wäre aber nicht zulässig, denn die Einwilligung des Kunden ist hier nicht freiwillig!  </p>
      <p>Die Erfüllung des Vertrages ist in diesem Beispiel von der Einwilligung in den Empfang des Newsletters abhängig, obwohl diese Form der Datenverwendung für die Erfüllung des Vertrages nicht erforderlich ist. Das widerspricht dem sogenannten Koppelungsverbot. </p>
      <h3>So könnte eine korrekte Aufforderung zur Einwilligung aussehen: </h3>
      <p>Ja, ich möchte die Ware XYZ zum Preis von AB kaufen.
        <br>
        Ja, ich stimme dem Erhalt eines wöchentlichen E-Mail Newsletters des Unternehmens XY, gesendet an folgende E-Mail-Adresse ……. zu.
        <br>
        Ich kann diese Einwilligung jederzeit und auch bei jedem Erhalt des Newsletters, widerrufen. Durch den Widerruf wird die Rechtmäßigkeit der aufgrund der Zustimmung bis zum Widerruf erfolgten Verarbeitung nicht berührt. </p>
      <div class="quelle">
        <a class="btn" href="https://www.wko.at/ooe/wirtschaftsrecht-gewerberecht/koppelungsverbot-im-datenschutzrecht " target="_blank">Quelle</a>
      </div>
    </section>
    <section class="container" id="datenschutzbeauftragter">
      <h2>5.7 Datenschutz&shy;beauftragter lt. DSGVO und dessen Funktion</h2>
      <p>Gemäß der Datenschutz-Grundverordnung (DSGVO) müssen bestimmte Organisationen einen Datenschutzbeauftragten ernennen. Die Hauptfunktionen eines Datenschutzbeauftragten gemäß der DSGVO umfassen:
      </p>
      <ul class="left" style="list-style: decimal">
        <li>Beratung und Überwachung: Der Datenschutzbeauftragte berät das Unternehmen oder die Organisation in allen Fragen des Datenschutzes und überwacht die Einhaltung der Datenschutzbestimmungen, einschließlich der DSGVO. </li>
        <li>Schulung und Sensibilisierung: Er ist dafür verantwortlich, das Personal über die Bestimmungen der DSGVO zu informieren und Schulungen anzubieten, um sicherzustellen, dass alle Mitarbeiter die Datenschutzrichtlinien und -verfahren verstehen und einhalten. </li>
        <li>Datenschutz-Folgenabschätzung: Bei der Einführung neuer Datenverarbeitungsverfahren oder -technologien, die ein hohes Risiko für die Rechte und Freiheiten von Einzelpersonen mit sich bringen, unterstützt der Datenschutzbeauftragte bei der Durchführung von Datenschutz-Folgenabschätzungen (DSFA). </li>
        <li>Kontakt mit Aufsichtsbehörden: Der Datenschutzbeauftragte fungiert als Ansprechpartner für die Aufsichtsbehörden in Datenschutzfragen und kooperiert mit ihnen bei der Erfüllung von Anfragen und Prüfungen. </li>
        <li>Kommunikation mit Betroffenen: Er ist die Kontaktperson für Betroffene, die Fragen oder Beschwerden bezüglich der Verarbeitung ihrer personenbezogenen Daten haben. Der Datenschutzbeauftragte ist dafür verantwortlich, angemessene Maßnahmen zur Beantwortung von Anfragen oder zur Behebung von Beschwerden zu ergreifen. </li>
        <li>Überwachung von Datenschutzverletzungen: Der Datenschutzbeauftragte unterstützt bei der Identifizierung, Bewertung und Meldung von Datenschutzverletzungen an die zuständigen Aufsichtsbehörden und Betroffenen gemäß den Vorschriften der DSGVO. </li>
      </ul>
      <p>Die genauen Aufgaben und Verantwortlichkeiten können je nach Art und Größe der Organisation variieren. In jedem Fall ist der Datenschutzbeauftragte eine wichtige Rolle bei der Gewährleistung des Datenschutzes und der Einhaltung der Datenschutzgesetze wie der DSGVO.</p>
      <div class="quelle">
        <a class="btn" href="https://www.berufslexikon.at/berufe/3349-DatenschutzbeauftragteR/#:~:text=Datenschutzbeauftragte%20beraten%2C%20informieren%20und%20betreuen,Zusammenarbeit%20mit%20der%20zust%C3%A4ndigen%20Aufsichtsbeh%C3%B6rde." target="_blank">Quelle</a>
      </div>
    </section>
    <section class="container" id="datendiebstahl">
      <h2>5.8 Pflichten für Unternehmen bei bekannt gewordenen Datendiebstahl lt. DSGVO</h2>
      <p>Informationspflichten: Sie müssen betroffene Personen unverzüglich informieren, wenn der Datendiebstahl voraussichtlich ein hohes Risiko für deren Rechte und Freiheiten zur Folge hat. Dies schließt die Bearbeitung von Anträgen zur Ausübung der Betroffenenrechte ein. </p>
      <p>Meldung an die Aufsichtsbehörde: Datenschutzverletzungen müssen in der Regel binnen 72 Stunden nach Bekanntwerden an die zuständige Aufsichtsbehörde gemeldet werden, außer es liegt ein Ausnahmegrund vor. </p>
      <p>Technische und organisatorische Maßnahmen: Das Unternehmen muss nachweisen, dass es geeignete Sicherheitsmaßnahmen getroffen hat, um die Risiken zu minimieren und die DSGVO einzuhalten. Dazu gehören Datenschutz durch Technikgestaltung und durch datenschutzfreundliche Voreinstellungen (privacy by design/default). </p>
      <p>Risikoanalysen und Datenschutz-Folgenabschätzung: Es sind regelmäßig Risikoanalysen durchzuführen. Führen diese zu dem Schluss, dass ein hohes Risiko besteht, ist eine Datenschutz-Folgenabschätzung notwendig. </p>
      <p>Datenschutzbeauftragter: Die Bestellung eines Datenschutzbeauftragten ist erforderlich, wenn die Datenverarbeitung eine regelmäßige und systematische Überwachung von Personen erfordert oder sensible Daten in großem Umfang verarbeitet werden. </p>
      <div class="quelle">
        <a class="btn" href="https://www.wko.at/datenschutz/eu-dsgvo-pflichten-verantwortliche " target="_blank">Quelle</a>
      </div>
    </section>
    <section class="container" id="gültigkeitsbereich">
      <h2>5.9 Kenntnisse über Grundbegriffe und Gültigkeits&shy;bereich des Urheber&shy;rechtes</h2>
     <p>Das Urheberrecht ist ein Rechtsbereich, der die Rechte von Autoren und anderen Kreativen an ihren geistigen Schöpfungen schützt. Hier sind einige Grundbegriffe und der Gültigkeitsbereich des Urheberrechts:</p>
      <h3>Grundbegriffe des Urheberrechts:</h3>
      <ul class="left">
        <li><strong>Urheber: </strong>Der Schöpfer eines Werkes, also die Person, die das Werk erschaffen hat.</li>
        <li><strong>Werk: </strong>Eine Schöpfung auf dem Gebiet der Literatur, Wissenschaft und Kunst, die eine persönliche geistige Schöpfung darstellt. Dazu zählen Bücher, Musik, Filme, Software, Fotografien, Graphiken und Architektur, aber auch Werbetexte und Webseitengestaltungen.</li>
        <li><strong>Verwertungsrechte: </strong>Die Rechte des Urhebers, sein Werk zu nutzen oder Dritten die Nutzung zu erlauben. Dies umfasst das Recht auf Vervielfältigung, Verbreitung, öffentliche Wiedergabe und Bearbeitung.</li>
        <li><strong>Urheberpersönlichkeitsrecht: </strong>Dieses Recht schützt die persönliche Beziehung des Urhebers zu seinem Werk, einschließlich des Rechts auf Anerkennung der Urheberschaft und des Rechts, Entstellungen oder andere Beeinträchtigungen des Werkes zu verbieten, die seine Interessen oder sein Ansehen gefährden könnten.</li>
        <li><strong>Lizenz: </strong>Eine Erlaubnis, die vom Urheber erteilt wird, um einem Dritten zu gestatten, das Werk in einer bestimmten Weise zu nutzen.</li>
      </ul>
      <h3>Gültigkeitsbereich des Urheberrechts:</h3>
      <ul class="left">
        <li><strong>Räumlicher Geltungsbereich: </strong>Das Urheberrecht gilt in der Regel landesspezifisch. Jedes Land hat seine eigenen Urheberrechtsgesetze, die auf seinem Territorium gelten. Es gibt jedoch internationale Verträge und Abkommen, wie die Berner Übereinkunft und das WIPO-Urheberrechtsvertrag, die Urheberrechtsschutz über Ländergrenzen hinweg sicherstellen.</li>
        <li><strong>Zeitliche Geltungsdauer: </strong>Das Urheberrecht tritt mit der Schöpfung des Werkes in Kraft und bleibt für eine bestimmte Zeitdauer bestehen, die nach dem Tod des Urhebers berechnet wird (oft 70 Jahre post mortem auctoris, also nach dem Tod des Urhebers).</li>
        <li><strong>Schutzfähige Werke: </strong>Nicht alles ist schutzfähig; das Werk muss eine gewisse Schöpfungshöhe erreichen und darf nicht trivial sein. Ideen, Methoden oder Konzepte an sich sind nicht geschützt, nur ihre Ausdrucksform.</li>
        <li><strong>Schutz ohne Formalitäten: </strong>In vielen Ländern, einschließlich derer, die Teil der Berner Übereinkunft sind, ist kein formaler Akt wie eine Registrierung notwendig, um Urheberrechtsschutz zu genießen.</li>
        <li><strong>Ausnahmen und Beschränkungen: </strong>Es gibt bestimmte gesetzlich festgelegte Ausnahmen vom Urheberrechtsschutz, wie zum Beispiel für Zitate, Parodien, Bildung und Wissenschaft, die unter bestimmten Umständen die Nutzung von geschützten Werken ohne Zustimmung des Urhebers erlauben.</li>
      </ul>
      <p>Das Urheberrecht soll einen Ausgleich zwischen den Interessen der Urheber und der Öffentlichkeit schaffen. Es ermöglicht Urhebern, von ihrer Arbeit zu profitieren, während es gleichzeitig sicherstellt, dass Werke schließlich in das Gemeingut (Public Domain) übergehen und so das kulturelle Erbe bereichern.</p>
      <div class="quelle">
        <a class="btn" href="https://de.wikipedia.org/wiki/Urheberrecht_(%C3%96sterreich)" target="_blank">Quelle</a>
        <a class="btn" href="https://www.wko.at/wettbewerbsrecht/urheberrecht" target="_blank">Quelle</a>
        <a class="btn" href="https://www.rechteasy.at/wiki/urheberrecht/" target="_blank">Quelle</a>
      </div>
    </section>
    <section class="container" id="garantiebestimmungen">
      <h2>5.10 Kenntnis gesetzlicher Gewähr&shy;leistungs- und Garantie&shy;bestimmungen und deren
        unterschiedlicher Anwendung bei Hardware- und Softwareproblemen</h2>
      <p>Gewährleistung und Garantie sind zwei Begriffe, die oft im Zusammenhang mit dem Kauf von Produkten, einschließlich Hardware und Software, verwendet werden. Obwohl sie manchmal synonym verwendet werden, haben sie unterschiedliche Bedeutungen und Implikationen im gesetzlichen Kontext.</p>
      <h3>Grundbegriffe des Urheberrechts:</h3>
      <ul class="left">
        <li><strong>Definition: </strong>Die Gewährleistung ist eine gesetzliche Verpflichtung des Verkäufers gegenüber dem Käufer, dass das verkaufte Produkt zum Zeitpunkt des Kaufs frei von Mängeln ist. Sie ist in vielen Ländern gesetzlich geregelt und kann nicht ausgeschlossen oder eingeschränkt werden.</li>
        <li><strong>Dauer: </strong>Die Dauer der gesetzlichen Gewährleistung ist je nach Land unterschiedlich. In der Europäischen Union beträgt die Mindestdauer in der Regel zwei Jahre ab Lieferdatum.</li>
        <li><strong>Anwendung: </strong>Die Gewährleistung deckt in der Regel Mängel ab, die zum Zeitpunkt der Übergabe vorhanden waren, auch wenn sie erst später erkennbar werden.</li>
        <li><strong>Hardware: </strong>Bei Hardware umfasst die Gewährleistung typischerweise Defekte in Material und Verarbeitung.</li>
        <li><strong>Software: </strong>Bei Software kann die Gewährleistung komplizierter sein, da Software häufig als Dienstleistung oder als lizenzierter Inhalt und nicht als physisches Produkt verkauft wird. Hier kann die Gewährleistung bedeuten, dass die Software im Wesentlichen so funktioniert, wie vom Hersteller beschrieben.</li>
      </ul>
      <h3>Garantie</h3>
      <ul class="left">
        <li><strong>Definition: </strong>Eine Garantie ist eine zusätzliche Zusage des Herstellers oder Verkäufers, die über die gesetzliche Gewährleistung hinausgeht. Sie ist nicht gesetzlich vorgeschrieben und wird freiwillig vom Garantiegeber angeboten.</li>
        <li><strong>Dauer: </strong>Die Dauer und der Umfang der Garantie können variieren und sind in den Garantiebedingungen festgelegt.</li>
        <li><strong>Anwendung: </strong>Eine Garantie kann zusätzliche Versprechungen enthalten, wie den kostenlosen Austausch von Teilen oder kostenlose Reparaturen für einen bestimmten Zeitraum.</li>
        <li><strong>Hardware: </strong>Bei Hardware ist eine Garantie oft umfassender und kann den Austausch bei Defekten oder sogar regelmäßige Wartungsdienste beinhalten.</li>
        <li><strong>Software: </strong>Bei Software können Garantien Updates oder technischen Support für einen bestimmten Zeitraum nach dem Kauf beinhalten.</li>
      </ul>
      <h3>Unterschiede in der Anwendung</h3>
      <ul class="left">
        <li><strong>•	Hardwareprobleme: </strong>Bei einem physischen Defekt eines Hardwareprodukts kann der Käufer Gewährleistungsrechte geltend machen, was bedeutet, dass der Verkäufer das Produkt reparieren, ersetzen oder den Kaufpreis erstatten muss. Falls zusätzlich eine Garantie besteht, kann der Käufer diese in Anspruch nehmen, was oft einen einfacheren oder umfangreicheren Service ermöglicht.</li>
        <li><strong>•	Softwareprobleme: </strong>Bei Software ist die Situation anders, da „Mängel“ oft schwerer zu definieren sind. Ein Softwarefehler, der nicht die grundlegende Nutzung beeinträchtigt, fällt möglicherweise nicht unter die Gewährleistung. Hier bieten Garantien oft spezifische Dienste wie Bug-Fixes oder Updates.</li>
      </ul>
      <p>In jedem Fall ist es wichtig, die Vertragsbedingungen genau zu lesen und zu verstehen, was Gewährleistung und Garantie im spezifischen Fall abdecken. Die genauen rechtlichen Rahmenbedingungen können je nach Land und spezifischem Kaufvertrag variieren.</p>
      <div class="quelle">
        <a class="btn" href="https://www.wko.at/gewerberecht/gewaehrleistung-garantie-schadenersatz-produkthaftung" target="_blank">Quelle</a>
        <a class="btn" href="https://www.anwaltfinden.at/ratgeber/gewaehrleistungsrecht/gewaehrleistung-garantie-unterschied/" target="_blank">Quelle</a>
      </div>
    </section>
    <section class="container" id="elektronikschrott">
      <h2>5.11 Kenntnisse über umwelt&shy;gerechte Entsorgung von Elektronik&shy;schrott, Toner, Akkus oder Batterien</h2>
      <p>Als Elektronikschrott zählen alle elektronischen Geräte, egal ob mit Batterie oder übers Netz betrieben. Elektronikschrott, Toner, Akkus und Batterien dürfen nicht einfach so im Restmüll entsorgt werden. </p>
      <p>Erste Anlaufstelle für die KonsumentInnen sind die Rücknahme- und Entsorgungsstellen der Gemeinden und Städte (Altstoffsammelzentren). </p>
      <p>Eine neue Verordnung verpflichtet Händler das Altgerät kostenlos zurückzunehmen, wenn ein gleichwertiges Produkt erworben wird. </p>
      <p>Der Versandhandel kann sich von seiner Rücknahmeverpflichtung dadurch befreien, indem er den KonsumentInnen zwei Rücknahmestellen pro politischen Bezirk anbietet. </p>
      <div class="quelle">
        <a class="btn" href="https://www.arbeiterkammer.at/interessenvertretung/umweltundverkehr/umwelt/abfall/Elektroaltgeraete_und_Altbatterien_entsorgen.html " target="_blank">Quelle</a>
      </div>
    </section>
    <section class="container" id="eCommerceGesetz">
      <h2>5.12 Kenntnisse über das E-Commerce - Gesetz (ECG)</h2>
      <p>Alle Anbieter von Diensten im Internet (dazu gehören insbesondere der Online-Vertrieb von Waren, der Online-Vertrieb von Dienstleistungen, Online-Informationsangebote, elektronische Suchmaschinen und Datenabfragemöglichkeiten, SMS-Dienste, WAP-Dienste sowie UMTS-Dienste, die über Mobiltelefon bereitgestellt und abgerufen werden können etc.), müssen die Informationspflichten nach dem E-Commerce-Gesetz (ECG) beachten. </p>
      <p>Das ECG verwendet den Begriff “Impressum“ nicht. Es hat sich in der Praxis aber eingebürgert, alle verpflichtenden Informationen, die den Webauftritt betreffen, unter der Bezeichnung „Impressum“ zusammenzufassen. </p>
      <h3>Impressumspflicht: </h3>
      <p>Der Diensteanbieter hat folgende Informationen leicht und unmittelbar zugänglich (z.B. auf der Startseite oder mittels klar erkennbaren Links z.B. „Wir über uns“) zur Verfügung zu stellen (bei Diensten, die über ein Mobiltelefon bereitgestellt werden, wird es genügen, wenn z.B. ein Hinweis auf eine über das Internet zugängliche Website gegeben wird):</p>
      <ul class="left">
        <li>Name bzw. Firma </li>
        <li>Rechtsform des Unternehmens (ggf. mit Zusatz in Liquidation) </li>
        <li>Sitz der Firma </li>
        <li>Firmenbuchnummer </li>
        <li>Firmenbuchgericht </li>
      </ul>
      <h3>Informationspflichten: </h3>
      <ul class="left">
        <li>Werbung muss als solche erkennbar sein. </li>
        <li>Der Auftraggeber der Werbung muss erkennbar sein. </li>
        <li>Der Auftraggeber der Werbung muss erkennbar sein. </li>
        <li>Firmenidentität: Die Identität des Anbieters muss klar erkennbar sein. Dazu gehören die Firma, die Anschrift und die Rechtsform.</li>
        <li>Kontaktmöglichkeiten:
          Es müssen klare und leicht zugängliche Kontaktmöglichkeiten
          angegeben werden, wie beispielsweise eine E-Mail-Adresse und Telefonnummer. </li>
        <li>Angaben zur Gewerbe- und Handelsregistereintragung:
          Wenn der Anbieter in das Handelsregister eingetragen ist, muss er dies angeben, einschließlich der entsprechenden Registernummer. </li>
        <li>Umsatzsteuer-Identifikationsnummer:
          Falls vorhanden, muss die Umsatzsteuer-Identifikationsnummer angegeben werden. </li>
        <li>Preisangaben:
          Die Preise der angebotenen Waren oder Dienstleistungen müssen klar und eindeutig dargestellt werden. Es müssen auch Informationen zu zusätzlichen Kosten wie Versandkosten, Steuern usw. gegeben werden. </li>
        <li>AGB (Allgemeine Geschäftsbedingungen):
          Es muss auf die Geltung der Allgemeinen Geschäftsbedingungen hingewiesen werden, und sie sollten leicht zugänglich sein. </li>
        <li>Datenschutzerklärung: </li>
      </ul>
      <p>Der Anbieter muss über die Art, den Umfang und den Zweck der Erhebung und Verwendung von personenbezogenen Daten informieren. Dies schließt auch Informationen zu Cookies ein. </p>
      
      <div class="quelle">
        <a class="btn" href="https://www.wko.at/internetrecht/informationspflichten-nach-dem-e-commerce-gesetz--dem-unte" target="_blank">Quelle</a>
        <a class="btn" href="https://www.wko.at/oe/gewerbe-handwerk/sanitaer-heizung-lueftung/e-commerce-gesetz" target="_blank">Quelle</a>
      </div>
    </section>
    <section class="container" id="telekomGesetz">
      <h2>5.13 Kenntnisse über das Telekom-Gesetz (TKG)</h2>
      <p>Das Telekommunikationsgesetz (TKG) hat mehrere Schwerpunkte, die die moderne Kommunikationsinfrastruktur betreffen:</p>
      <ul class="left">
        <li><strong>Netzausbau: </strong>Es fördert den Ausbau von Breitband-, Festnetz-, Mobilfunk- und Glasfasernetzen, um schnelle Internetverbindungen zu gewährleisten.</li>
        <li><strong>Krisenkommunikation: </strong>Das Gesetz sieht die Implementierung europaweiter Warnsysteme für Krisen- und Katastrophenfälle vor.</li>
        <li><strong>Konsumentenschutz: </strong>Hierunter fallen Maßnahmen wie der Schutz vor Nummernmissbrauch durch Ping-Anrufe, verbesserte Vertragsinformationen und die Aufrechterhaltung von Internetdiensten beim Wechsel des Anbieters.</li>
        <li><strong>Netzsicherheit: </strong>Einführung eines Überwachungssystems für Hochrisikozulieferer, insbesondere für den Aufbau von 5G-Netzen.</li>
        <li><strong>Europäische Vorgaben: </strong>Das TKG setzt den Rechtsrahmen des European Electronic Communications Code (EECC) um, welcher einheitliche Regulierungen für elektronische Kommunikationsdienste in der EU festlegt.</li>
      </ul>
      <p>Diese Punkte spiegeln die Bemühungen wider, sowohl die Infrastruktur als auch die Nutzerrechte im Telekommunikationssektor zu stärken.</p>
      <div class="quelle">
        <a class="btn" href="https://www.bmf.gv.at/themen/telekommunikation-post_2/telekommunikationsrecht-politik/neues-tkg.html " target="_blank">Quelle</a>
      </div>
    </section>
    <section class="container" id="pflichtangaben">
      <h2>5.14 Kenntnisse über Pflichtangaben eines Homepage - Betreibers (Impressum)</h2>
      <p>In Österreich müssen Homepage-Betreiber bestimmte Informationen im Impressum ihrer Webseite angeben, um rechtlichen Anforderungen gerecht zu werden. Diese Pflichtangaben sind im E-Commerce-Gesetz (ECG) und im Mediengesetz geregelt und beinhalten: </p>
      <ul class="left">
        <li><strong>Vollständigen Namen und Rechtsform: </strong>Den vollen Namen des Betreibers oder der Firma inklusive der Rechtsform wie GmbH, AG etc.</li>
        <li><strong>Anschrift: </strong>Die vollständige geschäftliche Anschrift des Unternehmens oder Betreibers.</li>
        <li><strong>Kontaktdaten: </strong>Mindestens eine E-Mail-Adresse und eine Telefonnummer für direkte und effektive Kommunikation. Falls vorhanden, auch Faxnummer.</li>
        <li><strong>Registerdaten: </strong>Das zuständige Firmenbuchgericht und die Firmenbuchnummer.</li>
        <li><strong>Umsatzsteuer-Identifikationsnummer: </strong>Falls vorhanden, insbesondere für umsatzsteuerpflichtige Unternehmen.</li>
        <li><strong>Berufsspezifische Angaben: </strong>Informationen zu beruflichen Zulassungen, Kammerzugehörigkeiten, gesetzlichen Berufsbezeichnungen und den Regeln der beruflichen Tätigkeit.</li>
        <li><strong>Aufsichtsbehörde: </strong>Die Angabe der zuständigen Aufsichtsbehörde ist erforderlich, wenn die berufliche Tätigkeit einer behördlichen Zulassung bedarf.</li>
      </ul>
      <p>Diese Informationen müssen leicht erkennbar, unmittelbar erreichbar und ständig verfügbar sein. Für bestimmte Berufsgruppen oder Tätigkeitsfelder können zusätzliche spezifische Angaben erforderlich sein. Es ist ratsam, sich vor dem Launch einer Website rechtlich beraten zu lassen, um die Einhaltung aller spezifischen nationalen Anforderungen sicherzustellen.</p>
      <div class="quelle">
        <a class="btn" href="https://www.ionos.at/digitalguide/websites/online-recht/impressum-im-internet-was-gilt-es-zu-beachten/ " target="_blank">Quelle</a>
      </div>
    </section>
    <section class="container" id="eMailVerkehr">
      <h2>5.15 Kenntnisse über Pflichtangaben beim E-Mail-Verkehr von Unternehmen</h2>
      <p>
        GewO = GewerbeOrdnung <br>
        UGB = UnternehmensGesetzBuch <br>
        DSG = DatenSchutzGesetzes <br>
        TKG = TeleKommunikationsGesetzes <br>
        MedienG = MedienGesetz <br>
        <br>
        In Österreich befassen sich mehrere Gesetze mit der so genannten „Impressumspflicht“ für E-Mails. Die einzelnen Gesetze haben dabei unterschiedliche Anwendungsbereiche. So gilt die betreffende Bestimmung im Unternehmensgesetzbuch (§ 14 UGB) nur für ins Firmenbuch eingetragene Unternehmen; die betreffende Bestimmung in der Gewerbeordnung (§ 63 GewO) gilt nur für Gewerbetreibende, die nicht ins Firmenbuch eingetragen sind; die betreffenden Bestimmungen im Mediengesetz (§§ 24, 25 MedienG) gelten für alle Versender von Newsletter. Dazu kommen noch allfällige Ergänzungen aufgrund des Telekommunikationsgesetzes (§ 107 TKG) und des Datenschutzgesetzes (§ 25 DSG).
        Die Bestimmungen gelten für jede Form von elektronischer Post und daher auch für Nachrichtensysteme von sozialen Medien wie z.B. XING, facebook und twitter
      </p>
      <h3>Impressumspflichten nach dem UGB und der GewO </h3>
      <p>Da sich die Impressumspflichten des UGB und der GewO ergänzen (§ 14 UGB gilt für ins
        Firmenbuch eingetragene Unternehmen; § 63 GewO gilt für nicht ins Firmenbuch
        eingetragene Gewerbetreibende), können die Impressumsangaben wie folgt
        zusammengefasst werden:
        Name bzw Firma laut Firmenbuch (bei Einzelunternehmen beides, falls nicht ident) </p>
      <ul class="left">
        <li> Rechtsform (nur bei im Firmenbuch eingetragenen Unternehmen notwendig;
          gegebenenfalls mit Zusatz „in Liquidation“) </li>
        <li>Sitz laut Firmenbuch bzw Standort der Gewerbeberechtigung </li>
        <li>Firmenbuchnummer (falls vorhanden) </li>
        <li> Firmenbuchgericht (falls vorhanden) </li>
        <li>falls Angaben über das Gesellschaftskapital gemacht werden: Stammkapital bzw
          Grundkapital und Betrag nicht einbezahlter Einlagen </li>
      </ul>
      <div class="quelle">
        <a class="btn" href="https://www.wko.at/internetrecht/das-korrekte-e-mail-impressum " target="_blank">Quelle</a>
      </div>
    </section>
    <section class="container" id="bildschirmpausen">
      <h2>5.16 Kenntnisse über die gesetzliche Einhaltung von Bildschirm&shy;pausen</h2>
      <h3>Bezahlte Pause bei Bildschirmarbeit: </h3>
      <p>Bildschirmarbeit beansprucht die Augen.</p>
      <h3>Daher gilt:</h3>
      <p>Wenn Sie täglich mehr als zwei Stunden ununterbrochen am Bildschirm arbeiten oder mehr als drei Stunden mit Unterbrechungen, steht Ihnen nach jeweils 50 Minuten eine zehnminütige bezahlte Pause oder ein Tätigkeitswechsel zu. </p>
      <p>Wenn der Arbeitsablauf es erfordert, ist es auch möglich, nach 100 Minuten eine Pause oder einen Tätigkeitswechsel von 20 Minuten einzulegen.
      </p>
      <div class="quelle">
        <a class="btn" href="https://www.arbeiterkammer.at/pause#:~:text=Bezahlte%20Pause%20bei%20Bildschirmarbeit%3A,Pause%20oder%20ein%20T%C3%A4tigkeitswechsel%20zu. " target="_blank">Quelle</a>
      </div>
    </section>
      <div class="center">
          <a class="btn" href="technischeDokumentationenProjektarbeitSchulungen.php">Zurück zu Technische Dokumentationen / Projektarbeit / Schulungen</a>
          <a class="btn" href="netzwerkdienste.php">Weiter zu Netzwerkdienste</a>
      </div>
  </article>
</main>
<?php include'include/footer.php' ?>