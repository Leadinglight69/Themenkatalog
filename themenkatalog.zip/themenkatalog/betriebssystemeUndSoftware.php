<?php
$title = 'Betriebssysteme und Software | Guide zur Applikationsentwicklung';
$description = 'Erkunden Sie die Kernaspekte von Betriebssystemen und Software, einschließlich Fachbegriffe, führende Systeme am Markt, Desktop-Betriebssysteme, Firmware, System- und Anwendungsprogramme sowie weitere spezialisierte Konzepte. Ein unverzichtbarer Leitfaden für angehende Applikationsentwickler.';
$keywords = 'Betriebssysteme, Software, Firmware, Powershell, Linux, Windows, macOS, Dateisystem, Applikationsentwicklung, IT';
$canonical = 'https://www.codeabschlussguide.at/betriebssysteme-und-software';
include 'include/header.php';
?>
<main class="responsive">
    <section>
        <h1>2. Betriebssysteme und Software</h1>
        <ul class="listLegend"  style="list-style: none">
            <li><a href="#betriebssystem">2.1 Fachbegriff Betriebssystem</a></li>
            <li><a href="#verbreiteten">2.2 Kenntnis der am Markt führend verbreiteten Betriebssysteme</a></li>
            <li><a href="#desktopBetriebssysteme">2.3 Kenntnisse über Desktop - Betriebssysteme</a></li>
            <li><a href="#firmware">2.4 Fachbegriff Firmware</a></li>
            <li><a href="#anwendungsprogramm">2.5 Fachbegriffe Systemprogramm, Anwendungsprogramm</a></li>
            <li><a href="#Multitaskingbetriebssystem">2.6 Fachbegriff Multitasking - Betriebssystem</a></li>
            <li><a href="#multiUserSystem">2.7 Fachbegriffe Single - User - System, Multi - User - System</a></li>
            <li><a href="#powershell">2.8 Kenntnis über die Powershell (inkl. einfacher Befehle)</a></li>
            <li><a href="#linux">2.9 Kenntnisse über grafische Oberflächen unter Linux</a></li>
            <li><a href="#dateisystem">2.10 Fachbegriff Dateisystem</a></li>
        </ul>
        <aside class="floatingNav">
            <div class="floatingDot" data-section="#betriebssystem"><span class="floatingText">2.1 </span></div>
            <div class="floatingDot" data-section="#verbreiteten"><span class="floatingText">2.2 </span></div>
            <div class="floatingDot" data-section="#desktopBetriebssysteme"><span class="floatingText">2.3 </span></div>
            <div class="floatingDot" data-section="#firmware"><span class="floatingText">2.4 </span></div>
            <div class="floatingDot" data-section="#anwendungsprogramm"><span class="floatingText">2.5 </span></div>
            <div class="floatingDot" data-section="#Multitaskingbetriebssystem"><span class="floatingText">2.6 </span></div>
            <div class="floatingDot" data-section="#multiUserSystem"><span class="floatingText">2.7 </span></div>
            <div class="floatingDot" data-section="#powershell"><span class="floatingText">2.8 </span></div>
            <div class="floatingDot" data-section="#linux"><span class="floatingText">2.9 </span></div>
            <div class="floatingDot" data-section="#dateisystem"><span class="floatingText">2.10 </span></div>
        </aside>
    </section>

    <article>
        <section class="container" id="betriebssystem">
            <h2>2.1 Fachbegriff Betriebssystem</h2>
            <p>
                Ein Betriebssystem (oft abgekürzt als BS oder OS für das englische “Operating System”) ist eine Software, die die Systemressourcen eines Computers, wie Arbeitsspeicher, Festplatten, Ein- und Ausgabegeräte verwaltet und diese Anwendungsprogrammen zur Verfügung stellt. Es ist die Schnittstelle zwischen dem Nutzer, der einen Befehl in den Computer eingeben möchte, und den Bestandteilen eines Computers, die den Befehl umsetzen.
            </p>
            <p>
                Die Aufgaben eines Betriebssystems umfassen die Verwaltung der Prozesse und Speicher, die Geräte- und Dateiverwaltung und die so genannte Abstraktion. Es ist daher für die Funktionstüchtigkeit eines Computers unverzichtbar. Es ermöglicht die Nutzung eines Computers oder Mobilgeräts, indem es die Software mit der Hardware verbindet und die auszuführenden Programme steuert.
            </p>
            <div class="quelle">
                <a class="btn" href="https://de.wikipedia.org/wiki/Betriebssystem " target="_blank">Quelle</a>
            </div>
        </section>

        <section class="container" id="verbreiteten">
            <h2>2.2 Kenntnis der am Markt führend verbreiteten Betriebssysteme</h2>
            <ul class="left">
                <li>Android (Mobil) </li>
                <li>Windows (Desktop/Server) </li>
                <li>IOS (Mobil) </li>
                <li>MacOS (Desktop)  </li>
                <li>Linux (Desktop/Server) </li>
            </ul>
            <div class="quelle">

            </div>
        </section>

        <section class="container" id="desktopBetriebssysteme">
            <h2>2.3 Kenntnisse über Desktop - Betriebssysteme</h2>
            <h3>Windows (Microsoft) </h3>
            <ul class="left">
                <li><strong>Hauptmerkmale:</strong> Benutzerfreundlich, breite Kompatibilität mit Software und Hardware. </li>
                <li><strong>Einsatzgebiete:</strong> Büroanwendungen, Gaming, Bildung, Softwareentwicklung. </li>
                <li><strong>Anpassung:</strong> Viele Optionen für das Erscheinungsbild und die Funktionalität, aber weniger Freiheiten als Linux. </li>
            </ul>
            <h3>macOS (Apple Inc.) </h3>
            <ul class="left">
                <li><strong>Hauptmerkmale:</strong> Elegantes Design, Zuverlässigkeit, nahtlose Integration mit Apple-Produkten. </li>
                <li><strong>Einsatzgebiete:</strong> Grafikdesign, Videobearbeitung, Musikproduktion, Softwareentwicklung für Apple-Geräte. </li>
                <li><strong>Anpassung:</strong> Weniger Anpassungsoptionen als Windows, stark in das Apple-Ökosystem integriert. </li>
            </ul>
            <h3>Linux (Gemeinschaftsbasiert) </h3>
            <ul class="left">
                <li><strong>Hauptmerkmale:</strong> Open-Source, bekannt für Stabilität, Sicherheit und Flexibilität. </li>
                <li><strong>Einsatzgebiete:</strong> Web- und Serveranwendungen, Softwareentwicklung, Bildung. </li>
                <li><strong>Anpassung:</strong> Umfangreiche Anpassungsmöglichkeiten durch verschiedene Desktop-Umgebungen</li>
            </ul>
            <div class="quelle">

            </div>
        </section>

        <section class="container" id="firmware">
            <h2>2.4 Fachbegriff Firmware</h2>
            <p>Firmware beschreibt Software, die in elektronische Geräte fest implementiert ist. Sie ist im Gegensatz zu herkömmlicher Software mit der Hardware unzertrennlich verankert, beide sind also aufeinander angewiesen. </p>
            <div class="quelle">
                <a class="btn" href="https://it-service.network/it-lexikon/firmware " target="_blank">Quelle 1</a>
            </div>
        </section>

        <section class="container" id="anwendungsprogramm">
            <h2>2.5 Fachbegriffe Systemprogramm, Anwendungs&shy;programm</h2>
            <p>Es gibt zwei Kategorien von Programmen. </p>
            <p><strong>Anwendungsprogramme </strong>(üblicherweise einfach "Applikationen" genannt) sind Programme, die Leute verwenden, um ihre Arbeit zu tun. Computer existieren, weil Leute mit diesen Programmen arbeiten wollen. </p>
            <p><strong>Systemprogramme</strong> helfen Hardware und Software zusammenzuarbeiten. Der Unterschied zwischen "Applikationsprogrammen" und "Systemprogrammen" ist unscharf. Es ist oft eher eine Angelegenheit des Marketings als der Logik. </p>
            <h3>Applikationsprogramme: </h3>
            <ul class="left">
                <li>Textverarbeitung  </li>
                <li>Spielprogramme </li>
                <li>Tabellenkalkulation  </li>
                <li>Datenbanken </li>
                <li>Grafikprogramme </li>
                <li>Webbrowser </li>
            </ul>
            <h3>Systemprogramme </h3>
            <ul class="left">
                <li>Betriebssystem </li>
                <li>Netzwerksystem </li>
                <li>Datenbanksystem </li>
                <li>Programme für Programmiersprachen </li>
                <li>Webserver </li>
                <li>Datensicherungssysteme </li>
            </ul>

            <div class="quelle">
                <a class="btn" href="https://www.gailer-net.de/tutorials/java3/Notes/chap01/ch01_9.html " target="_blank">Quelle 1</a>
            </div>
        </section>

        <section class="container" id="Multitaskingbetriebssystem">
            <h2>2.6 Fachbegriff Multitasking - Betriebssystem</h2>
            <p>Als Task wird im Computerbereich ein ausgeführtes Programm bezeichnet (englisch Task gleich Aufgabe oder Arbeit). Mit Multitasking wird die Fähigkeit eines Betriebssystems beschrie­ben, gleichzeitig mehrere Program­me ausführen zu können. Mit Multi­tasking kann beispielsweise in einem Programm weitergearbeitet werden, während sich das Betriebssystem um den Ausdruck von Dokumenten kümmert. Moderne Betriebssys­teme, wie Windows, Linux oder Mac OS, arbeiten mit so genanntem non-präemptiven Multitasking. </p>
            <p>Multitasking kann bei verschiedenen Anforderungen nützlich sein, insbesondere bei der Optimierung der Auslastung und für eine je nach Zielsetzung ausgeglichene oder prioritätsbasierte Ressourcenverteilung</p>
            <p>Der Grundgedanke hinter der „Optimierung der Auslastung“ ist der, dass in einem durchschnittlichen Rechner der überwiegende Teil der Rechenzeit nicht genutzt werden kann, weil häufig auf verhältnismäßig langsame, externe Ereignisse gewartet werden muss (beispielsweise auf den nächsten Tastendruck des Benutzers). Würde nur ein Prozess laufen (zum Beispiel die wartende Textverarbeitung), so ginge diese Wartezeit komplett ungenutzt verloren (siehe „aktives Warten“). Durch Multitasking kann jedoch die Wartezeit eines Prozesses von anderen Prozessen genutzt werden. </p>
            <p>Ist ein Rechner bzw. seine Rechenzeit demgegenüber größtenteils ausgelastet, beispielsweise durch einzelne rechenintensive Prozesse, so können dennoch mehrere Benutzer oder Prozesse anteilige Rechenzeit erhalten, anstatt auf das Ende eines anderen Prozesses warten zu müssen. Dies kommt insbesondere auch der Interaktivität zugute.</p>
            <p>Da das System zugleich für die verschiedenen Prozesse Prioritäten berücksichtigen kann, ist eine entsprechende Gewichtung möglich, je nach Zielsetzung. Ein Server kann zum Beispiel die Dienste bevorzugen, welche er anbieten soll, jedoch direkte Benutzer-Interaktionen niedrig priorisieren. Ein Desktop-PC wird umgekehrt vor allem die Ein- und Ausgaben von/an den Benutzer bevorzugen, und dafür Hintergrund-Prozesse etwas zurückstellen. </p>
            <div class="quelle">
                <a class="btn" href="https://de.wikipedia.org/wiki/Multitasking#Zweck_des_Multitasking " target="_blank">Quelle 1</a>
            </div>
        </section>

        <section class="container" id="multiUserSystem">
            <h2>2.7 Fachbegriffe Single - User - System, Multi - User - System</h2>
            <p><strong>Ein Single-User-System </strong>(auch Einzelbenutzersystem genannt) ist ein System, das darauf ausgelegt ist, von nur einer Person gleichzeitig genutzt zu werden. Es kann mehrere Prozesse gleichzeitig oder nacheinander ausführen, ist jedoch auf die Nutzung durch einen einzelnen Benutzer zur gleichen Zeit beschränkt. Klassische Single-User-Betriebssysteme sind MS-DOS (Microsoft Disk Operating System) oder das klassische Mac OS. </p>
            <p><strong>Ein Multi-User-System </strong>(auch Mehrbenutzersystem genannt) hingegen ist ein Betriebssystem, das die Möglichkeit bietet, Arbeitsumgebungen für verschiedene Benutzer bereitzustellen und voneinander abzugrenzen. Es ermöglicht mehreren Benutzern, gleichzeitig auf verschiedene Ressourcen eines Computers zuzugreifen. Dieser Zugriff wird über ein Netzwerk bereitgestellt, das aus verschiedenen persönlichen Computern besteht, die an ein Hauptrechnersystem angeschlossen sind. </p>
            <div class="quelle">
                <a class="btn" href="https://de.wikipedia.org/wiki/Einzelbenutzersystem " target="_blank">Quelle 1</a>
                <a class="btn" href="https://de.wikipedia.org/wiki/Mehrbenutzersystem" target="_blank">Quelle 2</a>
            </div>
        </section>

        <section class="container" id="powershell">
            <h2>2.8 Kenntnis über die Powershell (inkl. einfacher Befehle)</h2>
            <h3>Was ist Windows PowerShell?</h3>
            <p>Windows PowerShell ist, wie der Name schon sagt, eine sogenannte „Shell“. In der Informationstechnik versteht man darunter eine Schnittstelle zwischen einem Computer und seinem Benutzer. Der englische Begriff „Shell“ bedeutet „Muschelschale“, wird im übertragenden Sinne aber zur Bezeichnung einer äußeren Hülle verwendet. So auch in der Informatik: Dort bezeichnet man mit dem Begriff die sichtbare Benutzer-Oberfläche, über die man mit den systeminternen Funktionen eines Computers interagieren kann. </p>
            <p>Shells sind in der Regel kommandoorientiert und werden deshalb ausschließlich per Tastatur und Texteingaben gesteuert. Sie bilden damit eine Alternative zu grafischen Benutzeroberflächen (graphical user interfaces, kurz: GUI), auf denen man vorrangig mit der Maus navigiert – wie beispielsweise dem Windows-Explorer. Da Shells darüber hinaus Zugang zu deutlich mehr und tieferliegenden Funktionen und Komponenten eines PCs gewähren, werden sie von vielen IT-Profis und Systemadministratoren bevorzugt. </p>
            <table style="max-width: 700px">
                <thead >
                <tr class="tableRow" >
                    <th>Alias</th>
                    <th>Cmdlet</th>
                    <th>Funktion</th>
                </tr>
                </thead>
                <tbody>
                <tr class="tableRow">
                    <td>cd </td>
                    <td>Set-Location </td>
                    <td>Aktuelles Verzeichnis wechseln </td>
                </tr>
                <tr class="tableRow">
                    <td>dir </td>
                    <td>Get-ChildItem </td>
                    <td>Alle Elemente eines Ordners auflisten </td>
                </tr>
                <tr class="tableRow">
                    <td>gi </td>
                    <td>Get-Item </td>
                    <td>Ein bestimmtes Element aufrufen </td>
                </tr>
                <tr class="tableRow">
                    <td>ps</td>
                    <td>Get-Process </td>
                    <td>Alle Prozesse auflisten </td>
                </tr>
                <tr class="tableRow">
                    <td>gsv</td>
                    <td>Get-Service</td>
                    <td>Alle installierten Dienste auflisten </td>
                </tr>
                <tr class="tableRow">
                    <td>gm </td>
                    <td>Get-Member </td>
                    <td>Alle Eigenschaften und Methoden eines Objekts anzeigen </td>
                </tr>
                <tr class="tableRow">
                    <td>clear</td>
                    <td>Clear-Host </td>
                    <td>Den PowerShell-Host leeren</td>
                </tr>
                </tbody>
            </table>
            <div class="quelle">
                <a class="btn" href="https://www.ionos.at/digitalguide/server/knowhow/windows-powershell/" target="_blank">Quelle 1</a>
            </div>
        </section>

        <section class="container" id="linux">
            <h2>2.9 Kenntnisse über grafische Oberflächen unter Linux</h2>
            <h3>GNOME </h3>
            <p>Populär und einfach, fokussiert auf Produktivität. Bietet eine moderne und intuitive Benutzeroberfläche, optimiert für Effizienz. </p>
            <h3>KDE Plasma </h3>
            <p>Bekannt für Anpassungsfähigkeit und visuelle Attraktivität. Ermöglicht eine umfangreiche Personalisierung durch Widgets und Themen, ressourceneffizient und optisch ansprechend.</p>
            <h3>XFCE</h3>
            <p>Eine leichte Desktop-Umgebung, die für Geschwindigkeit und Effizienz auf älterer Hardware steht. Bietet eine klassische Erfahrung mit hoher Anpassbarkeit. </p>
            <h3>LXQt und LXDE </h3>
            <p>Beide sind für ihre Leichtigkeit und Schnelligkeit bekannt, ideal für weniger leistungsstarke Hardware. Sie bieten eine einfache, traditionelle Desktop-Erfahrung mit Fokus auf Ressourceneffizienz.</p>
            <div class="quelle">
                <a class="btn" href="https://de.wikipedia.org/wiki/Linux" target="_blank">Quelle</a>
            </div>
        </section>

        <section class="container" id="dateisystem">
            <h2>2.10 Fachbegriff Dateisystem</h2>
            <p>Das Filesystem ist für die Organisation der auf Speichermedien abgelegten Dateien verantwortlich. Es ist ein Bestandteil eines Betriebssystems und kann von Speichermedium zu Speichermedium unterschiedlich sein. Das Filesystem definiert Dateinamenskonventionen, Dateiattribute oder die Zugriffskontrolle. Typische Filesysteme sind FAT, NTFS, Ext oder ISO 9660.
                <br>
                Z.B.:
                <br>
                Die maximalen Dateigrössen und Berechtigungen unterscheiden sich die Möglichkeiten hat nur NTFS </p>
            <div class="quelle">
                <a class="btn" href="https://www.storage-insider.de/was-ist-ein-filesystem-a-862645/ " target="_blank">Quelle</a>
            </div>
        </section>
        <div class="center">
            <a class="btn" href="grundlagenInformationstechnologie.php">Zurück zu Grundlagen in der Informations&shy;technik</a>
            <a class="btn" href="betreuungVonMobilerHardware.php">Weiter zu Betreuung von mobiler Hardware</a>
        </div>


    </article>
</main>
<?php include 'include/footer.php'; ?>