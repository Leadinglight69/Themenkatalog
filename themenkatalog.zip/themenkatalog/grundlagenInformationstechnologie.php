<?php
$title = 'Grundlagen der Informationstechnik: Von ASCII bis Logik-Schaltungen';
$description = 'Erlernen Sie die Grundlagen der Informationstechnik, darunter wichtige Konzepte wie ASCII, Datenmengeneinheiten wie Bit und Byte, Speichergrößen von Gigabyte bis Exabyte, Zahlensysteme und die Umwandlung zwischen ihnen, sowie die Funktionsweise von Logik-Schaltungen und deren Wahrheitstabellen.';
$keywords = 'Informationstechnik Grundlagen, ASCII, Bit Byte, Gigabyte Terabyte, Binär Dezimal Hexadezimal, Logik-Schaltungen, AND OR XOR NOT, IT Zahlensysteme';
$canonical = 'https://www.codeabschlussguide.at/grundlagen-informationstechnik';
include 'include/header.php'
?>
<main class="responsive">
    <section>
        <h1>1 Grundlagen in der Informationstechnik</h1>
        <ul class="listLegend"  style="list-style: none">
            <li><a href="#ascii">1.1 Kenntnis des Zeichensatzes ASCII</a></li>
            <li><a href="#einheiten">1.2 Kenntnis der Einheiten Bit, Byte</a></li>
            <li><a href="#speichereinheiten">1.3 Kenntnis der Begriffe Gigabyte, Terabyte, Petabyte, Exabyte</a></li>
            <li><a href="#binärpräfixe">1.4 Kenntnis der Begriffe Gibibyte, Tebibyte, Pebibyte, Exbibyte</a></li>
            <li><a href="#zahlensysteme">1.5 Kenntnis der gebräuchlichen Zahlensysteme in der IT</a></li>
            <li><a href="#von-binaer-zu-dezimal">1.6 Umwandlung zwischen Binär-, Dezimal- und Hexadezimalzahlen</a></li>
            <li><a href="#logikschaltungen">1.7 Kenntnis der Logik-Schaltungen (AND, OR, XOR, NOT) und deren Wahrheitstabellen</a></li>
        </ul>
        <aside class="floatingNav">
            <div class="floatingDot" data-section="#ascii"><span class="floatingText">1.1 Kenntnis des Zeichensatzes ASCII</span></div>
            <div class="floatingDot" data-section="#einheiten"><span class="floatingText">1.2 Kenntnis der Einheiten Bit, Byte</span></div>
            <div class="floatingDot" data-section="#speichereinheiten"><span class="floatingText">1.3 Kenntnis der Begriffe Gigabyte, Terabyte, Petabyte, Exabyte</span></div>
            <div class="floatingDot" data-section="#binärpräfixe"><span class="floatingText">1.4 Kenntnis der Begriffe Gibibyte, Tebibyte, Pebibyte, Exbibyte</span></div>
            <div class="floatingDot" data-section="#zahlensysteme"><span class="floatingText">1.5 Kenntnis der gebräuchlichen Zahlensysteme in der IT</span></div>
            <div class="floatingDot" data-section="#von-binaer-zu-dezimal"><span class="floatingText">1.6 Umwandlung zwischen Binär-, Dezimal- und Hexadezimalzahlen</span></div>
            <div class="floatingDot" data-section="#logikschaltungen"><span class="floatingText">1.7 Kenntnis der Logik-Schaltungen (AND, OR, XOR, NOT) und deren Wahrheitstabellen</span></div>
        </aside>
    </section>

    <article>
        <section class="container" id="ascii">
            <h2>1.1Kenntnis des Zeichensatzes ASCII</h2>
            <p>ASCII steht für „American Standard Code for Information Interchange“. Es ist eine 7 Bit Zeichenkodierung, die 128 Zeichen beinhaltet, das heißt, dass jedem Zeichen eine einzigartige Kombination aus 7 0en und 1en zugeordnet ist. 95 davon sind druckbar, 33 sind Steuerzeichen, wie Zeileneinrückungen etc. Das Achte Bit im Byte wurde als Paritätsbit um eventuelle Übertragungsfehler zu prüfen, doch heutzutage wird der 7 Bit Code in den meisten Computern auf 8 Bit erweitert.</p>
            <div class="quelle">
                <a class="btn" href="https://praxistipps.chip.de/ascii-was-ist-das-einfach-erklaert_41542"target="_blank">Quelle 1</a>
                <a class="btn" href="https://www.ionos.de/digitalguide/server/knowhow/ascii-american-standard-code-for-information-interchange"target="_blank">Quelle 2</a>
                <a class="btn" href="https://www.itwissen.info/Paritaetsbit-parity-bit-PY.html"target="_blank">Quelle 3</a>
            </div>
        </section>

        <section class="container" id="einheiten">
            <h2>1.2 Kenntnis der Einheiten Bit, Byte</h2>
            <p>
                Die Einheiten Bit und Byte sind grundlegende Maßeinheiten für Datenmengen in der digitalen Informationsverarbeitung und Datenspeicherung.
            </p>
            <ul class="left">
                <li><strong>Bit:</strong> Ein Bit ist die kleinste Daten-Einheit in der Computertechnik und kann einen von zwei Werten haben, 0 oder 1. Es repräsentiert ein binäres Konzept, das die Grundlage für die meisten modernen Computersysteme bildet.
                </li>
                <li><strong>Byte:</strong> Ein Byte besteht aus 8 Bits. Mit einem Byte lassen sich 256 verschiedene Zustände (2^8) darstellen, was ausreicht, um zum Beispiel ein ASCII-Zeichen zu speichern. In der Informatik wird das Byte sehr häufig als Maßeinheit für die Speichergröße verwendet, zum Beispiel bei der Angabe von Arbeitsspeicher oder Festplattenspeicher.
                </li>
            </ul>
            <p>
                Die weiteren Vielfachen des Bytes werden oft in Kilobyte (KB), Megabyte (MB), Gigabyte (GB), Terabyte (TB), usw. angegeben, wobei in der Computerwissenschaft ein Kilobyte 1.024 Bytes entspricht, da es auf der Basis von Potenzen von 2 berechnet wird (2^10). Allerdings wird in der Datenübertragung und im allgemeinen Sprachgebrauch häufig die dezimale Definition verwendet, wo 1 KB einfach 1.000 Bytes bedeutet
            </p>
            <span class="quelle">
            <a class="btn" href="https://www.ionos.at/digitalguide/websites/web-entwicklung/was-ist-ein-bit"target="_blank">Quelle 1</a>
            <a class="btn" href="https://de.wikipedia.org/wiki/Byte"target="_blank">Quelle 2</a>
            </span>
        </section>

        <section class="container" id="speichereinheiten">
            <h2>1.3 Kenntnis der Begriffe Gigabyte, Terabyte, Petabyte, Exabyte</h2>
            <ul class="left">
                <li><strong>Gigabyte (GB):</strong> Ein Gigabyte entspricht 1.024 Megabyte (MB).</li>
                <li><strong>Terabyte (TB):</strong> Ein Terabyte ist 1.024 Gigabyte (GB).</li>
                <li><strong>Petabyte (PB):</strong> Ein Petabyte steht für 1.024 Terabyte (TB).</li>
                <li><strong>Exabyte (EB):</strong> Ein Exabyte entspricht 1.024 Petabyte (PB).</li>
            </ul>
            <span class="quelle">
            <a class="btn" href="https://www.ionos.at/digitalguide/websites/web-entwicklung/speichergroessen"target="_blank">Quelle 1</a>
            <a class="btn" href="https://www.storage-insider.de/speichergroessen-verstaendlich-dargestellt-vom-bit-zum-yottabyte-a-517817/"target="_blank">Quelle 2</a>
            </span>
        </section>

        <section class="container" id="binärpräfixe">
            <h2>1.4 Kenntnis der Begriffe Gibibyte, Tebibyte, Pebibyte, Exbibyte</h2>
            <ul class="left">
                <li><strong>Gibibyte (GiB):</strong> Ein Gibibyte besteht aus 2^30 Bytes.</li>
                <li><strong>Tebibyte (TiB):</strong> Ein Tebibyte besteht aus 2^40 Bytes.</li>
                <li><strong>Pebibyte (PiB):</strong> Ein Pebibyte besteht aus 2^50 Bytes.</li>
                <li><strong>Exbibyte (EiB):</strong> Ein Exbibyte besteht aus 2^60 Bytes.</li>
            </ul>
            <span class="quelle">
                <a class="btn" href="https://de.wiktionary.org/wiki/Gibibyte"target="_blank">Quelle 1</a>
                <a class="btn" href="https://de.wiktionary.org/wiki/Tebibyte"target="_blank">Quelle 2</a>
            </span>
        </section>

        <section class="container" id="zahlensysteme">
            <h2>1.5 Gebräuchliche Zahlensysteme in der IT</h2>
                <h3>Binärsystem (Basis 2)</h3>
                <p>Verwendet nur zwei Ziffern: 0 und 1. Es ist das grundlegende Zahlensystem der Computertechnik.</p>
                    <span class="quelle">
                        <a class="btn" href="https://de.wikipedia.org/wiki/Dualsystem"target="_blank">Mehr zum Binärsystem</a>
                    </span>
                <h3>Dezimalsystem (Basis 10)</h3>
                <p>Besteht aus den Ziffern 0 bis 9 und wird im Alltagsleben am häufigsten verwendet.</p>
                    <span class="quelle">
                        <a class="btn" href="https://de.wikipedia.org/wiki/Dezimalsystem"target="_blank">Mehr zum Dezimalsystem</a>
                    </span>
                <h3>Oktalsystem (Basis 8)</h3>
                <p>Nutzt die Ziffern 0 bis 7. Es wurde früher in der Computertechnik genutzt.</p>
                    <span class="quelle">
                        <a class="btn" href="https://de.wikipedia.org/wiki/Oktalsystem"target="_blank">Mehr zum Oktalsystem</a>
                    </span>
                <h3>Hexadezimalsystem (Basis 16)</h3>
                <p>Verwendet sechzehn Ziffern: 0 bis 9 und A bis F.</p>
                    <span class="quelle">
                        <a class="btn" href="https://de.wikipedia.org/wiki/Hexadezimalsystem"target="_blank">Mehr zum Hexadezimalsystem</a>
                    </span>
        </section>

        <section class="container" id="von-binaer-zu-dezimal">
            <h2>1.6 Umwandlung zwischen Zahlensystemen</h2>
            <p>Umwandlung zwischen Binär-, Dezimal- und Hexadezimalzahlen Die Umwandlung zwischen Binär-, Dezimal- und Hexadezimalzahlen ist eine grundlegende Fähigkeit in der Informatik und Elektronik. Hier sind die Grundlagen für die Umwandlung: </p>
            <h3>Von Binär in Dezimal</h3>
            <p>Jede Stelle einer Binärzahl steht für eine Potenz von 2, beginnend mit 2^0 für die am weitesten rechts stehende Stelle. Um eine Binärzahl in eine Dezimalzahl umzuwandeln, addieren Sie die Werte aller Stellen, an denen eine '1' steht.
            </p>
            <p><strong>Beispiel:</strong> Die Binärzahl 1101 </p>
            <ul class="left">
                <li>1×23=8 </li>
                <li>1×22=41×22=4 </li>
                <li>0×21=00×21=0 (wird ignoriert, da 0) </li>
                <li>1×20=11×20=1 </li>
            </ul>
            <p>Addieren Sie diese zusammen: 8+4+1=138+4+1=13 in dezimal.</p>
            <h3>Von Dezimal in Binär: </h3>
            <p>Um eine Dezimalzahl in eine Binärzahl umzuwandeln, teilen Sie die Zahl durch 2 und notieren Sie den Rest. Wiederholen Sie diesen Vorgang mit dem Quotienten, bis Sie 0 erreichen. Die Binärzahl ergibt sich dann durch das Lesen der Reste von unten nach oben. </p>
            <p><strong>Beispiel:</strong> Die Dezimalzahl 13</p>
            <ul class="left">
                <li>13÷2=6 Rest 1 </li>
                <li>6÷2=36÷2=3 Rest 0 </li>
                <li>3÷2=13÷2=1 Rest 1 </li>
                <li>1÷2=01÷2=0 Rest 1 </li>
            </ul>
            <p>Die Binärzahl lautet 1101</p>
            <h3>Von Dezimal in Hexadezimal: </h3>
            <p>Bei der Umwandlung von Dezimal in Hexadezimal wird ähnlich wie bei der Umwandlung in Binär verfahren, nur dass jetzt durch 16 geteilt wird. Die Reste, die dabei entstehen, werden den Hexadezimalzahlen 0-9 und A-F zugeordnet, wobei A für 10 steht, B für 11, bis F für 15. </p>
            <p><strong>Beispiel:</strong> Die Dezimalzahl 255</p>
            <ul class="left">
                <li>255÷16=15255÷16=15 Rest 15, was im Hexadezimalsystem 'F' ist. </li>
                <li>15÷16=015÷16=0 Rest 15, was im Hexadezimalsystem 'F' ist. </li>
            </ul>
            <p>Die Hexadezimalzahl lautet FF. </p>
            <h3>Von Hexadezimal in Dezimal: </h3>
            <p>Um eine Hexadezimalzahl in eine Dezimalzahl umzuwandeln, multiplizieren Sie jede Stelle mit 16 hoch ihrer Position (beginnend mit 0 von rechts) und addieren Sie die Ergebnisse. </p>
            <p><strong>Beispiel:</strong> Die Hexadezimalzahl FF</p>
            <ul class="left">
                <li>F×161=15×16=240  </li>
                <li>F×160=15×1=15  </li>
            </ul>
            <p>Addieren Sie diese zusammen: 240+15=255 in dezimal. </p>
            <h3>Von Binär in Hexadezimal (und umgekehrt): </h3>
            <p>Um von Binär in Hexadezimal umzuwandeln, teilen Sie die Binärzahl in Vierergruppen von rechts nach links ein und wandeln Sie jede Gruppe in die entsprechende Hexadezimalzahl um. </p>
            <p><strong>Beispiel:</strong> Die Binärzahl 11111111</p>
            <ul class="left">
                <li>Teilen Sie in Vierergruppen: 1111 1111 </li>
                <li>Wandeln Sie jede Gruppe um: 1111 ist F und 1111 ist F  </li>
            </ul>
            <p>Die Hexadezimalzahl lautet FF.</p>
            <p>Für die Umwandlung von Hexadezimal in Binär kehren Sie den Prozess einfach um: Wandeln Sie jede Hexadezimalstelle in eine Vierergruppe von Binärzahlen um.
                <br>
                Diese Methoden sind die Grundlage für die Konvertierung zwischen diesen Zahlensystemen. Es gibt auch zahlreiche Tools und Rechner, die diese Konvertierungen automatisch durchführen können. </p>


            <span class="quelle">
                <a class="btn" href="https://www.mathe-lexikon.at/mengenlehre/zahlensysteme/binaerzahlen/binaerzahl-in-hexadezimalzahl-umrechnen.html " target="_blank">Quelle</a>
                <a class="btn" href="https://www.arndt-bruenner.de/mathe/scripts/Zahlensysteme.htm "target="_blank">Quelle</a>
            </span>
        </section>

        <section class="container" id="logikschaltungen">
            <h2>1.7 Kenntnis der Logik-Schaltungen (AND, OR, XOR, NOT) und deren Wahrheitstabellen</h2>
            <h3>UND-Gatter (AND)</h3>
                <p>Das AND-Gatter gibt 1 (wahr) aus, nur wenn beide Eingänge 1 (wahr) sind.</p>
            <table>
                <thead class="tableHead">
                <tr class="tableRow">
                    <th>A</th>
                    <th>B</th>
                    <th>A AND B</th>
                </tr>
                </thead>
                <tbody>
                <tr class="tableRow">
                    <td>0</td>
                    <td>0</td>
                    <td>0</td>
                </tr>
                <tr class="tableRow">
                    <td>0</td>
                    <td>1</td>
                    <td>0</td>
                </tr>
                <tr class="tableRow">
                    <td>1</td>
                    <td>0</td>
                    <td>0</td>
                </tr>
                <tr class="tableRow">
                    <td>1</td>
                    <td>1</td>
                    <td>1</td>
                </tr>
                </tbody>
            </table>

            <h3>ODER-Gatter (OR)</h3>
            <p>Das OR-Gatter gibt 1 aus, wenn mindestens einer der Eingänge 1 ist.</p>
            <table>
                <thead>
                <tr class="tableRow">
                    <th>A</th>
                    <th>B</th>
                    <th>A OR B</th>
                </tr>
                </thead>
                <tbody>
                <tr class="tableRow">
                    <td>0</td>
                    <td>0</td>
                    <td>0</td>
                </tr>
                <tr class="tableRow">
                    <td>0</td>
                    <td>1</td>
                    <td>1</td>
                </tr>
                <tr class="tableRow">
                    <td>1</td>
                    <td>0</td>
                    <td>1</td>
                </tr>
                <tr class="tableRow">
                    <td>1</td>
                    <td>1</td>
                    <td>1</td>
                </tr>
                </tbody>
            </table>
            <h3>XOR-Gatter (Exklusiv-Oder)</h3>
            <p>Das XOR-Gatter gibt 1 aus, wenn genau einer der Eingänge 1 ist.</p>
            <table>
                <thead>
                <tr class="tableRow">
                    <th>A</th>
                    <th>B</th>
                    <th>A XOR B</th>
                <tr class="tableRow">
                </thead>
                <tbody>
                <tr class="tableRow">
                    <td>0</td>
                    <td>0</td>
                    <td>0</td>
                </tr>
                <tr class="tableRow">
                    <td>0</td>
                    <td>1</td>
                    <td>1</td>
                </tr>
                <tr class="tableRow">
                    <td>1</td>
                    <td>0</td>
                    <td>1</td>
                </tr>
                <tr class="tableRow">
                    <td>1</td>
                    <td>1</td>
                    <td>0</td>
                </tr>
                </tbody>
            </table>
            <h3>NOT-Gatter (Inverter)</h3>
            <p>Das NOT-Gatter invertiert den Eingang; es gibt 1 aus, wenn der Eingang 0 ist, und umgekehrt.</p>
            <table>
                <thead>
                <tr class="tableRow">
                    <th>A</th>
                    <th>NOT A</th>
                </tr>
                </thead>
                <tbody>
                <tr class="tableRow">
                    <td>0</td>
                    <td>1</td>
                </tr>
                <tr class="tableRow">
                    <td>1</td>
                    <td>0</td>
                </tr>
                </tbody>
            </table>
            <span class="quelle">
                <a class="btn" href="https://simpleclub.com/lessons/informatik-logikgatter " target="_blank">Quelle</a>
            </span>
        </section>

    </article>
    <div class="center">
        <a class="btn" href="betriebssystemeUndSoftware.php">Weiter zu Betriebssysteme und Software</a>
    </div>

</main>
<?php include'include/footer.php' ?>